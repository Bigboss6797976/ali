#!/bin/bash
# AlipayQR v3.0 - iOS IPA打包脚本

set -e

echo "========================================"
echo "   AlipayQR v3.0 - iOS IPA打包"
echo "========================================"
echo ""

# 检查macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "[!] iOS打包需要macOS系统"
    exit 1
fi

# 检查Xcode
if ! command -v xcodebuild &> /dev/null; then
    echo "[!] 需要安装Xcode"
    echo "    从App Store安装Xcode"
    exit 1
fi

if ! command -v node &> /dev/null; then
    echo "[!] 需要安装Node.js"
    exit 1
fi

echo "[*] 环境检查通过"

# 安装依赖
echo "[*] 安装依赖..."
npm install
npm install @capacitor/ios @capacitor/core @capacitor/cli

# 添加iOS平台
echo "[*] 添加iOS平台..."
npx cap add ios 2>/dev/null || echo "[*] iOS平台已存在"

# 同步Web资源
echo "[*] 同步Web资源到iOS..."
npx cap sync ios

# 打开Xcode项目
echo "[*] 打开Xcode项目..."
echo "    请在Xcode中配置签名并构建"
echo ""
echo "    手动构建步骤:"
echo "    1. 打开 ios/App/App.xcworkspace"
echo "    2. 选择你的Team/签名"
echo "    3. Product -> Archive"
echo "    4. Distribute App -> Ad Hoc/App Store"
echo ""

npx cap open ios

echo "========================================"
echo "   iOS项目已准备好!"
echo "========================================"
