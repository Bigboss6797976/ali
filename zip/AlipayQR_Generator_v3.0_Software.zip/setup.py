from setuptools import setup, find_packages
import os

# 读取README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# 读取版本
with open("src/__init__.py", "r") as f:
    for line in f:
        if line.startswith("__version__"):
            version = line.split("=")[1].strip().strip('"').strip("'")
            break

setup(
    name="alipayqr",
    version=version,
    author="AlipayQR Team",
    description="多通道聚合收款码生成器 - 支持支付宝/微信/Stripe/易支付",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/alipayqr",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial",
        "Topic :: Utilities",
    ],
    python_requires=">=3.8",
    install_requires=[
        "qrcode[pil]>=7.0",
        "Pillow>=9.0",
        "pycryptodome>=3.15",
        "cryptography>=3.4",
        "requests>=2.28",
        "pyinstaller>=5.0;platform_system!='Darwin'",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
            "mypy>=0.990",
        ],
        "camera": [
            "opencv-python>=4.5",
            "pyzbar>=0.1.9",
        ],
        "all": [
            "opencv-python>=4.5",
            "pyzbar>=0.1.9",
            "zxing>=0.14",
            "pystray>=0.19",
        ]
    },
    entry_points={
        "console_scripts": [
            "alipayqr=cli.alipayqr:main",
        ],
        "gui_scripts": [
            "alipayqr-gui=gui.app:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.html", "*.json", "*.js", "*.css", "*.png", "*.svg", "*.ico"],
    },
    zip_safe=False,
)
