const { app, BrowserWindow, ipcMain, dialog, shell, Tray, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { exec } = require('child_process');

let mainWindow;
let tray;
let server;
const PORT = 19456; // 固定端口

// 启动本地服务器
function startServer() {
    const serverPath = path.join(__dirname, 'src', 'ui', 'web');

    server = http.createServer((req, res) => {
        let filePath = path.join(serverPath, req.url === '/' ? 'index.html' : req.url);

        const ext = path.extname(filePath).toLowerCase();
        const mimeTypes = {
            '.html': 'text/html',
            '.js': 'application/javascript',
            '.css': 'text/css',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.svg': 'image/svg+xml',
            '.ico': 'image/x-icon',
        };

        const contentType = mimeTypes[ext] || 'application/octet-stream';

        fs.readFile(filePath, (err, content) => {
            if (err) {
                if (err.code === 'ENOENT') {
                    res.writeHead(404);
                    res.end('404 Not Found');
                } else {
                    res.writeHead(500);
                    res.end('500 Server Error');
                }
            } else {
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(content, 'utf-8');
            }
        });
    });

    server.listen(PORT, '127.0.0.1', () => {
        console.log(`[+] Server running at http://127.0.0.1:${PORT}`);
    });

    return PORT;
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 520,
        height: 900,
        minWidth: 400,
        minHeight: 700,
        titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js'),
            webSecurity: false
        },
        icon: path.join(__dirname, 'assets', 'icons', 'icon-512.png'),
        show: false,
        backgroundColor: '#1677FF',
        vibrancy: 'sidebar',
        transparent: false,
    });

    // 加载本地服务器
    mainWindow.loadURL(`http://127.0.0.1:${PORT}`);

    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        // 开发模式打开DevTools
        // mainWindow.webContents.openDevTools();
    });

    mainWindow.on('closed', () => {
        mainWindow = null;
    });

    // 处理新窗口打开
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        shell.openExternal(url);
        return { action: 'deny' };
    });
}

// 系统托盘
function createTray() {
    const iconPath = path.join(__dirname, 'assets', 'icons', 'icon-16.png');

    if (!fs.existsSync(iconPath)) {
        // 如果没有16x16图标，使用512的
        tray = new Tray(path.join(__dirname, 'assets', 'icons', 'icon-512.png'));
    } else {
        tray = new Tray(iconPath);
    }

    const contextMenu = Menu.buildFromTemplate([
        { label: '打开 AlipayQR', click: () => {
            if (mainWindow) {
                mainWindow.show();
                mainWindow.focus();
            } else {
                createWindow();
            }
        }},
        { type: 'separator' },
        { label: '快速生成收款码', click: () => {
            if (mainWindow) {
                mainWindow.show();
                mainWindow.webContents.executeJavaScript(`
                    document.querySelector('.tab').click();
                    document.getElementById('amount').value = '100';
                    generateQR();
                `);
            }
        }},
        { type: 'separator' },
        { label: '退出', click: () => {
            app.quit();
        }}
    ]);

    tray.setToolTip('AlipayQR v3.0');
    tray.setContextMenu(contextMenu);

    tray.on('click', () => {
        if (mainWindow) {
            mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
        } else {
            createWindow();
        }
    });
}

// IPC通信
ipcMain.handle('save-file', async (event, data, filename) => {
    const result = await dialog.showSaveDialog(mainWindow, {
        defaultPath: filename,
        filters: [
            { name: 'PNG图片', extensions: ['png'] },
            { name: 'SVG图片', extensions: ['svg'] },
            { name: '所有文件', extensions: ['*'] }
        ]
    });

    if (!result.canceled && result.filePath) {
        const base64Data = data.replace(/^data:image\/\w+;base64,/, '');
        const buffer = Buffer.from(base64Data, 'base64');
        fs.writeFileSync(result.filePath, buffer);
        return { success: true, path: result.filePath };
    }
    return { success: false };
});

ipcMain.handle('open-external', async (event, url) => {
    await shell.openExternal(url);
});

ipcMain.handle('get-version', () => {
    return app.getVersion();
});

ipcMain.handle('show-notification', (event, title, body) => {
    if (process.platform === 'darwin') {
        // macOS使用原生通知
    } else if (process.platform === 'win32') {
        // Windows使用托盘通知
        tray.displayBalloon({
            iconType: 'info',
            title: title,
            content: body
        });
    }
});

// 应用生命周期
app.whenReady().then(() => {
    startServer();
    createWindow();
    createTray();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    // macOS保持运行
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('before-quit', () => {
    if (server) {
        server.close();
    }
});

// 单实例锁定
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
    app.quit();
} else {
    app.on('second-instance', () => {
        if (mainWindow) {
            if (mainWindow.isMinimized()) mainWindow.restore();
            mainWindow.focus();
        }
    });
}
