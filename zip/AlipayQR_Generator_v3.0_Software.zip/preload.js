const { contextBridge, ipcRenderer } = require('electron');

// 暴露安全的API给前端
contextBridge.exposeInMainWorld('electronAPI', {
    saveFile: (data, filename) => ipcRenderer.invoke('save-file', data, filename),
    openExternal: (url) => ipcRenderer.invoke('open-external', url),
    getVersion: () => ipcRenderer.invoke('get-version'),
    showNotification: (title, body) => ipcRenderer.invoke('show-notification', title, body),

    // 平台信息
    platform: process.platform,

    // 文件系统操作 (受限)
    readFile: (path) => ipcRenderer.invoke('read-file', path),
});

// 监听来自主进程的消息
ipcRenderer.on('from-main', (event, message) => {
    console.log('Message from main:', message);
});
