#!/bin/bash
# AlipayQR v3.0 - Android APK打包脚本

set -e

echo "========================================"
echo "   AlipayQR v3.0 - Android APK打包"
echo "========================================"
echo ""

# 检查环境
if ! command -v java &> /dev/null; then
    echo "[!] 需要安装Java JDK 17+"
    echo "    Ubuntu: sudo apt install openjdk-17-jdk"
    echo "    macOS: brew install openjdk@17"
    exit 1
fi

if ! command -v node &> /dev/null; then
    echo "[!] 需要安装Node.js 18+"
    echo "    https://nodejs.org/"
    exit 1
fi

echo "[*] 环境检查通过"

# 安装Capacitor和依赖
echo "[*] 安装依赖..."
npm install
npm install @capacitor/android @capacitor/core @capacitor/cli

# 添加Android平台
echo "[*] 添加Android平台..."
npx cap add android 2>/dev/null || echo "[*] Android平台已存在"

# 同步Web资源
echo "[*] 同步Web资源到Android..."
npx cap sync android

# 构建Release APK
echo "[*] 构建Release APK..."
cd android

# 检查gradlew
if [ ! -f "./gradlew" ]; then
    echo "[!] 未找到gradlew，尝试生成..."
    gradle wrapper
fi

chmod +x ./gradlew

# 构建APK
./gradlew assembleRelease

APK_PATH="app/build/outputs/apk/release/app-release-unsigned.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "[+] APK构建成功!"
    echo "    路径: android/$APK_PATH"
    echo ""
    echo "[*] 签名APK (需要keystore)..."
    echo "    使用命令:"
    echo "    keytool -genkey -v -keystore my.keystore -alias alipayqr -keyalg RSA -validity 10000"
    echo "    jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my.keystore android/$APK_PATH alipayqr"
    echo ""
    echo "[+] 未签名APK可直接在模拟器/调试设备上安装"
    echo "    adb install android/$APK_PATH"
else
    echo "[!] APK构建失败"
    exit 1
fi

echo "========================================"
echo "   Android APK打包完成!"
echo "========================================"
