# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec file for AlipayQR v3.0
# 打包为独立可执行文件

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=['src'],
    binaries=[],
    datas=[
        ('index.html', '.'),
        ('manifest.json', '.'),
        ('sw.js', '.'),
        ('icon-*.png', '.'),
        ('icon.svg', '.'),
    ],
    hiddenimports=[
        'qrcode',
        'PIL',
        'PIL._imagingtk',
        'PIL._tkinter_finder',
        'cryptography',
        'Crypto',
        'Crypto.PublicKey',
        'Crypto.Signature',
        'Crypto.Hash',
        'xml.etree.ElementTree',
        'urllib.request',
        'http.server',
        'socketserver',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
        'tkinter',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='AlipayQR',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='icon-512.png',
)
