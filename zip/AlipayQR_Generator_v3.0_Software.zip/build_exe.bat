@echo off
chcp 65001 >nul
echo ========================================
echo    AlipayQR v3.0 - 打包为EXE软件
echo ========================================
echo.

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [!] 未找到Python，请先安装Python 3.8+
    echo     https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [*] Python已找到

REM 安装依赖
echo [*] 安装打包依赖...
python -m pip install --upgrade pip
python -m pip install pyinstaller qrcode[pil] Pillow pycryptodome cryptography requests

REM 打包为单文件EXE
echo [*] 打包为EXE...
pyinstaller --noconfirm --onefile --windowed ^
    --name "AlipayQR" ^
    --icon "icon-512.png" ^
    --add-data "index.html;." ^
    --add-data "manifest.json;." ^
    --add-data "sw.js;." ^
    --add-data "icon-512.png;." ^
    --add-data "src;src" ^
    --hidden-import qrcode ^
    --hidden-import PIL ^
    --hidden-import PIL._imagingtk ^
    --hidden-import cryptography ^
    --hidden-import Crypto ^
    --hidden-import Crypto.PublicKey ^
    --hidden-import Crypto.Signature ^
    --hidden-import Crypto.Hash ^
    --hidden-import xml.etree.ElementTree ^
    --hidden-import urllib.request ^
    --hidden-import http.server ^
    --hidden-import socketserver ^
    --hidden-import tkinter ^
    --hidden-import tkinter.ttk ^
    --hidden-import tkinter.messagebox ^
    --hidden-import tkinter.filedialog ^
    --hidden-import tkinter.scrolledtext ^
    main.py

if errorlevel 1 (
    echo [!] 打包失败
    pause
    exit /b 1
)

echo.
echo [+] 打包完成!
echo    输出: dist\AlipayQR.exe
echo    双击即可运行，无需安装Python
echo.

REM 创建便携版目录
if not exist "AlipayQR_Portable" mkdir "AlipayQR_Portable"
copy "dist\AlipayQR.exe" "AlipayQR_Portable\"
copy "index.html" "AlipayQR_Portable\"
copy "manifest.json" "AlipayQR_Portable\"
copy "sw.js" "AlipayQR_Portable\"
copy "icon-512.png" "AlipayQR_Portable\"

echo [+] 便携版已创建: AlipayQR_Portable\
echo.
pause
