#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlipayQR v3.0 - 安装向导
交互式安装，自动检测平台并安装
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def print_banner():
    print("""
========================================
         AlipayQR v3.0 安装向导
    多通道聚合收款码生成器
========================================
    """)

def detect_platform():
    system = platform.system()
    machine = platform.machine()
    return system, machine

def check_python():
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"OK Python {version.major}.{version.minor}.{version.micro} 已安装")
        return True
    print(f"FAIL Python版本过低: {version.major}.{version.minor}")
    print("  需要: Python 3.8+")
    return False

def install_python_deps():
    print("\n[*] 安装Python依赖...")
    deps = [
        "qrcode[pil]>=7.0",
        "Pillow>=9.0",
        "pycryptodome>=3.15",
        "cryptography>=3.4",
        "requests>=2.28",
    ]
    for dep in deps:
        print(f"  安装 {dep}...")
        subprocess.run([sys.executable, "-m", "pip", "install", dep], capture_output=True)
    print("OK Python依赖安装完成")

def create_shortcuts(system):
    print("\n[*] 创建快捷方式...")
    base_dir = Path(__file__).parent
    
    if system == "Windows":
        desktop = Path.home() / "Desktop"
        shortcut = desktop / "AlipayQR.lnk"
        ps_cmd = f'''
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("{shortcut}")
        $Shortcut.TargetPath = "{sys.executable}"
        $Shortcut.Arguments = "{base_dir / 'main.py'}"
        $Shortcut.WorkingDirectory = "{base_dir}"
        $Shortcut.IconLocation = "{base_dir / 'icon-512.png'}"
        $Shortcut.Description = "AlipayQR 收款码生成器"
        $Shortcut.Save()
        '''
        subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True)
        print(f"OK 桌面快捷方式已创建: {shortcut}")
    elif system == "Darwin":
        apps_dir = Path.home() / "Applications"
        app_dir = apps_dir / "AlipayQR.app"
        app_dir.mkdir(parents=True, exist_ok=True)
        (app_dir / "Contents").mkdir(exist_ok=True)
        (app_dir / "Contents/MacOS").mkdir(exist_ok=True)
        
        plist = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>AlipayQR</string>
    <key>CFBundleIdentifier</key>
    <string>com.alipayqr.app</string>
    <key>CFBundleName</key>
    <string>AlipayQR</string>
    <key>CFBundleVersion</key>
    <string>3.0.0</string>
</dict>
</plist>'''
        
        with open(app_dir / "Contents/Info.plist", "w") as f:
            f.write(plist)
        
        script = f'''#!/bin/bash
cd "{base_dir}"
{sys.executable} "{base_dir / 'main.py'}"
'''
        with open(app_dir / "Contents/MacOS/AlipayQR", "w") as f:
            f.write(script)
        os.chmod(app_dir / "Contents/MacOS/AlipayQR", 0o755)
        
        print(f"OK macOS应用已创建: {app_dir}")
    elif system == "Linux":
        desktop_dir = Path.home() / ".local/share/applications"
        desktop_dir.mkdir(parents=True, exist_ok=True)
        
        desktop_file = desktop_dir / "alipayqr.desktop"
        content = f'''[Desktop Entry]
Name=AlipayQR
Comment=多通道聚合收款码生成器
Exec={sys.executable} {base_dir / 'main.py'}
Icon={base_dir / 'icon-512.png'}
Terminal=false
Type=Application
Categories=Office;Finance;
'''
        with open(desktop_file, "w") as f:
            f.write(content)
        os.chmod(desktop_file, 0o755)
        
        print(f"OK Linux桌面入口已创建: {desktop_file}")

def main():
    print_banner()
    system, machine = detect_platform()
    print(f"[*] 检测平台: {system} ({machine})\n")
    
    print("[*] 检查环境...")
    python_ok = check_python()
    
    if not python_ok:
        print("\nFAIL 请先安装Python 3.8+")
        print("  Windows: https://www.python.org/downloads/")
        print("  macOS: brew install python3")
        print("  Linux: sudo apt install python3 python3-pip")
        input("\n按回车退出...")
        return
    
    install_python_deps()
    create_shortcuts(system)
    
    print("\n" + "="*40)
    print("OK 安装完成!")
    print("="*40)
    print("\n使用方式:")
    print(f"  1. 双击桌面快捷方式 'AlipayQR'")
    print(f"  2. 命令行: python {Path(__file__).parent / 'main.py'}")
    print(f"  3. Web: 打开 {Path(__file__).parent / 'index.html'}")
    print("\n配置API密钥后即可生成真实支付二维码!")
    print("  - 支付宝: https://open.alipay.com")
    print("  - 微信: https://pay.weixin.qq.com")
    print("  - Stripe: https://dashboard.stripe.com")
    print("")
    input("按回车退出...")

if __name__ == "__main__":
    main()
