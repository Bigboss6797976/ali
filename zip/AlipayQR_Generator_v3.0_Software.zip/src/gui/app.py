#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlipayQR v3.0 - 桌面GUI应用程序
双击即可运行的独立软件

支持平台: Windows / macOS / Linux
"""

import sys
import os
import json
import webbrowser
import threading
import socket
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler

# 尝试导入GUI库
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog, scrolledtext
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False

try:
    import pystray
    from PIL import Image
    PYSTRAY_AVAILABLE = True
except ImportError:
    PYSTRAY_AVAILABLE = False

# 项目路径
BASE_DIR = Path(__file__).parent.parent.parent
WEB_DIR = BASE_DIR / "src" / "ui" / "web"
if not WEB_DIR.exists():
    WEB_DIR = BASE_DIR  # 如果找不到，用根目录

class AlipayQRApp:
    """AlipayQR桌面应用程序"""

    def __init__(self):
        self.server = None
        self.server_thread = None
        self.port = self._find_free_port()
        self.window = None
        self.tray_icon = None

    def _find_free_port(self, start=8080):
        """查找可用端口"""
        for port in range(start, start + 100):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('127.0.0.1', port))
                    return port
            except OSError:
                continue
        return 8080

    def _start_server(self):
        """启动本地Web服务器"""
        os.chdir(str(WEB_DIR))

        class Handler(SimpleHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # 禁用日志

        self.server = HTTPServer(('127.0.0.1', self.port), Handler)
        self.server.serve_forever()

    def start_server(self):
        """在后台线程启动服务器"""
        self.server_thread = threading.Thread(target=self._start_server, daemon=True)
        self.server_thread.start()
        print(f"[+] Web服务器已启动: http://127.0.0.1:{self.port}")

    def stop_server(self):
        """停止服务器"""
        if self.server:
            self.server.shutdown()
            self.server = None

    def open_browser(self):
        """打开浏览器"""
        url = f"http://127.0.0.1:{self.port}"
        webbrowser.open(url)
        print(f"[+] 已打开浏览器: {url}")

    def create_gui(self):
        """创建桌面GUI窗口"""
        if not TKINTER_AVAILABLE:
            print("[!] tkinter不可用，使用命令行模式")
            self.open_browser()
            return

        self.window = tk.Tk()
        self.window.title("AlipayQR v3.0 - 收款码生成器")
        self.window.geometry("500x600")
        self.window.configure(bg='#1677FF')

        # 设置窗口图标
        try:
            icon_path = BASE_DIR / "icon-512.png"
            if icon_path.exists():
                img = tk.PhotoImage(file=str(icon_path))
                self.window.iconphoto(True, img)
        except:
            pass

        # 标题
        title_frame = tk.Frame(self.window, bg='#1677FF')
        title_frame.pack(pady=20)

        title_label = tk.Label(
            title_frame, 
            text="AlipayQR", 
            font=('Arial', 32, 'bold'),
            fg='white',
            bg='#1677FF'
        )
        title_label.pack()

        subtitle = tk.Label(
            title_frame,
            text="多通道聚合收款码生成器 v3.0",
            font=('Arial', 12),
            fg='#e6f4ff',
            bg='#1677FF'
        )
        subtitle.pack()

        # 按钮区域
        btn_frame = tk.Frame(self.window, bg='#1677FF')
        btn_frame.pack(pady=30)

        # 打开Web界面按钮
        web_btn = tk.Button(
            btn_frame,
            text="🌐 打开Web界面",
            font=('Arial', 14, 'bold'),
            bg='white',
            fg='#1677FF',
            width=20,
            height=2,
            command=self.open_browser,
            cursor='hand2',
            relief=tk.FLAT,
            borderwidth=0
        )
        web_btn.pack(pady=10)

        # CLI生成按钮
        cli_btn = tk.Button(
            btn_frame,
            text="⌨️ CLI命令行工具",
            font=('Arial', 14, 'bold'),
            bg='#52c41a',
            fg='white',
            width=20,
            height=2,
            command=self.open_cli,
            cursor='hand2',
            relief=tk.FLAT,
            borderwidth=0
        )
        cli_btn.pack(pady=10)

        # 配置按钮
        config_btn = tk.Button(
            btn_frame,
            text="⚙️ 配置API密钥",
            font=('Arial', 14, 'bold'),
            bg='#faad14',
            fg='white',
            width=20,
            height=2,
            command=self.open_config,
            cursor='hand2',
            relief=tk.FLAT,
            borderwidth=0
        )
        config_btn.pack(pady=10)

        # 快速生成按钮
        quick_btn = tk.Button(
            btn_frame,
            text="⚡ 快速生成收款码",
            font=('Arial', 14, 'bold'),
            bg='#ff4d4f',
            fg='white',
            width=20,
            height=2,
            command=self.quick_generate,
            cursor='hand2',
            relief=tk.FLAT,
            borderwidth=0
        )
        quick_btn.pack(pady=10)

        # 状态信息
        status_frame = tk.Frame(self.window, bg='#1677FF')
        status_frame.pack(pady=20)

        self.status_label = tk.Label(
            status_frame,
            text=f"✅ 服务运行中: http://127.0.0.1:{self.port}",
            font=('Arial', 10),
            fg='#a8e650',
            bg='#1677FF'
        )
        self.status_label.pack()

        # 底部信息
        footer = tk.Label(
            self.window,
            text="支持: 支付宝/微信/Stripe/易支付 | 双击即可运行",
            font=('Arial', 9),
            fg='#b3d1ff',
            bg='#1677FF'
        )
        footer.pack(side=tk.BOTTOM, pady=10)

        # 窗口关闭处理
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)

        # 启动系统托盘
        if PYSTRAY_AVAILABLE:
            self.setup_tray()

        self.window.mainloop()

    def open_cli(self):
        """打开CLI工具窗口"""
        cli_window = tk.Toplevel(self.window)
        cli_window.title("AlipayQR CLI")
        cli_window.geometry("700x500")
        cli_window.configure(bg='#1a1a2e')

        # 命令输入
        cmd_frame = tk.Frame(cli_window, bg='#1a1a2e')
        cmd_frame.pack(fill=tk.X, padx=10, pady=10)

        tk.Label(cmd_frame, text="命令:", fg='#00ff88', bg='#1a1a2e', font=('Courier', 12)).pack(side=tk.LEFT)

        cmd_entry = tk.Entry(cmd_frame, font=('Courier', 12), bg='#16213e', fg='#00ff88', insertbackground='#00ff88')
        cmd_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        cmd_entry.insert(0, "alipayqr --provider alipay --amount 100")

        # 输出区域
        output = scrolledtext.ScrolledText(
            cli_window,
            font=('Courier', 11),
            bg='#0f0f23',
            fg='#00ff88',
            insertbackground='#00ff88'
        )
        output.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        def run_cmd():
            import subprocess
            cmd = cmd_entry.get()
            output.insert(tk.END, f"$ {cmd}\n")
            output.see(tk.END)

            try:
                result = subprocess.run(
                    cmd.split(),
                    capture_output=True,
                    text=True,
                    cwd=str(BASE_DIR),
                    timeout=30
                )
                output.insert(tk.END, result.stdout + "\n")
                if result.stderr:
                    output.insert(tk.END, f"[stderr] {result.stderr}\n")
            except Exception as e:
                output.insert(tk.END, f"[错误] {str(e)}\n")

            output.insert(tk.END, "\n")
            output.see(tk.END)

        run_btn = tk.Button(
            cmd_frame,
            text="运行",
            command=run_cmd,
            bg='#00ff88',
            fg='#1a1a2e',
            font=('Arial', 10, 'bold')
        )
        run_btn.pack(side=tk.LEFT)

    def open_config(self):
        """打开配置窗口"""
        config_window = tk.Toplevel(self.window)
        config_window.title("API配置")
        config_window.geometry("600x700")
        config_window.configure(bg='white')

        # 配置说明
        tk.Label(
            config_window,
            text="配置支付API密钥",
            font=('Arial', 16, 'bold'),
            fg='#1677FF',
            bg='white'
        ).pack(pady=10)

        tk.Label(
            config_window,
            text="配置后生成的二维码可直接扫码支付",
            font=('Arial', 10),
            fg='#666',
            bg='white'
        ).pack()

        # 创建标签页
        notebook = ttk.Notebook(config_window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 支付宝配置
        alipay_frame = tk.Frame(notebook, bg='white')
        notebook.add(alipay_frame, text="💙 支付宝")

        self._create_config_field(alipay_frame, "APPID:", "alipay_appid")
        self._create_config_field(alipay_frame, "私钥文件路径:", "alipay_private_key", is_file=True)
        self._create_config_field(alipay_frame, "公钥文件路径:", "alipay_public_key", is_file=True)

        tk.Label(alipay_frame, text="获取方式: open.alipay.com", fg='#999', bg='white').pack(pady=10)

        # 微信配置
        wechat_frame = tk.Frame(notebook, bg='white')
        notebook.add(wechat_frame, text="💚 微信")

        self._create_config_field(wechat_frame, "商户号(mch_id):", "wechat_mchid")
        self._create_config_field(wechat_frame, "API密钥:", "wechat_key")

        tk.Label(wechat_frame, text="获取方式: pay.weixin.qq.com", fg='#999', bg='white').pack(pady=10)

        # Stripe配置
        stripe_frame = tk.Frame(notebook, bg='white')
        notebook.add(stripe_frame, text="🟣 Stripe")

        self._create_config_field(stripe_frame, "Secret Key:", "stripe_secret")

        tk.Label(stripe_frame, text="获取方式: dashboard.stripe.com", fg='#999', bg='white').pack(pady=10)

        # 保存按钮
        save_btn = tk.Button(
            config_window,
            text="💾 保存配置",
            font=('Arial', 12, 'bold'),
            bg='#1677FF',
            fg='white',
            command=lambda: self.save_config(config_window),
            cursor='hand2'
        )
        save_btn.pack(pady=20)

    def _create_config_field(self, parent, label, key, is_file=False):
        """创建配置输入字段"""
        frame = tk.Frame(parent, bg='white')
        frame.pack(fill=tk.X, padx=10, pady=5)

        tk.Label(frame, text=label, width=15, anchor='e', bg='white').pack(side=tk.LEFT)

        entry = tk.Entry(frame, font=('Arial', 11), width=40)
        entry.pack(side=tk.LEFT, padx=5)

        if is_file:
            def browse():
                path = filedialog.askopenfilename(filetypes=[("PEM files", "*.pem"), ("All files", "*.*")])
                if path:
                    entry.delete(0, tk.END)
                    entry.insert(0, path)

            tk.Button(frame, text="浏览...", command=browse).pack(side=tk.LEFT)

        setattr(self, f"entry_{key}", entry)

    def save_config(self, window):
        """保存配置"""
        config = {
            "alipay": {
                "app_id": getattr(self, 'entry_alipay_appid', tk.Entry()).get(),
                "private_key_path": getattr(self, 'entry_alipay_private_key', tk.Entry()).get(),
                "public_key_path": getattr(self, 'entry_alipay_public_key', tk.Entry()).get(),
            },
            "wechat": {
                "mch_id": getattr(self, 'entry_wechat_mchid', tk.Entry()).get(),
                "api_key": getattr(self, 'entry_wechat_key', tk.Entry()).get(),
            },
            "stripe": {
                "secret_key": getattr(self, 'entry_stripe_secret', tk.Entry()).get(),
            }
        }

        config_path = Path.home() / '.alipayqr' / 'config.json'
        config_path.parent.mkdir(parents=True, exist_ok=True)

        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)

        messagebox.showinfo("成功", "配置已保存！")
        window.destroy()

    def quick_generate(self):
        """快速生成收款码"""
        quick_window = tk.Toplevel(self.window)
        quick_window.title("快速生成收款码")
        quick_window.geometry("400x500")
        quick_window.configure(bg='white')

        tk.Label(quick_window, text="快速生成", font=('Arial', 18, 'bold'), fg='#1677FF', bg='white').pack(pady=20)

        # 金额
        amount_frame = tk.Frame(quick_window, bg='white')
        amount_frame.pack(fill=tk.X, padx=20, pady=10)
        tk.Label(amount_frame, text="金额:", bg='white', font=('Arial', 12)).pack(side=tk.LEFT)
        amount_entry = tk.Entry(amount_frame, font=('Arial', 14), width=20)
        amount_entry.pack(side=tk.LEFT, padx=5)
        amount_entry.insert(0, "100")

        # 通道
        provider_frame = tk.Frame(quick_window, bg='white')
        provider_frame.pack(fill=tk.X, padx=20, pady=10)
        tk.Label(provider_frame, text="通道:", bg='white', font=('Arial', 12)).pack(side=tk.LEFT)
        provider_var = tk.StringVar(value='auto')
        providers = [('🤖 智能路由', 'auto'), ('💙 支付宝', 'alipay'), ('💚 微信', 'wechat'), ('🟣 Stripe', 'stripe')]
        for text, val in providers:
            tk.Radiobutton(provider_frame, text=text, variable=provider_var, value=val, bg='white').pack(anchor='w')

        # 备注
        note_frame = tk.Frame(quick_window, bg='white')
        note_frame.pack(fill=tk.X, padx=20, pady=10)
        tk.Label(note_frame, text="备注:", bg='white', font=('Arial', 12)).pack(side=tk.LEFT)
        note_entry = tk.Entry(note_frame, font=('Arial', 12), width=25)
        note_entry.pack(side=tk.LEFT, padx=5)
        note_entry.insert(0, "收款")

        def generate():
            import subprocess
            cmd = [
                sys.executable, "-m", "cli.alipayqr",
                "--provider", provider_var.get(),
                "--amount", amount_entry.get(),
                "--note", note_entry.get(),
                "--output", str(Path.home() / "Desktop" / "qr_code.png")
            ]

            try:
                result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=30)
                if result.returncode == 0:
                    messagebox.showinfo("成功", f"收款码已生成！\n保存到: Desktop/qr_code.png")
                else:
                    messagebox.showerror("错误", result.stderr)
            except Exception as e:
                messagebox.showerror("错误", str(e))

        generate_btn = tk.Button(
            quick_window,
            text="⚡ 生成收款码",
            font=('Arial', 14, 'bold'),
            bg='#1677FF',
            fg='white',
            command=generate,
            cursor='hand2'
        )
        generate_btn.pack(pady=20)

    def setup_tray(self):
        """设置系统托盘"""
        if not PYSTRAY_AVAILABLE:
            return

        def on_open(icon, item):
            self.open_browser()

        def on_exit(icon, item):
            icon.stop()
            self.on_close()

        try:
            icon_path = BASE_DIR / "icon-512.png"
            if icon_path.exists():
                image = Image.open(str(icon_path))
                image = image.resize((64, 64))
            else:
                image = Image.new('RGB', (64, 64), '#1677FF')

            menu = pystray.Menu(
                pystray.MenuItem("打开 AlipayQR", on_open),
                pystray.MenuItem("退出", on_exit)
            )

            self.tray_icon = pystray.Icon("AlipayQR", image, "AlipayQR v3.0", menu)

            tray_thread = threading.Thread(target=self.tray_icon.run, daemon=True)
            tray_thread.start()
        except Exception as e:
            print(f"[!] 系统托盘初始化失败: {e}")

    def on_close(self):
        """关闭窗口"""
        if self.tray_icon:
            self.tray_icon.stop()
        self.stop_server()
        if self.window:
            self.window.destroy()
        sys.exit(0)

    def run(self):
        """运行应用程序"""
        print("=" * 50)
        print("  AlipayQR v3.0 - 收款码生成器")
        print("=" * 50)
        print(f"[*] 启动Web服务器: http://127.0.0.1:{self.port}")
        print("[*] 正在打开界面...")
        print("[*] 按 Ctrl+C 退出")
        print("")

        self.start_server()

        # 延迟打开浏览器
        import time
        time.sleep(1)

        if TKINTER_AVAILABLE:
            self.create_gui()
        else:
            self.open_browser()
            print("[*] 请在浏览器中使用")
            print("[*] 访问: http://127.0.0.1:{self.port}")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                self.on_close()

def main():
    """主入口"""
    app = AlipayQRApp()
    app.run()

if __name__ == '__main__':
    main()
