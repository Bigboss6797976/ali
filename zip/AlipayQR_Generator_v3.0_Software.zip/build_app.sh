#!/bin/bash
# AlipayQR v3.0 - 打包为应用程序

set -e

echo "========================================"
echo "   AlipayQR v3.0 - 打包为APP"
echo "========================================"
echo ""

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "[!] 未找到Python3"
    exit 1
fi

echo "[*] Python已找到: $(python3 --version)"

# 安装依赖
echo "[*] 安装打包依赖..."
python3 -m pip install --upgrade pip
python3 -m pip install pyinstaller qrcode[pil] Pillow pycryptodome cryptography requests

# 检测平台
PLATFORM=$(uname -s)

echo "[*] 检测到平台: $PLATFORM"

# 打包
if [ "$PLATFORM" = "Darwin" ]; then
    # macOS
    echo "[*] 打包macOS应用..."
    pyinstaller --noconfirm --onefile --windowed \
        --name "AlipayQR" \
        --icon "icon-512.png" \
        --add-data "index.html:." \
        --add-data "manifest.json:." \
        --add-data "sw.js:." \
        --add-data "icon-512.png:." \
        --add-data "src:src" \
        --hidden-import qrcode \
        --hidden-import PIL \
        --hidden-import cryptography \
        --hidden-import Crypto \
        --hidden-import tkinter \
        main.py

    # 创建.app bundle
    echo "[*] 创建.app bundle..."
    mkdir -p "dist/AlipayQR.app/Contents/MacOS"
    mkdir -p "dist/AlipayQR.app/Contents/Resources"

    cp "dist/AlipayQR" "dist/AlipayQR.app/Contents/MacOS/"
    cp "icon-512.png" "dist/AlipayQR.app/Contents/Resources/"

    cat > "dist/AlipayQR.app/Contents/Info.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>AlipayQR</string>
    <key>CFBundleIdentifier</key>
    <string>com.alipayqr.app</string>
    <key>CFBundleName</key>
    <string>AlipayQR</string>
    <key>CFBundleVersion</key>
    <string>3.0.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.14</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
EOF

    echo "[+] macOS应用打包完成!"
    echo "    输出: dist/AlipayQR.app"
    echo "    双击即可运行"

else
    # Linux
    echo "[*] 打包Linux应用..."
    pyinstaller --noconfirm --onefile \
        --name "AlipayQR" \
        --icon "icon-512.png" \
        --add-data "index.html:." \
        --add-data "manifest.json:." \
        --add-data "sw.js:." \
        --add-data "icon-512.png:." \
        --add-data "src:src" \
        --hidden-import qrcode \
        --hidden-import PIL \
        --hidden-import cryptography \
        --hidden-import Crypto \
        main.py

    # 创建AppImage (需要appimagetool)
    if command -v appimagetool &> /dev/null; then
        echo "[*] 创建AppImage..."
        mkdir -p "AlipayQR.AppDir/usr/bin"
        cp "dist/AlipayQR" "AlipayQR.AppDir/usr/bin/"
        cp "icon-512.png" "AlipayQR.AppDir/"

        cat > "AlipayQR.AppDir/AppRun" << 'EOF'
#!/bin/bash
exec "$(dirname "$0")/usr/bin/AlipayQR" "$@"
EOF
        chmod +x "AlipayQR.AppDir/AppRun"

        cat > "AlipayQR.AppDir/AlipayQR.desktop" << EOF
[Desktop Entry]
Name=AlipayQR
Exec=AlipayQR
Icon=icon-512
Type=Application
Categories=Office;Finance;
EOF

        appimagetool "AlipayQR.AppDir" "dist/AlipayQR-x86_64.AppImage"
        echo "[+] AppImage创建完成: dist/AlipayQR-x86_64.AppImage"
    fi

    echo "[+] Linux应用打包完成!"
    echo "    输出: dist/AlipayQR"
    echo "    运行: ./dist/AlipayQR"
fi

echo ""
echo "========================================"
echo "   打包完成!"
echo "========================================"
