import type { SingleCodeSettings, AggregateSettings, PaymentType } from '../types';
import { PAYMENT_LABELS } from '../types';

// 加载图片为Image对象
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

// 将文件转为DataURL
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// 创建圆角矩形路径
export function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

// 绘制圆形clip
export function clipCircle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number
) {
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.closePath();
}

// 绘制圆角方形clip
export function clipRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  radius: number
) {
  roundRectPath(ctx, x - size / 2, y - size / 2, size, size, radius);
}

// 绘制能量球（蚂蚁森林风格）
export function drawEnergyBall(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  text: string,
  color: string = '#52C41A'
) {
  const grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
  grad.addColorStop(0, lightenColor(color, 40));
  grad.addColorStop(0.5, color);
  grad.addColorStop(1, darkenColor(color, 20));

  // 外发光
  const glowGrad = ctx.createRadialGradient(x, y, radius * 0.6, x, y, radius * 1.6);
  glowGrad.addColorStop(0, color + '40');
  glowGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(x, y, radius * 1.6, 0, Math.PI * 2);
  ctx.fill();

  // 主球体
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();

  // 高光
  const highlightGrad = ctx.createRadialGradient(
    x - radius * 0.25,
    y - radius * 0.25,
    0,
    x - radius * 0.25,
    y - radius * 0.25,
    radius * 0.6
  );
  highlightGrad.addColorStop(0, 'rgba(255,255,255,0.7)');
  highlightGrad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = highlightGrad;
  ctx.beginPath();
  ctx.arc(x - radius * 0.1, y - radius * 0.1, radius * 0.5, 0, Math.PI * 2);
  ctx.fill();

  // 文字
  if (text) {
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${Math.max(radius * 0.35, 10)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 2;
    const lines = text.length > 4 ? [text.slice(0, 2), text.slice(2)] : [text];
    lines.forEach((line, i) => {
      const lineY = lines.length === 1 ? y : y + (i - 0.5) * radius * 0.5;
      ctx.fillText(line, x, lineY);
    });
    ctx.shadowBlur = 0;
  }
}

// 绘制阴影
export function drawShadow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  intensity: number
) {
  ctx.save();
  ctx.shadowColor = `rgba(0,0,0,${intensity})`;
  ctx.shadowBlur = 20;
  ctx.shadowOffsetY = 8;
  roundRectPath(ctx, x, y, w, h, r);
  ctx.fillStyle = 'transparent';
  ctx.fill();
  ctx.restore();
}

// 颜色处理工具
export function lightenColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.min(255, ((num >> 16) & 0xff) + Math.round(2.55 * percent));
  const g = Math.min(255, ((num >> 8) & 0xff) + Math.round(2.55 * percent));
  const b = Math.min(255, (num & 0xff) + Math.round(2.55 * percent));
  return `rgb(${r},${g},${b})`;
}

export function darkenColor(hex: string, percent: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.max(0, ((num >> 16) & 0xff) - Math.round(2.55 * percent));
  const g = Math.max(0, ((num >> 8) & 0xff) - Math.round(2.55 * percent));
  const b = Math.max(0, (num & 0xff) - Math.round(2.55 * percent));
  return `rgb(${r},${g},${b})`;
}

export function hexToRgba(hex: string, alpha: number): string {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = (num >> 16) & 0xff;
  const g = (num >> 8) & 0xff;
  const b = num & 0xff;
  return `rgba(${r},${g},${b},${alpha})`;
}

// 绘制渐变背景
export function drawGradientBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  color1: string,
  color2: string,
  direction: 'vertical' | 'horizontal' | 'radial' = 'vertical'
) {
  let grad: CanvasGradient;
  if (direction === 'radial') {
    grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) / 2);
  } else if (direction === 'horizontal') {
    grad = ctx.createLinearGradient(0, 0, w, 0);
  } else {
    grad = ctx.createLinearGradient(0, 0, 0, h);
  }
  grad.addColorStop(0, color1);
  grad.addColorStop(1, color2);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}

// 绘制带logo的QR码卡片（单码美化核心函数）
export async function renderSingleCodeCard(
  canvas: HTMLCanvasElement,
  qrImage: HTMLImageElement,
  logoImage: HTMLImageElement | null,
  settings: SingleCodeSettings
): Promise<void> {
  const ctx = canvas.getContext('2d')!;
  const dpr = 2;
  const W = 600;
  const H = 800;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';
  ctx.scale(dpr, dpr);

  // 清空
  ctx.clearRect(0, 0, W, H);

  // 背景
  if (settings.backgroundStyle === 'gradient') {
    drawGradientBackground(ctx, W, H, settings.primaryColor, settings.secondaryColor, 'vertical');
  } else if (settings.backgroundStyle === 'solid') {
    ctx.fillStyle = settings.primaryColor;
    ctx.fillRect(0, 0, W, H);
  } else {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, W, H);
  }

  // 阴影
  const cardX = 40;
  const cardY = 100;
  const cardW = W - 80;
  const cardH = 580;

  if (settings.shadowIntensity > 0) {
    drawShadow(ctx, cardX, cardY, cardW, cardH, settings.borderRadius, settings.shadowIntensity);
  }

  // 白色卡片背景
  ctx.fillStyle = '#FFFFFF';
  roundRectPath(ctx, cardX, cardY, cardW, cardH, settings.borderRadius);
  ctx.fill();

  // 边框
  if (settings.showBorder) {
    ctx.strokeStyle = settings.borderColor;
    ctx.lineWidth = 1;
    roundRectPath(ctx, cardX, cardY, cardW, cardH, settings.borderRadius);
    ctx.stroke();
  }

  // 能量球装饰
  if (settings.showEnergyBalls) {
    const ballPositions = [
      { x: cardX - 10, y: cardY + cardH * 0.3 },
      { x: cardX + cardW + 10, y: cardY + cardH * 0.2 },
      { x: cardX + cardW + 10, y: cardY + cardH * 0.7 },
      { x: cardX - 10, y: cardY + cardH * 0.6 },
    ];
    const count = Math.min(settings.energyBallCount, ballPositions.length);
    for (let i = 0; i < count; i++) {
      drawEnergyBall(ctx, ballPositions[i].x, ballPositions[i].y, 35, settings.energyBallText, settings.secondaryColor);
    }
  }

  // QR码区域
  const qrSize = 360;
  const qrX = (W - qrSize) / 2;
  const qrY = cardY + 60;

  // QR码背景
  ctx.fillStyle = '#FFFFFF';
  roundRectPath(ctx, qrX - settings.qrPadding / 2, qrY - settings.qrPadding / 2, qrSize + settings.qrPadding, qrSize + settings.qrPadding, 8);
  ctx.fill();
  ctx.strokeStyle = '#F0F0F0';
  ctx.lineWidth = 1;
  roundRectPath(ctx, qrX - settings.qrPadding / 2, qrY - settings.qrPadding / 2, qrSize + settings.qrPadding, qrSize + settings.qrPadding, 8);
  ctx.stroke();

  // 绘制QR码图片（保持正方形）
  const qrImgSize = Math.min(qrImage.width, qrImage.height);
  const sx = (qrImage.width - qrImgSize) / 2;
  const sy = (qrImage.height - qrImgSize) / 2;
  ctx.drawImage(qrImage, sx, sy, qrImgSize, qrImgSize, qrX, qrY, qrSize, qrSize);

  // Logo覆盖
  if (logoImage) {
    const logoSize = settings.logoSize;
    const logoX = W / 2;
    const logoY = qrY + qrSize / 2;

    ctx.save();
    if (settings.logoShape === 'circle') {
      clipCircle(ctx, logoX, logoY, logoSize / 2);
    } else if (settings.logoShape === 'rounded') {
      clipRoundedRect(ctx, logoX, logoY, logoSize, 12);
    } else {
      // square
      ctx.beginPath();
      ctx.rect(logoX - logoSize / 2, logoY - logoSize / 2, logoSize, logoSize);
    }
    ctx.clip();
    ctx.drawImage(logoImage, logoX - logoSize / 2, logoY - logoSize / 2, logoSize, logoSize);
    ctx.restore();

    // Logo边框
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 3;
    if (settings.logoShape === 'circle') {
      ctx.beginPath();
      ctx.arc(logoX, logoY, logoSize / 2, 0, Math.PI * 2);
      ctx.stroke();
    } else if (settings.logoShape === 'rounded') {
      roundRectPath(ctx, logoX - logoSize / 2, logoY - logoSize / 2, logoSize, logoSize, 12);
      ctx.stroke();
    } else {
      ctx.strokeRect(logoX - logoSize / 2, logoY - logoSize / 2, logoSize, logoSize);
    }
  }

  // 支付提示文字
  if (settings.showPaymentText) {
    ctx.fillStyle = settings.primaryColor;
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(settings.paymentText, W / 2, qrY + qrSize + 50);
  }

  // 底部提示
  ctx.fillStyle = hexToRgba('#FFFFFF', 0.85);
  ctx.font = '16px sans-serif';
  ctx.textAlign = 'center';
  const bottomText = '支付得蚂蚁森林能量';
  ctx.fillText(bottomText, W / 2, H - 30);

  // 顶部Logo区域（模拟支付宝风格）
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 20px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('支', cardX + 16, cardY - 14);
  ctx.font = '16px sans-serif';
  ctx.fillText('支付宝', cardX + 42, cardY - 14);
}

// 渲染聚合码
export async function renderAggregateCode(
  canvas: HTMLCanvasElement,
  codes: { image: HTMLImageElement; type: PaymentType; label?: string }[],
  settings: AggregateSettings
): Promise<void> {
  const ctx = canvas.getContext('2d')!;
  const dpr = 2;

  const layouts = {
    horizontal: { cols: codes.length, rows: 1, W: Math.max(800, codes.length * 320), H: 500 },
    vertical: { cols: 1, rows: codes.length, W: 420, H: Math.max(800, codes.length * 360) },
    grid: { cols: Math.min(2, codes.length), rows: Math.ceil(codes.length / 2), W: 720, H: Math.max(600, Math.ceil(codes.length / 2) * 380) },
  };

  const layout = layouts[settings.layout];
  const W = layout.W;
  const H = layout.H + (settings.showTitle ? 80 : 0);

  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  // 背景
  if (settings.backgroundStyle === 'gradient') {
    drawGradientBackground(ctx, W, H, settings.primaryColor, settings.secondaryColor, 'horizontal');
  } else if (settings.backgroundStyle === 'dark') {
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, W, H);
  } else {
    ctx.fillStyle = '#F5F7FA';
    ctx.fillRect(0, 0, W, H);
  }

  // 标题
  if (settings.showTitle) {
    ctx.fillStyle = settings.titleColor;
    ctx.font = 'bold 24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(settings.titleText, W / 2, 40);
  }

  const titleOffset = settings.showTitle ? 80 : 0;
  const cardSize = 280;
  const qrSize = 220;

  codes.forEach((code, index) => {
    const col = index % layout.cols;
    const row = Math.floor(index / layout.cols);

    const availableW = W - settings.gap * 2;
    const availableH = H - titleOffset - settings.gap;
    const stepX = layout.cols > 1 ? availableW / layout.cols : availableW;
    const stepY = layout.rows > 1 ? availableH / layout.rows : availableH;

    const cardX = settings.gap + col * stepX + (stepX - cardSize) / 2;
    const cardY = titleOffset + settings.gap + row * stepY + (stepY - cardSize) / 2;

    // 卡片阴影
    drawShadow(ctx, cardX, cardY, cardSize, cardSize + 40, settings.borderRadius, 0.1);

    // 卡片背景
    ctx.fillStyle = '#FFFFFF';
    roundRectPath(ctx, cardX, cardY, cardSize, cardSize + 40, settings.borderRadius);
    ctx.fill();

    // 能量球
    if (settings.showEnergyBalls) {
      const ballOffset = 20;
      const label = PAYMENT_LABELS[code.type];
      drawEnergyBall(ctx, cardX - ballOffset, cardY + cardSize * 0.3, 28, '绿色能量', label.color);
      drawEnergyBall(ctx, cardX + cardSize + ballOffset, cardY + cardSize * 0.6, 24, '能量', label.color);
    }

    // QR码
    const qrX = cardX + (cardSize - qrSize) / 2;
    const qrY = cardY + 20;
    const imgSize = Math.min(code.image.width, code.image.height);
    const sx = (code.image.width - imgSize) / 2;
    const sy = (code.image.height - imgSize) / 2;
    ctx.drawImage(code.image, sx, sy, imgSize, imgSize, qrX, qrY, qrSize, qrSize);

    // 标签
    if (settings.showLabels) {
      const label = PAYMENT_LABELS[code.type];
      const labelY = qrY + qrSize + 30;

      if (settings.labelStyle === 'badge') {
        const badgeW = 100;
        const badgeH = 32;
        const badgeX = cardX + (cardSize - badgeW) / 2;
        ctx.fillStyle = label.bgColor;
        roundRectPath(ctx, badgeX, labelY - badgeH / 2, badgeW, badgeH, 16);
        ctx.fill();
        ctx.fillStyle = label.color;
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label.name, cardX + cardSize / 2, labelY + 4);
      } else if (settings.labelStyle === 'underline') {
        ctx.fillStyle = label.color;
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label.name, cardX + cardSize / 2, labelY);
        ctx.strokeStyle = label.color;
        ctx.lineWidth = 2;
        const tw = ctx.measureText(label.name).width;
        ctx.beginPath();
        ctx.moveTo(cardX + cardSize / 2 - tw / 2, labelY + 8);
        ctx.lineTo(cardX + cardSize / 2 + tw / 2, labelY + 8);
        ctx.stroke();
      }
    }
  });
}

// 下载Canvas为图片
export function downloadCanvas(canvas: HTMLCanvasElement, filename: string) {
  const link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL('image/png', 1.0);
  link.click();
}

// 批量生成8种风格
export async function generateBatchStyles(
  qrImage: HTMLImageElement,
  logoImage: HTMLImageElement | null
): Promise<{ name: string; canvas: HTMLCanvasElement }[]> {
  const templates: { template: SingleCodeSettings['template']; name: string }[] = [
    { template: 'default', name: '经典蓝' },
    { template: 'gradient', name: '渐变紫' },
    { template: 'dark', name: '暗夜黑' },
    { template: 'neon', name: '霓虹炫' },
    { template: 'minimal', name: '极简白' },
    { template: 'festive', name: '喜庆红' },
    { template: 'business', name: '商务金' },
    { template: 'cartoon', name: '卡通彩' },
  ];

  const results: { name: string; canvas: HTMLCanvasElement }[] = [];

  for (const t of templates) {
    const canvas = document.createElement('canvas');
    const preset = {
      ...getTemplatePreset(t.template),
      template: t.template,
    };
    await renderSingleCodeCard(canvas, qrImage, logoImage, preset);
    results.push({ name: t.name, canvas });
  }

  return results;
}

function getTemplatePreset(template: SingleCodeSettings['template']): SingleCodeSettings {
  const presets: Record<string, SingleCodeSettings> = {
    default: {
      ...getBaseSettings(),
      template: 'default',
      primaryColor: '#1677FF',
      secondaryColor: '#52C41A',
      showEnergyBalls: true,
      energyBallText: '绿色能量',
      paymentText: '打开支付宝[扫一扫]',
    },
    gradient: {
      ...getBaseSettings(),
      template: 'gradient',
      primaryColor: '#722ED1',
      secondaryColor: '#EB2F96',
      backgroundStyle: 'gradient',
      showEnergyBalls: true,
      energyBallText: '紫色能量',
      paymentText: '扫码支付',
    },
    dark: {
      ...getBaseSettings(),
      template: 'dark',
      primaryColor: '#262626',
      secondaryColor: '#434343',
      backgroundStyle: 'solid',
      showEnergyBalls: true,
      energyBallText: '能量',
      paymentText: '扫码支付',
    },
    neon: {
      ...getBaseSettings(),
      template: 'neon',
      primaryColor: '#0D1117',
      secondaryColor: '#00E5FF',
      backgroundStyle: 'solid',
      showEnergyBalls: true,
      energyBallText: 'NEON',
      paymentText: 'Scan to Pay',
    },
    minimal: {
      ...getBaseSettings(),
      template: 'minimal',
      primaryColor: '#FAFAFA',
      secondaryColor: '#ECECEC',
      backgroundStyle: 'solid',
      showEnergyBalls: false,
      paymentText: '扫码支付',
    },
    festive: {
      ...getBaseSettings(),
      template: 'festive',
      primaryColor: '#CF1322',
      secondaryColor: '#FF4D4F',
      backgroundStyle: 'gradient',
      showEnergyBalls: true,
      energyBallText: '福',
      paymentText: '恭喜发财',
    },
    business: {
      ...getBaseSettings(),
      template: 'business',
      primaryColor: '#D48806',
      secondaryColor: '#FAAD14',
      backgroundStyle: 'solid',
      showEnergyBalls: true,
      energyBallText: '财富',
      paymentText: '扫码付款',
    },
    cartoon: {
      ...getBaseSettings(),
      template: 'cartoon',
      primaryColor: '#13C2C2',
      secondaryColor: '#36CFC9',
      backgroundStyle: 'gradient',
      showEnergyBalls: true,
      energyBallText: '快乐',
      paymentText: '扫一扫~',
    },
  };
  return presets[template] || presets.default;
}

function getBaseSettings(): SingleCodeSettings {
  return {
    template: 'default',
    primaryColor: '#1677FF',
    secondaryColor: '#52C41A',
    showEnergyBalls: true,
    energyBallCount: 3,
    energyBallText: '绿色能量',
    logoShape: 'circle',
    logoSize: 64,
    borderRadius: 16,
    showPaymentText: true,
    paymentText: '打开支付宝[扫一扫]',
    backgroundStyle: 'solid',
    qrPadding: 24,
    showBorder: true,
    borderColor: '#E8E8E8',
    shadowIntensity: 0.15,
  };
}

// ZIP打包下载（使用原生Blob）
export async function downloadAsZip(
  items: { name: string; dataUrl: string }[]
) {
  // 简化为逐个下载
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const link = document.createElement('a');
    link.download = `${item.name}.png`;
    link.href = item.dataUrl;
    setTimeout(() => link.click(), i * 200);
  }
}
