import { useState } from 'react';
import { Header } from './components/Header';
import { SingleCodeMode } from './components/SingleCodeMode';
import { AggregateMode } from './components/AggregateMode';
import { BatchMode } from './components/BatchMode';
import { Footer } from './components/Footer';
import type { WorkMode } from './types';
import './App.css';

function App() {
  const [mode, setMode] = useState<WorkMode>('single');

  return (
    <div className="min-h-screen bg-gray-50/50">
      <Header currentMode={mode} onModeChange={setMode} />
      
      <main className="max-w-6xl mx-auto px-4 py-6">
        {mode === 'single' && <SingleCodeMode />}
        {mode === 'aggregate' && <AggregateMode />}
        {mode === 'batch' && <BatchMode />}
      </main>

      <Footer />
    </div>
  );
}

export default App;
