import { useState, useRef, useEffect, useCallback } from 'react';
import { Download, Sparkles, RefreshCw, ImagePlus } from 'lucide-react';
import { UploadArea } from './UploadArea';
import type { SingleCodeSettings } from '../types';
import { DEFAULT_SINGLE_SETTINGS, TEMPLATE_PRESETS } from '../types';
import { renderSingleCodeCard, loadImage, downloadCanvas } from '../utils/canvasUtils';
import { useImageUpload } from '../hooks/useImageUpload';

export function SingleCodeMode() {
  const {
    images: qrImages,
    isDragging: qrDragging,
    handleFiles: handleQrFiles,
    handleDragOver: qrDragOver,
    handleDragLeave: qrDragLeave,
    handleDrop: qrDrop,
    removeImage: removeQrImage,
  } = useImageUpload();

  const {
    images: logoImages,
    isDragging: logoDragging,
    handleFiles: handleLogoFiles,
    handleDragOver: logoDragOver,
    handleDragLeave: logoDragLeave,
    handleDrop: logoDrop,
    removeImage: removeLogoImage,
  } = useImageUpload();

  const [settings, setSettings] = useState<SingleCodeSettings>(DEFAULT_SINGLE_SETTINGS);
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  const generatePreview = useCallback(async () => {
    if (qrImages.length === 0 || !previewCanvasRef.current) return;
    try {
      const qrImg = await loadImage(qrImages[0].dataUrl);
      let logoImg = null;
      if (logoImages.length > 0) {
        logoImg = await loadImage(logoImages[0].dataUrl);
      }
      await renderSingleCodeCard(previewCanvasRef.current, qrImg, logoImg, settings);
    } catch (e) {
      console.error('Preview generation failed:', e);
    }
  }, [qrImages, logoImages, settings]);

  useEffect(() => {
    generatePreview();
  }, [generatePreview]);

  const handleDownload = async () => {
    if (!canvasRef.current || qrImages.length === 0) return;
    setIsGenerating(true);
    try {
      const qrImg = await loadImage(qrImages[0].dataUrl);
      let logoImg = null;
      if (logoImages.length > 0) {
        logoImg = await loadImage(logoImages[0].dataUrl);
      }
      await renderSingleCodeCard(canvasRef.current, qrImg, logoImg, settings);
      downloadCanvas(canvasRef.current, `能量码_${settings.template}_${Date.now()}.png`);
    } finally {
      setIsGenerating(false);
    }
  };

  const applyTemplate = (template: SingleCodeSettings['template']) => {
    const preset = TEMPLATE_PRESETS[template];
    setSettings(prev => ({
      ...prev,
      template,
      primaryColor: preset.colors[0],
      secondaryColor: preset.colors[1],
    }));
  };

  const hasQrCode = qrImages.length > 0;

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* 左侧：上传与设置 */}
        <div className="lg:col-span-2 space-y-5">
          {/* 步骤1：上传收款码 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-blue-500 text-white flex items-center justify-center text-sm font-bold">1</div>
              <h3 className="font-semibold text-gray-800">上传收款码</h3>
            </div>
            <UploadArea
              onFileSelect={handleQrFiles}
              onDragOver={qrDragOver}
              onDragLeave={qrDragLeave}
              onDrop={qrDrop}
              isDragging={qrDragging}
              uploadedImages={qrImages}
              onRemove={removeQrImage}
              acceptMultiple={false}
              label="点击或拖拽上传收款码图片"
            />
          </div>

          {/* 步骤2：上传Logo（可选） */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-purple-500 text-white flex items-center justify-center text-sm font-bold">2</div>
              <h3 className="font-semibold text-gray-800">中心Logo（可选）</h3>
            </div>
            <UploadArea
              onFileSelect={handleLogoFiles}
              onDragOver={logoDragOver}
              onDragLeave={logoDragLeave}
              onDrop={logoDrop}
              isDragging={logoDragging}
              uploadedImages={logoImages}
              onRemove={removeLogoImage}
              acceptMultiple={false}
              label="上传头像或Logo"
              compact
            />
            {logoImages.length > 0 && (
              <div className="mt-3 flex gap-2">
                {(['circle', 'square', 'rounded'] as const).map((shape) => (
                  <button
                    key={shape}
                    onClick={() => setSettings(p => ({ ...p, logoShape: shape }))}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      settings.logoShape === shape
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {shape === 'circle' ? '圆形' : shape === 'square' ? '方形' : '圆角'}
                  </button>
                ))}
                <div className="flex items-center gap-2 ml-auto">
                  <span className="text-xs text-gray-500">大小</span>
                  <input
                    type="range"
                    min="32"
                    max="120"
                    value={settings.logoSize}
                    onChange={(e) => setSettings(p => ({ ...p, logoSize: Number(e.target.value) }))}
                    className="w-20"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 步骤3：样式设置 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-green-500 text-white flex items-center justify-center text-sm font-bold">3</div>
              <h3 className="font-semibold text-gray-800">样式设置</h3>
            </div>

            {/* 模板选择 */}
            <div className="mb-4">
              <label className="text-xs font-medium text-gray-500 mb-2 block">选择模板</label>
              <div className="grid grid-cols-4 gap-2">
                {(Object.keys(TEMPLATE_PRESETS) as Array<keyof typeof TEMPLATE_PRESETS>).map((key) => {
                  const preset = TEMPLATE_PRESETS[key];
                  return (
                    <button
                      key={key}
                      onClick={() => applyTemplate(key)}
                      className={`relative rounded-xl p-2.5 transition-all border-2 ${
                        settings.template === key
                          ? 'border-blue-500 shadow-md scale-[1.02]'
                          : 'border-transparent hover:border-gray-200'
                      }`}
                      style={{ background: `linear-gradient(135deg, ${preset.colors[0]}15, ${preset.colors[1]}15)` }}
                    >
                      <div className="flex flex-col items-center gap-1">
                        <div
                          className="w-6 h-6 rounded-full"
                          style={{ background: `linear-gradient(135deg, ${preset.colors[0]}, ${preset.colors[1]})` }}
                        />
                        <span className="text-[10px] font-medium text-gray-700 leading-tight">{preset.name}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 颜色设置 */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">主色调</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={settings.primaryColor}
                    onChange={(e) => setSettings(p => ({ ...p, primaryColor: e.target.value }))}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs text-gray-600 font-mono">{settings.primaryColor}</span>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">能量色</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={settings.secondaryColor}
                    onChange={(e) => setSettings(p => ({ ...p, secondaryColor: e.target.value }))}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs text-gray-600 font-mono">{settings.secondaryColor}</span>
                </div>
              </div>
            </div>

            {/* 能量球设置 */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-500">能量球装饰</label>
                <button
                  onClick={() => setSettings(p => ({ ...p, showEnergyBalls: !p.showEnergyBalls }))}
                  className={`w-10 h-5 rounded-full transition-colors relative ${
                    settings.showEnergyBalls ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
                      settings.showEnergyBalls ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
              {settings.showEnergyBalls && (
                <>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">能量球数量</label>
                    <input
                      type="range"
                      min="1"
                      max="4"
                      value={settings.energyBallCount}
                      onChange={(e) => setSettings(p => ({ ...p, energyBallCount: Number(e.target.value) }))}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">能量文字</label>
                    <input
                      type="text"
                      value={settings.energyBallText}
                      onChange={(e) => setSettings(p => ({ ...p, energyBallText: e.target.value }))}
                      className="w-full px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-blue-400"
                      placeholder="绿色能量"
                    />
                  </div>
                </>
              )}
            </div>

            {/* 文字设置 */}
            <div className="mt-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-500">显示支付提示</label>
                <button
                  onClick={() => setSettings(p => ({ ...p, showPaymentText: !p.showPaymentText }))}
                  className={`w-10 h-5 rounded-full transition-colors relative ${
                    settings.showPaymentText ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
                      settings.showPaymentText ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
              {settings.showPaymentText && (
                <input
                  type="text"
                  value={settings.paymentText}
                  onChange={(e) => setSettings(p => ({ ...p, paymentText: e.target.value }))}
                  className="w-full px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-blue-400"
                  placeholder="打开支付宝[扫一扫]"
                />
              )}
            </div>

            {/* 背景样式 */}
            <div className="mt-4">
              <label className="text-xs font-medium text-gray-500 mb-2 block">背景样式</label>
              <div className="flex gap-2">
                {(['solid', 'gradient', 'transparent'] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => setSettings(p => ({ ...p, backgroundStyle: style }))}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      settings.backgroundStyle === style
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {style === 'solid' ? '纯色' : style === 'gradient' ? '渐变' : '透明'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 右侧：实时预览 */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 sticky top-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <h3 className="font-semibold text-gray-800">实时预览</h3>
              </div>
              <div className="flex gap-2">
                {hasQrCode && (
                  <button
                    onClick={handleDownload}
                    disabled={isGenerating}
                    className="flex items-center gap-1.5 px-4 py-2 bg-blue-500 text-white rounded-xl text-sm font-medium hover:bg-blue-600 disabled:opacity-50 transition-colors shadow-sm"
                  >
                    {isGenerating ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    下载图片
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center justify-center bg-gray-50 rounded-xl p-4 min-h-[500px]">
              {hasQrCode ? (
                <canvas
                  ref={previewCanvasRef}
                  className="max-w-full rounded-lg shadow-lg"
                />
              ) : (
                <div className="flex flex-col items-center text-gray-400">
                  <div className="w-20 h-20 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
                    <ImagePlus className="w-10 h-10" />
                  </div>
                  <p className="text-sm">上传收款码后预览效果</p>
                </div>
              )}
            </div>

            {hasQrCode && (
              <p className="text-xs text-gray-400 text-center mt-3">
                预览已自动更新，点击「下载图片」保存高清版本
              </p>
            )}
          </div>
        </div>
      </div>

      {/* 隐藏的高清输出canvas */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
