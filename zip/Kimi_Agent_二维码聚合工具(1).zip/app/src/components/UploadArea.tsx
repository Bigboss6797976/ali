import { Upload, X, ImagePlus } from 'lucide-react';
import type { PaymentType } from '../types';
import { PAYMENT_LABELS } from '../types';

interface UploadAreaProps {
  onFileSelect: (files: FileList | null, type?: PaymentType) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent, type?: PaymentType) => void;
  isDragging: boolean;
  uploadedImages: { id: string; dataUrl: string; type: PaymentType; name: string }[];
  onRemove: (id: string) => void;
  acceptMultiple?: boolean;
  paymentType?: PaymentType;
  label?: string;
  compact?: boolean;
}

export function UploadArea({
  onFileSelect,
  onDragOver,
  onDragLeave,
  onDrop,
  isDragging,
  uploadedImages,
  onRemove,
  acceptMultiple = false,
  paymentType,
  label,
  compact = false,
}: UploadAreaProps) {
  const typeColor = paymentType ? PAYMENT_LABELS[paymentType].color : '#1677FF';

  if (compact) {
    return (
      <div className="w-full">
        {uploadedImages.length === 0 ? (
          <label
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={(e) => onDrop(e, paymentType)}
            className={`flex flex-col items-center justify-center border-2 border-dashed rounded-xl cursor-pointer transition-all duration-200 ${
              isDragging
                ? 'border-blue-400 bg-blue-50 scale-[1.02]'
                : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
            }`}
            style={{ minHeight: 120 }}
          >
            <input
              type="file"
              accept="image/*"
              multiple={acceptMultiple}
              className="hidden"
              onChange={(e) => onFileSelect(e.target.files, paymentType)}
            />
            <ImagePlus className="w-8 h-8 mb-2" style={{ color: typeColor }} />
            <span className="text-sm font-medium" style={{ color: typeColor }}>
              {label || '点击或拖拽上传'}
            </span>
          </label>
        ) : (
          <div className="flex flex-wrap gap-2">
            {uploadedImages.map((img) => (
              <div key={img.id} className="relative group">
                <img
                  src={img.dataUrl}
                  alt={img.name}
                  className="w-20 h-20 object-cover rounded-lg border border-gray-200"
                />
                <button
                  onClick={() => onRemove(img.id)}
                  className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                >
                  <X className="w-3 h-3" />
                </button>
                <span
                  className="absolute bottom-0 left-0 right-0 text-[10px] text-white text-center py-0.5 rounded-b-lg font-medium"
                  style={{ backgroundColor: typeColor + 'CC' }}
                >
                  {PAYMENT_LABELS[img.type].name}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full">
      <div
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={(e) => onDrop(e, paymentType)}
        className={`relative border-2 border-dashed rounded-2xl p-8 transition-all duration-200 ${
          isDragging
            ? 'border-blue-400 bg-blue-50/50 scale-[1.01]'
            : uploadedImages.length === 0
            ? 'border-gray-300 hover:border-gray-400 bg-gray-50/50'
            : 'border-green-300 bg-green-50/30'
        }`}
      >
        {uploadedImages.length === 0 ? (
          <label className="flex flex-col items-center justify-center cursor-pointer py-4">
            <input
              type="file"
              accept="image/*"
              multiple={acceptMultiple}
              className="hidden"
              onChange={(e) => onFileSelect(e.target.files, paymentType)}
            />
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 transition-transform"
              style={{ backgroundColor: typeColor + '15' }}
            >
              <Upload className="w-8 h-8" style={{ color: typeColor }} />
            </div>
            <p className="text-base font-medium text-gray-700 mb-1">
              {label || '点击或拖拽上传收款码图片'}
            </p>
            <p className="text-sm text-gray-400">支持 JPG、PNG、GIF、WEBP</p>
          </label>
        ) : (
          <div className="flex flex-wrap gap-3 justify-center">
            {uploadedImages.map((img) => (
              <div key={img.id} className="relative group">
                <img
                  src={img.dataUrl}
                  alt={img.name}
                  className="w-24 h-24 object-cover rounded-xl border-2 border-white shadow-md"
                />
                <button
                  onClick={() => onRemove(img.id)}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:bg-red-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            <label className="w-24 h-24 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors">
              <input
                type="file"
                accept="image/*"
                multiple={acceptMultiple}
                className="hidden"
                onChange={(e) => onFileSelect(e.target.files, paymentType)}
              />
              <ImagePlus className="w-6 h-6 text-gray-400" />
            </label>
          </div>
        )}
      </div>
    </div>
  );
}
