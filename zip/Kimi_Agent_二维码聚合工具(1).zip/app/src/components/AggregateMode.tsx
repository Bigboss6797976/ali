import { useState, useRef, useEffect, useCallback } from 'react';
import { Download, Layers, RefreshCw, ImagePlus } from 'lucide-react';
import { UploadArea } from './UploadArea';
import type { AggregateSettings, PaymentType, UploadedImage } from '../types';
import { DEFAULT_AGGREGATE_SETTINGS, PAYMENT_LABELS } from '../types';
import { renderAggregateCode, loadImage, downloadCanvas } from '../utils/canvasUtils';
import { useImageUpload } from '../hooks/useImageUpload';

const PAYMENT_TYPES: { type: PaymentType; label: string }[] = [
  { type: 'alipay', label: '支付宝' },
  { type: 'wechat', label: '微信支付' },
  { type: 'unionpay', label: '云闪付' },
];

export function AggregateMode() {
  const uploadHooks = {
    alipay: useImageUpload(),
    wechat: useImageUpload(),
    unionpay: useImageUpload(),
  };

  const [settings, setSettings] = useState<AggregateSettings>(DEFAULT_AGGREGATE_SETTINGS);
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  const generatePreview = useCallback(async () => {
    const codes = [] as { image: any; type: PaymentType }[];
    for (const pt of PAYMENT_TYPES) {
      for (const img of uploadHooks[pt.type].images) {
        codes.push({ image: img, type: pt.type });
      }
    }
    if (codes.length === 0 || !previewCanvasRef.current) return;

    try {
      const loadedImages = [] as { image: HTMLImageElement; type: PaymentType }[];
      for (const c of codes) {
        const img = await loadImage((c.image as UploadedImage).dataUrl);
        loadedImages.push({ image: img, type: c.type });
      }
      await renderAggregateCode(previewCanvasRef.current, loadedImages, settings);
    } catch (e) {
      console.error('Aggregate preview failed:', e);
    }
  }, [uploadHooks, settings]);

  useEffect(() => {
    generatePreview();
  }, [generatePreview]);

  const handleDownload = async () => {
    if (!canvasRef.current) return;
    const codes = [] as { image: any; type: PaymentType }[];
    for (const pt of PAYMENT_TYPES) {
      for (const img of uploadHooks[pt.type].images) {
        codes.push({ image: img, type: pt.type });
      }
    }
    if (codes.length === 0) return;

    setIsGenerating(true);
    try {
      const loadedImages = [] as { image: HTMLImageElement; type: PaymentType }[];
      for (const c of codes) {
        const img = await loadImage((c.image as UploadedImage).dataUrl);
        loadedImages.push({ image: img, type: c.type });
      }
      await renderAggregateCode(canvasRef.current, loadedImages, settings);
      downloadCanvas(canvasRef.current, `聚合能量码_${Date.now()}.png`);
    } finally {
      setIsGenerating(false);
    }
  };

  const totalCodes = PAYMENT_TYPES.reduce((sum, pt) => sum + uploadHooks[pt.type].images.length, 0);

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* 左侧：上传与设置 */}
        <div className="lg:col-span-2 space-y-5">
          {/* 上传各支付码 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-blue-500 text-white flex items-center justify-center text-sm font-bold">1</div>
              <h3 className="font-semibold text-gray-800">上传各支付码</h3>
            </div>
            <div className="space-y-4">
              {PAYMENT_TYPES.map(({ type, label }) => {
                const hook = uploadHooks[type];
                const config = PAYMENT_LABELS[type];
                return (
                  <div key={type} className="border border-gray-100 rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="w-5 h-5 rounded-md flex items-center justify-center text-white text-[10px] font-bold"
                        style={{ backgroundColor: config.color }}
                      >
                        {label[0]}
                      </div>
                      <span className="text-sm font-medium text-gray-700">{label}</span>
                      {hook.images.length > 0 && (
                        <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ backgroundColor: config.bgColor, color: config.color }}>
                          {hook.images.length}
                        </span>
                      )}
                    </div>
                    <UploadArea
                      onFileSelect={hook.handleFiles}
                      onDragOver={hook.handleDragOver}
                      onDragLeave={hook.handleDragLeave}
                      onDrop={hook.handleDrop}
                      isDragging={hook.isDragging}
                      uploadedImages={hook.images}
                      onRemove={hook.removeImage}
                      acceptMultiple={false}
                      paymentType={type}
                      label={`上传${label}收款码`}
                      compact
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* 布局与样式设置 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-green-500 text-white flex items-center justify-center text-sm font-bold">2</div>
              <h3 className="font-semibold text-gray-800">布局与样式</h3>
            </div>

            {/* 布局选择 */}
            <div className="mb-4">
              <label className="text-xs font-medium text-gray-500 mb-2 block">排列方式</label>
              <div className="flex gap-2">
                {(['horizontal', 'vertical', 'grid'] as const).map((layout) => (
                  <button
                    key={layout}
                    onClick={() => setSettings(p => ({ ...p, layout }))}
                    className={`flex-1 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                      settings.layout === layout
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {layout === 'horizontal' ? '横排' : layout === 'vertical' ? '竖排' : '网格'}
                  </button>
                ))}
              </div>
            </div>

            {/* 颜色 */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">主色调</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={settings.primaryColor}
                    onChange={(e) => setSettings(p => ({ ...p, primaryColor: e.target.value }))}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs text-gray-600 font-mono">{settings.primaryColor}</span>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">辅助色</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={settings.secondaryColor}
                    onChange={(e) => setSettings(p => ({ ...p, secondaryColor: e.target.value }))}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs text-gray-600 font-mono">{settings.secondaryColor}</span>
                </div>
              </div>
            </div>

            {/* 背景 */}
            <div className="mb-4">
              <label className="text-xs font-medium text-gray-500 mb-2 block">背景样式</label>
              <div className="flex gap-2">
                {(['solid', 'gradient', 'dark'] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => setSettings(p => ({ ...p, backgroundStyle: style }))}
                    className={`flex-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      settings.backgroundStyle === style
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {style === 'solid' ? '浅色' : style === 'gradient' ? '渐变' : '深色'}
                  </button>
                ))}
              </div>
            </div>

            {/* 标签样式 */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-medium text-gray-500">显示标签</label>
                <button
                  onClick={() => setSettings(p => ({ ...p, showLabels: !p.showLabels }))}
                  className={`w-10 h-5 rounded-full transition-colors relative ${
                    settings.showLabels ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
                      settings.showLabels ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
              {settings.showLabels && (
                <div className="flex gap-2">
                  {(['badge', 'underline', 'none'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => setSettings(p => ({ ...p, labelStyle: style }))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        settings.labelStyle === style
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {style === 'badge' ? '徽章' : style === 'underline' ? '下划线' : '隐藏'}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 能量球 */}
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-medium text-gray-500">能量球装饰</label>
              <button
                onClick={() => setSettings(p => ({ ...p, showEnergyBalls: !p.showEnergyBalls }))}
                className={`w-10 h-5 rounded-full transition-colors relative ${
                  settings.showEnergyBalls ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
                    settings.showEnergyBalls ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            {/* 标题 */}
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-gray-500">显示标题</label>
              <button
                onClick={() => setSettings(p => ({ ...p, showTitle: !p.showTitle }))}
                className={`w-10 h-5 rounded-full transition-colors relative ${
                  settings.showTitle ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
                    settings.showTitle ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
            {settings.showTitle && (
              <input
                type="text"
                value={settings.titleText}
                onChange={(e) => setSettings(p => ({ ...p, titleText: e.target.value }))}
                className="w-full px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-blue-400"
                placeholder="请选择支付方式"
              />
            )}

            {/* 间距 */}
            <div className="mt-4">
              <label className="text-xs text-gray-500 mb-1 block">码间距</label>
              <input
                type="range"
                min="12"
                max="48"
                value={settings.gap}
                onChange={(e) => setSettings(p => ({ ...p, gap: Number(e.target.value) }))}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* 右侧：预览 */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 sticky top-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-500" />
                <h3 className="font-semibold text-gray-800">聚合预览</h3>
                {totalCodes > 0 && (
                  <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full">
                    {totalCodes}个码
                  </span>
                )}
              </div>
              {totalCodes > 0 && (
                <button
                  onClick={handleDownload}
                  disabled={isGenerating}
                  className="flex items-center gap-1.5 px-4 py-2 bg-blue-500 text-white rounded-xl text-sm font-medium hover:bg-blue-600 disabled:opacity-50 transition-colors shadow-sm"
                >
                  {isGenerating ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  下载聚合码
                </button>
              )}
            </div>

            <div className="flex items-center justify-center bg-gray-50 rounded-xl p-4 min-h-[400px] overflow-auto">
              {totalCodes > 0 ? (
                <canvas
                  ref={previewCanvasRef}
                  className="max-w-full rounded-lg shadow-lg"
                />
              ) : (
                <div className="flex flex-col items-center text-gray-400">
                  <div className="w-20 h-20 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
                    <ImagePlus className="w-10 h-10" />
                  </div>
                  <p className="text-sm">上传至少一个收款码开始预览</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
