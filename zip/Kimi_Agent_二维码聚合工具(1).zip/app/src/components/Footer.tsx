import { Shield, Info, Leaf } from 'lucide-react';
import { useState } from 'react';

export function Footer() {
  const [showHelp, setShowHelp] = useState(false);

  return (
    <footer className="w-full border-t border-gray-100 mt-12">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-gray-500">
              <Leaf className="w-4 h-4 text-green-500" />
              <span className="text-sm">能量码生成器 v3.0</span>
            </div>
            <span className="text-gray-300">|</span>
            <div className="flex items-center gap-1.5 text-gray-500">
              <Shield className="w-3.5 h-3.5" />
              <span className="text-xs">纯前端处理，图片不上传服务器</span>
            </div>
          </div>
          <button
            onClick={() => setShowHelp(!showHelp)}
            className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-500 transition-colors"
          >
            <Info className="w-4 h-4" />
            使用说明
          </button>
        </div>

        {showHelp && (
          <div className="mt-4 bg-blue-50/50 rounded-xl p-4 border border-blue-100">
            <h4 className="font-semibold text-gray-800 mb-2 text-sm">关于「免密/无人脸」说明</h4>
            <p className="text-xs text-gray-600 leading-relaxed mb-2">
              本工具仅负责美化收款码图片，无法控制支付端的风控策略。支付APP（支付宝/微信）是否要求密码、人脸或指纹，取决于：
            </p>
            <ul className="text-xs text-gray-600 space-y-1 ml-4 list-disc">
              <li>用户设置的免密额度</li>
              <li>支付金额大小</li>
              <li>账户安全等级与设备信任状态</li>
            </ul>
            <p className="text-xs text-gray-500 mt-2">
              工具生成的只是美观、清晰、可被正确识别的二维码图片。扫描后的支付流程由支付平台控制。
            </p>
          </div>
        )}
      </div>
    </footer>
  );
}
