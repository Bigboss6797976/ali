import { useState, useRef, useCallback } from 'react';
import { Download, Package, RefreshCw, ImagePlus } from 'lucide-react';
import { UploadArea } from './UploadArea';
import { useImageUpload } from '../hooks/useImageUpload';
import { loadImage, renderSingleCodeCard } from '../utils/canvasUtils';
import { TEMPLATE_PRESETS } from '../types';
import type { SingleCodeSettings } from '../types';

interface BatchResult {
  name: string;
  template: string;
  dataUrl: string;
  primaryColor: string;
  secondaryColor: string;
}

export function BatchMode() {
  const {
    images: qrImages,
    isDragging: qrDragging,
    handleFiles: handleQrFiles,
    handleDragOver: qrDragOver,
    handleDragLeave: qrDragLeave,
    handleDrop: qrDrop,
    removeImage: removeQrImage,
  } = useImageUpload();

  const {
    images: logoImages,
    handleFiles: handleLogoFiles,
    handleDragOver: logoDragOver,
    handleDragLeave: logoDragLeave,
    handleDrop: logoDrop,
    removeImage: removeLogoImage,
  } = useImageUpload();

  const [results, setResults] = useState<BatchResult[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingProgress, setGeneratingProgress] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const generateBatch = useCallback(async () => {
    if (qrImages.length === 0 || !canvasRef.current) return;
    setIsGenerating(true);
    setGeneratingProgress(0);
    setResults([]);

    try {
      const qrImg = await loadImage(qrImages[0].dataUrl);
      let logoImg = null;
      if (logoImages.length > 0) {
        logoImg = await loadImage(logoImages[0].dataUrl);
      }

      const templates = Object.entries(TEMPLATE_PRESETS).map(([key, preset]) => ({
        template: key as SingleCodeSettings['template'],
        name: preset.name,
        colors: preset.colors as [string, string],
      }));

      const newResults: BatchResult[] = [];

      for (let i = 0; i < templates.length; i++) {
        const t = templates[i];
        const settings: SingleCodeSettings = {
          template: t.template,
          primaryColor: t.colors[0],
          secondaryColor: t.colors[1],
          showEnergyBalls: t.template !== 'minimal',
          energyBallCount: 3,
          energyBallText: t.template === 'festive' ? '福' : t.template === 'business' ? '财富' : t.template === 'cartoon' ? '快乐' : t.template === 'neon' ? 'NEON' : '绿色能量',
          logoShape: 'circle',
          logoSize: 64,
          borderRadius: 16,
          showPaymentText: true,
          paymentText: t.template === 'festive' ? '恭喜发财' : t.template === 'business' ? '扫码付款' : t.template === 'cartoon' ? '扫一扫~' : t.template === 'neon' ? 'Scan to Pay' : '打开支付宝[扫一扫]',
          backgroundStyle: t.template === 'gradient' || t.template === 'cartoon' ? 'gradient' : 'solid',
          qrPadding: 24,
          showBorder: true,
          borderColor: '#E8E8E8',
          shadowIntensity: 0.15,
        };

        await renderSingleCodeCard(canvasRef.current, qrImg, logoImg, settings);
        const dataUrl = canvasRef.current.toDataURL('image/png', 1.0);

        newResults.push({
          name: t.name,
          template: t.template,
          dataUrl,
          primaryColor: t.colors[0],
          secondaryColor: t.colors[1],
        });

        setGeneratingProgress(Math.round(((i + 1) / templates.length) * 100));
      }

      setResults(newResults);
    } catch (e) {
      console.error('Batch generation failed:', e);
    } finally {
      setIsGenerating(false);
    }
  }, [qrImages, logoImages]);

  const downloadAll = () => {
    results.forEach((result, index) => {
      setTimeout(() => {
        const link = document.createElement('a');
        link.download = `能量码_${result.name}_${Date.now()}.png`;
        link.href = result.dataUrl;
        link.click();
      }, index * 300);
    });
  };

  const downloadSingle = (result: BatchResult) => {
    const link = document.createElement('a');
    link.download = `能量码_${result.name}_${Date.now()}.png`;
    link.href = result.dataUrl;
    link.click();
  };

  const hasQrCode = qrImages.length > 0;

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* 左侧：上传与控制 */}
        <div className="lg:col-span-2 space-y-5">
          {/* 上传收款码 */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-blue-500 text-white flex items-center justify-center text-sm font-bold">1</div>
              <h3 className="font-semibold text-gray-800">上传收款码</h3>
            </div>
            <UploadArea
              onFileSelect={handleQrFiles}
              onDragOver={qrDragOver}
              onDragLeave={qrDragLeave}
              onDrop={qrDrop}
              isDragging={qrDragging}
              uploadedImages={qrImages}
              onRemove={removeQrImage}
              acceptMultiple={false}
              label="点击或拖拽上传收款码图片"
            />
          </div>

          {/* Logo（可选） */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-purple-500 text-white flex items-center justify-center text-sm font-bold">2</div>
              <h3 className="font-semibold text-gray-800">中心Logo（可选）</h3>
            </div>
            <UploadArea
              onFileSelect={handleLogoFiles}
              onDragOver={logoDragOver}
              onDragLeave={logoDragLeave}
              onDrop={logoDrop}
              isDragging={false}
              uploadedImages={logoImages}
              onRemove={removeLogoImage}
              acceptMultiple={false}
              label="上传头像或Logo"
              compact
            />
          </div>

          {/* 生成按钮 */}
          <button
            onClick={generateBatch}
            disabled={!hasQrCode || isGenerating}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl font-semibold text-lg shadow-lg hover:from-blue-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                生成中 {generatingProgress}%
              </>
            ) : results.length > 0 ? (
              <>
                <RefreshCw className="w-5 h-5" />
                重新生成
              </>
            ) : (
              <>
                <Package className="w-5 h-5" />
                生成8种风格
              </>
            )}
          </button>

          {isGenerating && (
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div
                className="bg-blue-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${generatingProgress}%` }}
              />
            </div>
          )}

          {results.length > 0 && !isGenerating && (
            <button
              onClick={downloadAll}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-green-500 text-white rounded-2xl font-medium hover:bg-green-600 transition-colors shadow-sm"
            >
              <Download className="w-5 h-5" />
              全部下载 ({results.length}张)
            </button>
          )}
        </div>

        {/* 右侧：结果预览 */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Package className="w-4 h-4 text-purple-500" />
              <h3 className="font-semibold text-gray-800">
                生成结果
                {results.length > 0 && (
                  <span className="ml-2 text-sm font-normal text-gray-500">{results.length}种风格</span>
                )}
              </h3>
            </div>

            {results.length > 0 ? (
              <div className="grid grid-cols-2 gap-4 max-h-[700px] overflow-y-auto pr-1">
                {results.map((result) => (
                  <div
                    key={result.template}
                    className="group relative bg-gray-50 rounded-xl p-3 border border-gray-100 hover:border-blue-200 hover:shadow-md transition-all"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-4 h-4 rounded-full"
                          style={{ background: `linear-gradient(135deg, ${result.primaryColor}, ${result.secondaryColor})` }}
                        />
                        <span className="text-sm font-medium text-gray-700">{result.name}</span>
                      </div>
                      <button
                        onClick={() => downloadSingle(result)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <img
                      src={result.dataUrl}
                      alt={result.name}
                      className="w-full rounded-lg border border-gray-200 cursor-pointer hover:scale-[1.02] transition-transform"
                      onClick={() => downloadSingle(result)}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <div className="w-20 h-20 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
                  {isGenerating ? (
                    <RefreshCw className="w-10 h-10 animate-spin text-blue-400" />
                  ) : (
                    <ImagePlus className="w-10 h-10" />
                  )}
                </div>
                <p className="text-sm">
                  {isGenerating ? '正在生成多种风格...' : hasQrCode ? '点击「生成8种风格」按钮' : '请先上传收款码'}
                </p>
                {isGenerating && (
                  <p className="text-xs text-gray-400 mt-2">进度: {generatingProgress}%</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
