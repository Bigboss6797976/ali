import { Leaf } from 'lucide-react';
import type { WorkMode } from '../types';

interface HeaderProps {
  currentMode: WorkMode;
  onModeChange: (mode: WorkMode) => void;
}

const MODES: { id: WorkMode; label: string; description: string }[] = [
  { id: 'single', label: '单码美化', description: '上传收款码，选择模板生成精美二维码' },
  { id: 'aggregate', label: '聚合能量码', description: '多支付码合一，生成聚合收款图' },
  { id: 'batch', label: '批量生成', description: '一键生成8种不同风格' },
];

export function Header({ currentMode, onModeChange }: HeaderProps) {
  return (
    <header className="w-full">
      {/* 顶部标题栏 */}
      <div className="max-w-6xl mx-auto px-4 pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-lg shadow-green-200">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 tracking-tight">能量码生成器</h1>
              <p className="text-xs text-gray-500">一码多付 · 智能美化 · 即时可用</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 bg-green-50 text-green-700 text-xs font-semibold rounded-full border border-green-200">
              v3.0
            </span>
          </div>
        </div>
      </div>

      {/* 模式选择标签 */}
      <div className="border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex gap-1">
            {MODES.map((mode) => {
              const isActive = currentMode === mode.id;
              return (
                <button
                  key={mode.id}
                  onClick={() => onModeChange(mode.id)}
                  className={`relative px-5 py-3.5 text-sm font-medium transition-all rounded-t-xl ${
                    isActive
                      ? 'text-blue-600'
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-blue-500 rounded-full" />
                  )}
                  {mode.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 模式描述 */}
      <div className="bg-gray-50/50 border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <p className="text-sm text-gray-500">
            {MODES.find(m => m.id === currentMode)?.description}
          </p>
        </div>
      </div>
    </header>
  );
}
