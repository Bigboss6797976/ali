import { useState, useCallback } from 'react';
import type { UploadedImage, PaymentType } from '../types';
import { fileToDataUrl } from '../utils/canvasUtils';

export function useImageUpload() {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleFiles = useCallback(async (files: FileList | null, type?: PaymentType) => {
    if (!files) return;
    const newImages: UploadedImage[] = [];
    for (const file of Array.from(files)) {
      if (!file.type.startsWith('image/')) continue;
      try {
        const dataUrl = await fileToDataUrl(file);
        newImages.push({
          id: Math.random().toString(36).slice(2),
          file,
          dataUrl,
          type: type || inferPaymentType(file.name),
          name: file.name,
        });
      } catch (e) {
        console.error('Failed to load image:', e);
      }
    }
    setImages(prev => [...prev, ...newImages]);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, type?: PaymentType) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files, type);
  }, [handleFiles]);

  const removeImage = useCallback((id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  }, []);

  const clearImages = useCallback(() => {
    setImages([]);
  }, []);

  return {
    images,
    isDragging,
    handleFiles,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    removeImage,
    clearImages,
  };
}

function inferPaymentType(filename: string): PaymentType {
  const lower = filename.toLowerCase();
  if (lower.includes('alipay') || lower.includes('支付宝') || lower.includes('zfb')) return 'alipay';
  if (lower.includes('wechat') || lower.includes('微信') || lower.includes('wx')) return 'wechat';
  if (lower.includes('union') || lower.includes('云闪付') || lower.includes('ysf')) return 'unionpay';
  return 'alipay';
}
