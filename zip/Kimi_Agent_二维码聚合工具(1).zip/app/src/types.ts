export type WorkMode = 'single' | 'aggregate' | 'batch';

export type PaymentType = 'alipay' | 'wechat' | 'unionpay';

export type LogoShape = 'circle' | 'square' | 'rounded';

export type TemplateStyle = 'default' | 'gradient' | 'dark' | 'neon' | 'minimal' | 'festive' | 'business' | 'cartoon';

export interface UploadedImage {
  id: string;
  file: File;
  dataUrl: string;
  type: PaymentType;
  name: string;
}

export interface SingleCodeSettings {
  template: TemplateStyle;
  primaryColor: string;
  secondaryColor: string;
  showEnergyBalls: boolean;
  energyBallCount: number;
  energyBallText: string;
  logoShape: LogoShape;
  logoSize: number;
  borderRadius: number;
  showPaymentText: boolean;
  paymentText: string;
  backgroundStyle: 'solid' | 'gradient' | 'transparent';
  qrPadding: number;
  showBorder: boolean;
  borderColor: string;
  shadowIntensity: number;
}

export interface AggregateSettings {
  layout: 'horizontal' | 'vertical' | 'grid';
  primaryColor: string;
  secondaryColor: string;
  showEnergyBalls: boolean;
  showLabels: boolean;
  labelStyle: 'none' | 'badge' | 'underline';
  backgroundStyle: 'solid' | 'gradient' | 'dark';
  gap: number;
  borderRadius: number;
  showTitle: boolean;
  titleText: string;
  titleColor: string;
}

export interface BatchSettings {
  showEnergyBalls: boolean;
  logoShape: LogoShape;
  logoSize: number;
  includeOriginal: boolean;
}

export const DEFAULT_SINGLE_SETTINGS: SingleCodeSettings = {
  template: 'default',
  primaryColor: '#1677FF',
  secondaryColor: '#52C41A',
  showEnergyBalls: true,
  energyBallCount: 3,
  energyBallText: '绿色能量',
  logoShape: 'circle',
  logoSize: 64,
  borderRadius: 16,
  showPaymentText: true,
  paymentText: '打开支付宝[扫一扫]',
  backgroundStyle: 'solid',
  qrPadding: 24,
  showBorder: true,
  borderColor: '#E8E8E8',
  shadowIntensity: 0.15,
};

export const DEFAULT_AGGREGATE_SETTINGS: AggregateSettings = {
  layout: 'horizontal',
  primaryColor: '#1677FF',
  secondaryColor: '#52C41A',
  showEnergyBalls: true,
  showLabels: true,
  labelStyle: 'badge',
  backgroundStyle: 'solid',
  gap: 24,
  borderRadius: 16,
  showTitle: true,
  titleText: '请选择支付方式',
  titleColor: '#333333',
};

export const TEMPLATE_PRESETS: Record<TemplateStyle, { name: string; colors: [string, string]; description: string }> = {
  default: { name: '经典蓝', colors: ['#1677FF', '#52C41A'], description: '支付宝经典蓝色风格' },
  gradient: { name: '渐变紫', colors: ['#722ED1', '#EB2F96'], description: '梦幻紫粉渐变' },
  dark: { name: '暗夜黑', colors: ['#262626', '#434343'], description: '高端深色商务风' },
  neon: { name: '霓虹炫', colors: ['#00E5FF', '#FF4081'], description: '赛博朋克霓虹风' },
  minimal: { name: '极简白', colors: ['#FAFAFA', '#ECECEC'], description: '简约纯白设计' },
  festive: { name: '喜庆红', colors: ['#CF1322', '#FF4D4F'], description: '节日红色喜庆' },
  business: { name: '商务金', colors: ['#D48806', '#FAAD14'], description: '金色商务质感' },
  cartoon: { name: '卡通彩', colors: ['#13C2C2', '#36CFC9'], description: '活泼卡通风格' },
};

export const PAYMENT_LABELS: Record<PaymentType, { name: string; color: string; bgColor: string }> = {
  alipay: { name: '支付宝', color: '#1677FF', bgColor: '#E6F4FF' },
  wechat: { name: '微信支付', color: '#07C160', bgColor: '#E6FFF0' },
  unionpay: { name: '云闪付', color: '#C41E3A', bgColor: '#FFF0F2' },
};
