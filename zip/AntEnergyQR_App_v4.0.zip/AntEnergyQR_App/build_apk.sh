#!/bin/bash
# build_apk.sh - 构建蚂蚁能量收款码 APK

echo "=========================================="
echo "  蚂蚁能量收款码 APK 构建脚本"
echo "=========================================="

# 检查环境
if ! command -v node &> /dev/null; then
    echo "❌ Node.js 未安装"
    echo "运行: pkg install nodejs"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "❌ npm 未安装"
    exit 1
fi

# 安装 Cordova（如果未安装）
if ! command -v cordova &> /dev/null; then
    echo "📦 安装 Cordova..."
    npm install -g cordova
fi

# 进入项目目录
cd "$(dirname "$0")"

# 安装依赖
echo "📦 安装项目依赖..."
npm install

# 添加 Android 平台
echo "📱 添加 Android 平台..."
cordova platform add android@12.0.0

# 构建 APK
echo "🔨 构建 APK..."
cordova build android --release

# 检查构建结果
APK_PATH="platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "✅ APK 构建成功!"
    echo "📁 路径: $APK_PATH"
    echo ""
    echo "下一步: 签名 APK"
    echo "1. 生成密钥: keytool -genkey -v -keystore antenergy.keystore -alias antenergy -keyalg RSA -validity 10000"
    echo "2. 签名: jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore antenergy.keystore $APK_PATH antenergy"
    echo "3. 优化: zipalign -v 4 app-release-unsigned.apk AntEnergyQR.apk"
else
    echo "❌ APK 构建失败"
    exit 1
fi
