# 图标和启动屏

## 需要添加的文件

### 图标 (www/img/logo.png)
- 尺寸: 1024x1024px
- 格式: PNG
- 建议: 绿色背景 + 白色二维码图标

### 启动屏 (www/img/splash.png)
- 尺寸: 2732x2732px
- 格式: PNG
- 建议: 深色背景 + App名称 + 版本号

## 快速生成（可选）
可以用在线工具生成：
- https://appicon.co/
- https://www.photopea.com/

或者直接用默认的（Cordova会使用默认图标）
