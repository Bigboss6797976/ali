#!/bin/bash
# termux_build.sh - Termux 快速构建

echo "🚀 开始构建蚂蚁能量收款码 APK..."

# 安装必要包
echo "📦 检查依赖..."
pkg update -y
pkg install -y nodejs openjdk-17 gradle

# 安装 Cordova
npm install -g cordova

# 进入项目目录
cd "$(dirname "$0")"

# 安装依赖
npm install

# 添加平台并构建
cordova platform add android
cordova build android

# 复制 APK 到下载目录
APK="platforms/android/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    cp "$APK" /storage/emulated/0/Download/AntEnergyQR_v4.apk
    echo "✅ APK 已保存到: /storage/emulated/0/Download/AntEnergyQR_v4.apk"
else
    echo "❌ 构建失败"
fi
