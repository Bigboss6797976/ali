# 蚂蚁能量收款码生成器 App v4.0

## 功能
- 🔍 智能提取：从截图自动识别收款二维码
- 🎨 官方模板：支付宝蓝/微信绿/云闪付红
- 👤 自定义头像：二维码中心添加头像/Logo
- 🌿 蚂蚁能量：绿色能量标签
- 🔗 聚合码：一码多付
- 👥 多人扫码：支持同时多人支付
- 📦 批量生成：8种风格一键打包

## 构建 APK

### 方式1：Termux 一键构建
```bash
cd AntEnergyQR_App
bash termux_build.sh
```

### 方式2：手动构建
```bash
cd AntEnergyQR_App
npm install
cordova platform add android
cordova build android
```

## 安装
构建完成后 APK 在：
- `platforms/android/app/build/outputs/apk/debug/app-debug.apk`
- 或下载目录: `/storage/emulated/0/Download/AntEnergyQR_v4.apk`

## 技术栈
- Cordova + HTML5 + Canvas
- 纯前端，无需后端服务器
