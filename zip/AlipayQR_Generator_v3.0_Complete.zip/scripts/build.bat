@echo off
echo ========================================
echo    AlipayQR v3.0 - 全平台构建
echo ========================================
echo.

set PLATFORM=%1
if "%PLATFORM%"=="" set PLATFORM=all

if "%PLATFORM%"=="web" goto :web
if "%PLATFORM%"=="all" goto :web

:web
echo [*] Web/PWA版本...
echo [+] Web版本已就绪
echo    访问: %CD%\index.html
echo.

if "%PLATFORM%"=="web" goto :end

:desktop
echo [*] 构建桌面端...
if not exist node_modules npm install
npm run build:win
echo [+] Windows桌面端构建完成
echo.

if "%PLATFORM%"=="desktop" goto :end

:android
echo [*] 构建 Android...
npx cap sync android
cd android
if exist gradlew.bat (
    gradlew.bat assembleRelease
    echo [+] Android APK构建完成
) else (
    echo [!] 请先运行: npx cap add android
)
cd ..
echo.

:end
echo ========================================
echo    构建完成！
echo ========================================
pause
