# -*- coding: utf-8 -*-
"""图标生成脚本 - 生成所有平台需要的图标尺寸"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_base_icon(size=512):
    """创建支付宝风格的蓝色图标"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    radius = size // 8
    draw.rounded_rectangle(
        [(0, 0), (size, size)],
        radius=radius,
        fill=(22, 119, 255, 255)
    )

    try:
        font_size = int(size * 0.55)
        font = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc", font_size)
    except:
        try:
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            font = ImageFont.load_default()

    text = "支"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    x = (size - text_width) // 2
    y = (size - text_height) // 2 - bbox[1] // 2

    draw.text((x, y), text, fill=(255, 255, 255, 255), font=font)

    return img

def generate_all_icons(output_dir='./assets/icons'):
    """生成所有需要的图标尺寸"""
    os.makedirs(output_dir, exist_ok=True)

    sizes = {
        'icon-72.png': 72,
        'icon-96.png': 96,
        'icon-128.png': 128,
        'icon-144.png': 144,
        'icon-152.png': 152,
        'icon-192.png': 192,
        'icon-384.png': 384,
        'icon-512.png': 512,
        'favicon.ico': 32,
        'apple-touch-icon.png': 180,
    }

    base = create_base_icon(512)

    for filename, size in sizes.items():
        icon = base.resize((size, size), Image.LANCZOS)
        filepath = os.path.join(output_dir, filename)

        if filename.endswith('.ico'):
            icon.save(filepath, format='ICO', sizes=[(size, size)])
        else:
            icon.save(filepath, 'PNG')

        print(f"Generated: {filename} ({size}x{size})")

    print(f"
All icons saved to: {output_dir}")
    return output_dir

if __name__ == '__main__':
    generate_all_icons()
