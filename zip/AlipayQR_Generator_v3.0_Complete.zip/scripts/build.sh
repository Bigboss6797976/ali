#!/bin/bash
# AlipayQR v3.0 - 全平台构建脚本

set -e

PLATFORM=${1:-all}

echo "========================================"
echo "   AlipayQR v3.0 - 全平台构建"
echo "========================================"
echo ""

case $PLATFORM in
    web|all)
        echo "[*] 构建 Web/PWA 版本..."
        echo "[+] Web版本已就绪"
        echo "   访问: file://$(pwd)/index.html"
        echo "   或: python -m http.server 8080"
        ;;
esac

case $PLATFORM in
    desktop|all)
        echo "[*] 构建桌面端..."
        if ! command -v npm &> /dev/null; then
            echo "[!] 需要安装 Node.js"
            exit 1
        fi
        npm install
        npm run build:win 2>/dev/null || echo "   Windows构建跳过"
        npm run build:mac 2>/dev/null || echo "   macOS构建跳过"
        npm run build:linux 2>/dev/null || echo "   Linux构建跳过"
        echo "[+] 桌面端构建完成"
        ;;
esac

case $PLATFORM in
    android|all)
        echo "[*] 构建 Android APK..."
        if ! command -v npx &> /dev/null; then
            echo "[!] 需要安装 Node.js"
            exit 1
        fi
        npx cap sync android
        cd android
        if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease
            echo "[+] Android APK构建完成"
            echo "   输出: android/app/build/outputs/apk/release/"
        else
            echo "[!] 请先运行: npx cap add android"
        fi
        cd ..
        ;;
esac

case $PLATFORM in
    ios|all)
        echo "[*] 构建 iOS..."
        if [[ "$OSTYPE" != "darwin"* ]]; then
            echo "[!] iOS构建需要macOS"
        else
            npx cap sync ios
            cd ios/App
            xcodebuild -workspace App.xcworkspace -scheme App -configuration Release
            echo "[+] iOS构建完成"
        fi
        ;;
esac

case $PLATFORM in
    docker)
        echo "[*] 构建 Docker镜像..."
        docker-compose build
        echo "[+] Docker镜像构建完成"
        echo "   运行: docker-compose up -d"
        ;;
esac

echo ""
echo "========================================"
echo "   构建完成！"
echo "========================================"
