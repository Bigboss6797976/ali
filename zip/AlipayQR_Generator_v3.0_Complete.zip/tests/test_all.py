# -*- coding: utf-8 -*-
"""测试套件"""

import pytest
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.config import ConfigManager
from core.qr_engine import QREngine
from core.crypto import CryptoUtil
from payments.router import SmartRouter

class TestConfigManager:
    def test_set_get(self):
        config = ConfigManager()
        config.set('test.key', 'value')
        assert config.get('test.key') == 'value'

    def test_default_value(self):
        config = ConfigManager()
        assert config.get('nonexistent.key', 'default') == 'default'

class TestQREngine:
    def test_generate_alipay(self):
        engine = QREngine()
        result = engine.generate(
            provider='alipay',
            amount=100,
            note='测试',
            output='/tmp/test_qr.png'
        )
        assert result['provider'] == 'alipay'
        assert 'qr_url' in result
        assert os.path.exists('/tmp/test_qr.png')

    def test_generate_auto_route(self):
        engine = QREngine()
        result = engine.generate(
            provider='auto',
            amount=50,
            output='/tmp/test_auto.png'
        )
        assert 'qr_url' in result

class TestSmartRouter:
    def test_small_amount(self):
        router = SmartRouter()
        assert router.select(50) == 'easypay'

    def test_medium_amount(self):
        router = SmartRouter()
        assert router.select(500) == 'alipay'

    def test_large_amount(self):
        router = SmartRouter()
        assert router.select(10000) == 'stripe'

    def test_route_info(self):
        router = SmartRouter()
        info = router.get_route_info(1000)
        assert 'estimated_fee' in info
        assert info['provider'] == 'alipay'

class TestCryptoUtil:
    def test_md5_sign(self):
        params = {"pid": "1000", "type": "alipay", "money": "100"}
        sign = CryptoUtil.md5_sign(params, "test_key")
        assert len(sign) == 32
        assert sign.isupper()

    def test_nonce_str(self):
        nonce = CryptoUtil.generate_nonce_str()
        assert len(nonce) == 32
