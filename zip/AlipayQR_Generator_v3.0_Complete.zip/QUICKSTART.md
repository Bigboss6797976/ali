# AlipayQR v3.0 - 快速启动指南

## 🚀 5分钟快速开始

### 方式1: Web浏览器 (最快)
```bash
# 1. 下载项目
# 2. 双击 index.html 或用浏览器打开
# 3. 完成！支持添加到主屏幕

# 或启动本地服务器
python -m http.server 8080
# 访问 http://localhost:8080
```

### 方式2: 一键安装 (推荐)

**Windows:**
```powershell
# 右键以管理员运行
.\install.ps1
```

**macOS/Linux:**
```bash
chmod +x install.sh
./install.sh
```

### 方式3: pip安装
```bash
pip install alipayqr
alipayqr --help
```

## 📱 各平台使用

### Web/PWA
1. 用Chrome/Safari打开 `index.html`
2. 点击地址栏"安装"按钮
3. 添加到主屏幕
4. 离线可用

### iOS
1. Safari打开网页
2. 点击分享 → "添加到主屏幕"
3. 像原生App一样使用

### Android
1. Chrome打开网页
2. 点击菜单 → "添加到主屏幕"
3. 或点击"安装应用"弹窗

### 桌面端 (Windows/Mac/Linux)
```bash
# 构建桌面应用
npm install
npm run build

# 运行
# Windows: dist-electron/AlipayQR.exe
# macOS: dist-electron/AlipayQR.app
# Linux: dist-electron/AlipayQR.AppImage
```

### CLI命令行
```bash
# 生成收款码
alipayqr --provider alipay --amount 100 --note "测试"

# 智能路由
alipayqr --provider auto --amount 5000

# 解析二维码
alipayqr --parse qr.png
```

## ⚙️ 配置API密钥

1. 复制 `config/config.example.json` 为 `config.json`
2. 填入你的API密钥
3. 保存后重新启动

## 🧪 测试
```bash
pytest tests/test_full.py -v
```

## 📚 更多文档
- [API文档](docs/API.md)
- [CLI文档](docs/CLI.md)
- [部署指南](docs/DEPLOY.md)
