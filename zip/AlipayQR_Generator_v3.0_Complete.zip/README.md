# AlipayQR v3.0 🚀

多通道聚合收款码生成器 - 支持 **Web / iOS / Android / 平板 / 桌面端 / CLI**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Node.js 18+](https://img.shields.io/badge/node-18+-green.svg)](https://nodejs.org/)

## ✨ 12大功能特性

| # | 功能 | 说明 | 状态 |
|---|------|------|------|
| 1 | 🔍 **抓取解析** | `--parse existing_qr.png` 识别现有收款码URL | ✅ |
| 2 | 👤 **自定义账号** | 替换为你自己的支付宝/微信/Stripe账号 | ✅ |
| 3 | 💙 **支付宝官方** | 直接对接 `alipay.trade.precreate` | ✅ |
| 4 | 🟢 **易支付** | 第三方聚合支付，D+0到账 | ✅ |
| 5 | 💚 **微信官方** | Native扫码支付 | ✅ |
| 6 | 🟣 **Stripe** | 国际支付，多币种 | ✅ |
| 7 | 🤖 **智能路由** | 小额→易支付，中额→支付宝，大额→Stripe | ✅ |
| 8 | 🔐 **真实API签名** | RSA2/MD5签名生成 | ✅ |
| 9 | ♾️ **固定可用** | 二维码永久有效 | ✅ |
| 10 | ⚡ **免密支付** | 支付宝标准免密流程 | ✅ |
| 11 | 🎨 **样式自由** | `--avatar head.jpg` 自定义头像 | ✅ |
| 12 | ⌨️ **命令行工具** | 完整CLI参数支持 | ✅ |

## 🚀 快速开始

### 方式1: 直接打开 (Web)
```bash
# 下载后双击 index.html
# 或启动服务器
python -m http.server 8080
```

### 方式2: 一键安装
```bash
# Windows (PowerShell管理员)
.\install.ps1

# macOS/Linux
chmod +x install.sh && ./install.sh
```

### 方式3: pip安装
```bash
pip install alipayqr
alipayqr --provider alipay --amount 100
```

## 📱 平台支持

| 平台 | 安装方式 | 离线可用 |
|------|----------|----------|
| Web/PWA | 浏览器打开 | ✅ |
| iOS | Safari添加到主屏幕 | ✅ |
| Android | Chrome添加到主屏幕 | ✅ |
| iPad/平板 | 自动适配 | ✅ |
| Windows | 双击 start.bat | ✅ |
| macOS | ./start.sh | ✅ |
| Linux | ./start.sh | ✅ |
| 桌面应用 | Electron打包 | ✅ |

## 💻 CLI命令示例

```bash
# 生成支付宝收款码
alipayqr --provider alipay --amount 100 --note "测试订单"

# 智能路由自动选择
alipayqr --provider auto --amount 5000 --recipient "商家"

# 解析现有二维码
alipayqr --parse existing_qr.png

# 自定义账号+头像
alipayqr --provider alipay --amount 88.88 \
  --account "your@email.com" --avatar head.jpg

# 易支付通道
alipayqr --provider easypay --amount 50 --config easypay.json

# 微信Native支付
alipayqr --provider wechat --amount 200 \
  --mch_id 123456 --api_key xxx

# Stripe国际支付
alipayqr --provider stripe --amount 99.99 \
  --currency usd --stripe_key sk_live_xxx

# 免密支付+永久有效
alipayqr --provider alipay --amount 10 \
  --no-password --permanent
```

## 🛡️ 安全特性

- ✅ **AES-256加密** - 配置本地加密存储
- ✅ **RSA2签名** - 支付宝官方签名算法
- ✅ **MD5签名** - 易支付/微信签名验证
- ✅ **盲签支持** - 隐私保护签名
- ✅ **离线签名** - 无需联网生成签名
- ✅ **沙箱环境** - 安全测试不扣款

## 📦 项目结构

```
AlipayQR_Generator/
├── index.html              # Web/PWA主入口
├── manifest.json           # PWA配置
├── sw.js                   # Service Worker(离线)
├── main.py                 # Python入口
├── src/
│   ├── cli/                # 命令行工具
│   │   └── alipayqr.py     # CLI主程序
│   ├── core/               # 核心模块
│   │   ├── qr_engine.py    # 二维码引擎
│   │   ├── crypto.py       # 加密工具
│   │   └── config.py       # 配置管理(AES-256)
│   ├── payments/           # 支付通道
│   │   ├── alipay.py       # 支付宝API
│   │   ├── wechat.py       # 微信支付
│   │   ├── stripe_pay.py   # Stripe国际
│   │   ├── easypay.py      # 易支付
│   │   └── router.py       # 智能路由
│   └── utils/              # 工具模块
│       ├── qr_parser.py    # 二维码解析
│       ├── offline_sign.py # 离线签名
│       ├── blind_sign.py   # 盲签
│       ├── batch_generator.py  # 批量生成
│       ├── payment_monitor.py  # 支付监控
│       └── analytics.py    # 数据统计
├── tests/                  # 测试套件
├── docs/                   # 文档
├── android/                # Android项目
├── ios/                    # iOS项目
├── scripts/                # 构建脚本
└── config/                 # 配置文件
```

## 📚 文档

- [快速开始](QUICKSTART.md)
- [API文档](docs/API.md)
- [CLI文档](docs/CLI.md)
- [部署指南](docs/DEPLOY.md)
- [移动端安装](MOBILE_INSTALL.md)

## 🤝 贡献

欢迎提交PR！请阅读 [CONTRIBUTING.md](CONTRIBUTING.md)

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE)

---

⭐ 如果这个项目对你有帮助，请给个Star！
