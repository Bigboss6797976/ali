---
name: 功能请求
about: 建议新功能
title: '[FEATURE] '
labels: enhancement
assignees: ''

---

**功能描述**
清晰描述需要的功能

**使用场景**
描述这个功能的使用场景

**替代方案**
是否有临时替代方案

**附加信息**
任何其他相关信息
