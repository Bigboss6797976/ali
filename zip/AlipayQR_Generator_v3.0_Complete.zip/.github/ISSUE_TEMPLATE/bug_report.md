---
name: Bug报告
about: 报告一个bug
title: '[BUG] '
labels: bug
assignees: ''

---

**描述Bug**
清晰描述bug现象

**复现步骤**
1. 打开...
2. 点击...
3. 看到错误...

**期望行为**
描述期望的正确行为

**截图**
如有截图请附上

**环境信息:**
 - 平台: [Web/iOS/Android/桌面端]
 - 版本: [v3.0.0]
 - 浏览器/系统: [Chrome/Safari/Android 14]
