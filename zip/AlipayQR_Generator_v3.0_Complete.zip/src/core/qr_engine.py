# -*- coding: utf-8 -*-
"""二维码生成引擎"""

import qrcode
import qrcode.image.svg
from PIL import Image, ImageDraw, ImageFont
import os
import base64
import urllib.parse
import uuid
from datetime import datetime

class QREngine:
    def __init__(self):
        self.version = 5
        self.error_correction = qrcode.constants.ERROR_CORRECT_H
        self.box_size = 10
        self.border = 2

    def generate(self, provider, amount=None, note=None, recipient=None,
                 account=None, avatar=None, no_password=False,
                 permanent=False, api=None, size=512, output='qr_output.png'):
        """生成收款码"""

        # 生成订单号
        order_no = f"ORDER{datetime.now().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6].upper()}"

        # 构建URL
        qr_url = self._build_url(
            provider=provider,
            order_no=order_no,
            amount=amount,
            note=note,
            recipient=recipient,
            account=account,
            no_password=no_password,
            permanent=permanent,
            api=api
        )

        # 生成二维码
        qr = qrcode.QRCode(
            version=self.version,
            error_correction=self.error_correction,
            box_size=self.box_size,
            border=self.border,
        )
        qr.add_data(qr_url)
        qr.make(fit=True)

        # 创建图像
        img = qr.make_image(fill_color="black", back_color="white").convert('RGBA')
        img = img.resize((size, size), Image.LANCZOS)

        # 添加头像
        if avatar and os.path.exists(avatar):
            img = self._add_avatar(img, avatar)

        # 添加装饰
        img = self._add_decoration(img, provider, amount)

        # 保存
        img.save(output)

        provider_names = {
            'alipay': '支付宝官方',
            'easypay': '易支付',
            'wechat': '微信官方',
            'stripe': 'Stripe'
        }

        return {
            'provider': provider,
            'provider_name': provider_names.get(provider, provider),
            'order_no': order_no,
            'qr_url': qr_url,
            'output': output,
            'size': size,
            'amount': amount,
            'note': note
        }

    def _build_url(self, provider, order_no, amount=None, note=None,
                   recipient=None, account=None, no_password=False,
                   permanent=False, api=None):
        """构建支付URL"""

        if api and hasattr(api, 'create_order'):
            # 使用真实API
            return api.create_order(
                order_no=order_no,
                amount=amount,
                subject=note or '收款',
                body=recipient or '收款码'
            )

        # 模拟URL
        urls = {
            'alipay': f'https://qr.alipay.com/bax{base64.b64encode(order_no.encode()).decode().replace("=","")[:20]}',
            'easypay': f'https://pay.easypay.com/pay/{order_no}',
            'wechat': f'weixin://wxpay/bizpayurl?pr={order_no[:16]}',
            'stripe': f'https://stripe.com/pay/{order_no}'
        }

        url = urls.get(provider, urls['alipay'])

        params = []
        if amount:
            params.append(f'amount={amount}')
        if note:
            params.append(f'note={urllib.parse.quote(note)}')
        if recipient:
            params.append(f'recipient={urllib.parse.quote(recipient)}')
        if account:
            params.append(f'acc={base64.b64encode(account.encode()).decode()}')
        if no_password:
            params.append('no_pwd=1')
        if permanent:
            params.append('perm=1')

        if params:
            url += '?' + '&'.join(params)

        return url

    def _add_avatar(self, img, avatar_path):
        """在二维码中心添加头像"""
        try:
            avatar = Image.open(avatar_path).convert('RGBA')
            avatar_size = int(img.width * 0.22)
            avatar = avatar.resize((avatar_size, avatar_size), Image.LANCZOS)

            # 创建圆形遮罩
            mask = Image.new('L', (avatar_size, avatar_size), 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, avatar_size, avatar_size), fill=255)

            # 白色背景
            bg = Image.new('RGBA', (avatar_size + 8, avatar_size + 8), (255, 255, 255, 255))
            bg.paste(avatar, (4, 4), mask)

            pos = ((img.width - bg.width) // 2, (img.height - bg.height) // 2)
            img.paste(bg, pos)
        except Exception as e:
            print(f"[!] 头像添加失败: {e}")
        return img

    def _add_decoration(self, img, provider, amount):
        """添加装饰元素"""
        draw = ImageDraw.Draw(img)

        # 添加边框
        border_width = 4
        draw.rectangle(
            [border_width//2, border_width//2, img.width-border_width//2, img.height-border_width//2],
            outline='#1677FF', width=border_width
        )

        return img

    def generate_svg(self, data, output='qr_output.svg'):
        """生成SVG格式"""
        factory = qrcode.image.svg.SvgImage
        qr = qrcode.QRCode(image_factory=factory)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(output)
        return output
