# -*- coding: utf-8 -*-
"""加密工具 - RSA2/MD5签名生成"""

import hashlib
import hmac
import base64
from urllib.parse import quote_plus

try:
    from Crypto.PublicKey import RSA
    from Crypto.Signature import pkcs1_15
    from Crypto.Hash import SHA256, MD5
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

class CryptoUtil:
    """支付签名工具"""

    @staticmethod
    def md5_sign(params, key):
        """MD5签名 (易支付/微信)"""
        # 按键排序
        sorted_params = sorted(params.items())
        # 拼接字符串
        sign_str = '&'.join([f"{k}={v}" for k, v in sorted_params if v])
        sign_str += f"&key={key}"
        # MD5加密
        return hashlib.md5(sign_str.encode()).hexdigest().upper()

    @staticmethod
    def rsa2_sign(params, private_key):
        """RSA2签名 (支付宝)"""
        if not CRYPTO_AVAILABLE:
            raise ImportError("需要安装 pycryptodome: pip install pycryptodome")

        # 构建待签名字符串
        sorted_params = sorted(params.items())
        sign_str = '&'.join([f"{k}={v}" for k, v in sorted_params if v])

        # RSA签名
        key = RSA.import_key(private_key)
        h = SHA256.new(sign_str.encode())
        signature = pkcs1_15.new(key).sign(h)
        return base64.b64encode(signature).decode()

    @staticmethod
    def verify_rsa2(params, signature, public_key):
        """验证RSA2签名"""
        if not CRYPTO_AVAILABLE:
            raise ImportError("需要安装 pycryptodome")

        sorted_params = sorted(params.items())
        sign_str = '&'.join([f"{k}={v}" for k, v in sorted_params if v])

        key = RSA.import_key(public_key)
        h = SHA256.new(sign_str.encode())
        try:
            pkcs1_15.new(key).verify(h, base64.b64decode(signature))
            return True
        except (ValueError, TypeError):
            return False

    @staticmethod
    def base64_urlsafe(data):
        """URL安全的Base64编码"""
        return base64.urlsafe_b64encode(data).decode().rstrip('=')

    @staticmethod
    def generate_nonce_str(length=32):
        """生成随机字符串"""
        import random
        import string
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
