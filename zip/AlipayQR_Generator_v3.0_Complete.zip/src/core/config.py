# -*- coding: utf-8 -*-
"""配置管理器 - AES-256加密存储"""

import json
import os
import base64
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class ConfigManager:
    CONFIG_FILE = Path.home() / '.alipayqr' / 'config.enc'
    SALT_FILE = Path.home() / '.alipayqr' / '.salt'

    def __init__(self):
        self._data = {}
        self._load()

    def _get_key(self):
        """从机器指纹生成加密密钥"""
        if self.SALT_FILE.exists():
            salt = self.SALT_FILE.read_bytes()
        else:
            salt = os.urandom(16)
            self.SALT_FILE.parent.mkdir(parents=True, exist_ok=True)
            self.SALT_FILE.write_bytes(salt)

        # 使用机器标识作为密码
        machine_id = self._get_machine_id()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(machine_id.encode()))
        return key

    def _get_machine_id(self):
        """获取机器唯一标识"""
        try:
            import uuid
            return str(uuid.getnode())
        except:
            return 'default_machine_id'

    def _load(self):
        """加载加密配置"""
        if not self.CONFIG_FILE.exists():
            return
        try:
            f = Fernet(self._get_key())
            encrypted = self.CONFIG_FILE.read_bytes()
            decrypted = f.decrypt(encrypted)
            self._data = json.loads(decrypted.decode())
        except Exception:
            self._data = {}

    def save(self):
        """保存加密配置"""
        self.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        f = Fernet(self._get_key())
        encrypted = f.encrypt(json.dumps(self._data).encode())
        self.CONFIG_FILE.write_bytes(encrypted)

    def get(self, key, default=None):
        """获取配置项 (支持点号路径)"""
        keys = key.split('.')
        value = self._data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        return value if value is not None else default

    def set(self, key, value):
        """设置配置项"""
        keys = key.split('.')
        target = self._data
        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        target[keys[-1]] = value

    def load_from_file(self, path):
        """从JSON文件加载配置"""
        with open(path, 'r', encoding='utf-8') as f:
            self._data.update(json.load(f))
