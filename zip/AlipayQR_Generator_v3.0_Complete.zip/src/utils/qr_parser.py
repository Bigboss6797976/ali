# -*- coding: utf-8 -*-
"""二维码解析工具"""

from PIL import Image
try:
    import zxing
    ZXING_AVAILABLE = True
except ImportError:
    ZXING_AVAILABLE = False

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

class QRParser:
    """二维码解析器"""

    @staticmethod
    def parse(image_path):
        """解析二维码图片"""
        result = {
            'success': False,
            'url': None,
            'type': 'unknown',
            'raw_data': None,
            'error': None
        }

        try:
            # 尝试使用zxing
            if ZXING_AVAILABLE:
                reader = zxing.BarCodeReader()
                barcode = reader.decode(image_path)
                if barcode:
                    result['success'] = True
                    result['url'] = barcode.parsed
                    result['raw_data'] = barcode.raw

            # 尝试使用OpenCV
            if not result['success'] and CV2_AVAILABLE:
                img = cv2.imread(image_path)
                detector = cv2.QRCodeDetector()
                data, bbox, _ = detector.detectAndDecode(img)
                if data:
                    result['success'] = True
                    result['url'] = data
                    result['raw_data'] = data

            # 尝试使用pyzbar
            if not result['success']:
                try:
                    from pyzbar.pyzbar import decode
                    img = Image.open(image_path)
                    decoded = decode(img)
                    if decoded:
                        result['success'] = True
                        result['url'] = decoded[0].data.decode('utf-8')
                        result['raw_data'] = decoded[0].data.decode('utf-8')
                except ImportError:
                    pass

            # 识别支付类型
            if result['url']:
                url = result['url'].lower()
                if 'alipay' in url:
                    result['type'] = 'alipay'
                elif 'weixin' in url or 'wxpay' in url:
                    result['type'] = 'wechat'
                elif 'stripe' in url:
                    result['type'] = 'stripe'
                elif 'easypay' in url:
                    result['type'] = 'easypay'

        except Exception as e:
            result['error'] = str(e)

        return result

    @staticmethod
    def parse_from_camera():
        """从摄像头实时解析"""
        if not CV2_AVAILABLE:
            raise ImportError("需要安装 opencv-python")

        cap = cv2.VideoCapture(0)
        detector = cv2.QRCodeDetector()

        print("[*] 按 'q' 退出扫描")
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            data, bbox, _ = detector.detectAndDecode(frame)

            if data:
                print(f"[+] 扫描成功: {data}")
                cap.release()
                cv2.destroyAllWindows()
                return data

            cv2.imshow('QR Scanner', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        return None
