# -*- coding: utf-8 -*-
"""支付数据统计分析"""

import json
import os
from datetime import datetime, timedelta
from collections import defaultdict

class PaymentAnalytics:
    """支付数据分析"""

    DATA_FILE = os.path.expanduser('~/.alipayqr/analytics.json')

    def __init__(self):
        self._data = self._load()

    def _load(self):
        if os.path.exists(self.DATA_FILE):
            with open(self.DATA_FILE, 'r') as f:
                return json.load(f)
        return {'records': []}

    def _save(self):
        os.makedirs(os.path.dirname(self.DATA_FILE), exist_ok=True)
        with open(self.DATA_FILE, 'w') as f:
            json.dump(self._data, f, ensure_ascii=False)

    def record(self, provider, amount, status='success', fee=0, note=''):
        """记录一笔交易"""
        self._data['records'].append({
            'timestamp': datetime.now().isoformat(),
            'provider': provider,
            'amount': float(amount),
            'status': status,
            'fee': float(fee),
            'note': note
        })
        self._save()

    def get_summary(self, days=30):
        """获取统计摘要"""
        cutoff = datetime.now() - timedelta(days=days)
        records = [r for r in self._data['records'] 
                   if datetime.fromisoformat(r['timestamp']) > cutoff]

        total_amount = sum(r['amount'] for r in records)
        total_fee = sum(r['fee'] for r in records)
        count = len(records)

        # 按通道统计
        by_provider = defaultdict(lambda: {'count': 0, 'amount': 0, 'fee': 0})
        for r in records:
            p = r['provider']
            by_provider[p]['count'] += 1
            by_provider[p]['amount'] += r['amount']
            by_provider[p]['fee'] += r['fee']

        return {
            'period_days': days,
            'total_transactions': count,
            'total_amount': round(total_amount, 2),
            'total_fee': round(total_fee, 2),
            'net_amount': round(total_amount - total_fee, 2),
            'by_provider': dict(by_provider),
            'avg_transaction': round(total_amount / count, 2) if count > 0 else 0
        }

    def export_csv(self, path):
        """导出CSV报表"""
        import csv
        with open(path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(['时间', '通道', '金额', '手续费', '净额', '状态', '备注'])
            for r in self._data['records']:
                writer.writerow([
                    r['timestamp'],
                    r['provider'],
                    r['amount'],
                    r['fee'],
                    round(r['amount'] - r['fee'], 2),
                    r['status'],
                    r['note']
                ])
