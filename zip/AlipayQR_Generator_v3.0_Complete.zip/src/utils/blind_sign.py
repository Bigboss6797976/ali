# -*- coding: utf-8 -*-
"""盲签工具 - 隐私保护签名"""

import hashlib
import random
import base64

try:
    from Crypto.PublicKey import RSA
    from Crypto.Signature import pkcs1_15
    from Crypto.Hash import SHA256
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

class BlindSigner:
    """盲签名实现"""

    def __init__(self):
        if not CRYPTO_AVAILABLE:
            raise ImportError("需要安装 pycryptodome")

    def blind_message(self, message, public_key):
        """盲化消息"""
        key = RSA.import_key(public_key)
        n = key.n
        e = key.e

        # 生成随机盲因子
        r = random.randint(2, n - 1)
        while self._gcd(r, n) != 1:
            r = random.randint(2, n - 1)

        # 消息哈希
        h = int(hashlib.sha256(message.encode()).hexdigest(), 16)

        # 盲化: m' = m * r^e mod n
        blinded = (h * pow(r, e, n)) % n

        return {
            'blinded_message': blinded,
            'blind_factor': r,
            'original_hash': h
        }

    def sign_blinded(self, blinded_message, private_key):
        """对盲化消息签名"""
        key = RSA.import_key(private_key)
        n = key.n
        d = key.d

        # 签名: s' = (m')^d mod n
        signature = pow(blinded_message, d, n)
        return signature

    def unblind_signature(self, blinded_signature, blind_factor, public_key):
        """去盲化得到真实签名"""
        key = RSA.import_key(public_key)
        n = key.n

        # 去盲化: s = s' * r^-1 mod n
        r_inv = self._mod_inverse(blind_factor, n)
        signature = (blinded_signature * r_inv) % n

        return signature

    def verify(self, message, signature, public_key):
        """验证签名"""
        key = RSA.import_key(public_key)
        n = key.n
        e = key.e

        h = int(hashlib.sha256(message.encode()).hexdigest(), 16)
        verified = pow(signature, e, n)

        return h == verified

    @staticmethod
    def _gcd(a, b):
        while b:
            a, b = b, a % b
        return a

    @staticmethod
    def _mod_inverse(a, m):
        def extended_gcd(a, b):
            if a == 0:
                return b, 0, 1
            gcd, x1, y1 = extended_gcd(b % a, a)
            x = y1 - (b // a) * x1
            y = x1
            return gcd, x, y

        _, x, _ = extended_gcd(a % m, m)
        return (x % m + m) % m
