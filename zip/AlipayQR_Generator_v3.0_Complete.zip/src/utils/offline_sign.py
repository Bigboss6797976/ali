# -*- coding: utf-8 -*-
"""离线签名工具 - 无需联网生成签名"""

import hashlib
import hmac
import base64
import time
from core.crypto import CryptoUtil

class OfflineSigner:
    """离线签名生成器"""

    @staticmethod
    def alipay_offline_sign(params, private_key):
        """支付宝离线RSA2签名"""
        return CryptoUtil.rsa2_sign(params, private_key)

    @staticmethod
    def easypay_offline_sign(params, key):
        """易支付离线MD5签名"""
        return CryptoUtil.md5_sign(params, key)

    @staticmethod
    def wechat_offline_sign(params, api_key):
        """微信离线MD5签名"""
        return CryptoUtil.md5_sign(params, api_key)

    @staticmethod
    def generate_timestamp():
        """生成时间戳"""
        return time.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def generate_order_no(prefix='ORDER'):
        """生成订单号"""
        import uuid
        return f"{prefix}{int(time.time())}{uuid.uuid4().hex[:6].upper()}"
