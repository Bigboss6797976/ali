# -*- coding: utf-8 -*-
"""支付状态监控器"""

import time
import threading
from typing import Callable, Optional

class PaymentMonitor:
    """支付状态轮询监控"""

    def __init__(self, check_interval=5):
        self.check_interval = check_interval
        self._callbacks = {}
        self._running = False
        self._thread = None

    def start_monitoring(self, order_no: str, 
                        check_func: Callable,
                        on_success: Optional[Callable] = None,
                        on_timeout: Optional[Callable] = None,
                        timeout=300):
        """
        开始监控订单状态
        check_func: 返回状态的函数，返回 'SUCCESS', 'PENDING', 'FAILED'
        """
        self._callbacks[order_no] = {
            'check': check_func,
            'on_success': on_success,
            'on_timeout': on_timeout,
            'start_time': time.time(),
            'timeout': timeout
        }

        if not self._running:
            self._running = True
            self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self._thread.start()

    def _monitor_loop(self):
        """监控循环"""
        while self._running and self._callbacks:
            current_time = time.time()
            completed = []

            for order_no, config in list(self._callbacks.items()):
                # 检查超时
                if current_time - config['start_time'] > config['timeout']:
                    if config['on_timeout']:
                        config['on_timeout'](order_no)
                    completed.append(order_no)
                    continue

                # 检查状态
                try:
                    status = config['check'](order_no)
                    if status == 'SUCCESS':
                        if config['on_success']:
                            config['on_success'](order_no)
                        completed.append(order_no)
                    elif status == 'FAILED':
                        completed.append(order_no)
                except Exception as e:
                    print(f"[!] 监控订单 {order_no} 出错: {e}")

            # 清理已完成
            for order_no in completed:
                del self._callbacks[order_no]

            time.sleep(self.check_interval)

        self._running = False

    def stop_monitoring(self, order_no=None):
        """停止监控"""
        if order_no:
            self._callbacks.pop(order_no, None)
        else:
            self._callbacks.clear()
            self._running = False
