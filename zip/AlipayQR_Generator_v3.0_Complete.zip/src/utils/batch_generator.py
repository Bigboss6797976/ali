# -*- coding: utf-8 -*-
"""批量二维码生成器"""

import os
import json
from concurrent.futures import ThreadPoolExecutor
from core.qr_engine import QREngine
from payments.router import SmartRouter

class BatchGenerator:
    """批量生成收款码"""

    def __init__(self, max_workers=4):
        self.engine = QREngine()
        self.router = SmartRouter()
        self.max_workers = max_workers

    def generate_batch(self, items, output_dir='./batch_output'):
        """
        批量生成
        items: [{"amount": 100, "note": "", "provider": "auto"}, ...]
        """
        os.makedirs(output_dir, exist_ok=True)
        results = []

        def process_item(i, item):
            provider = item.get('provider', 'auto')
            amount = item.get('amount')

            if provider == 'auto' and amount:
                provider = self.router.select(amount)

            output = os.path.join(output_dir, f"qr_{i:04d}_{provider}_{amount}.png")

            result = self.engine.generate(
                provider=provider,
                amount=amount,
                note=item.get('note', ''),
                recipient=item.get('recipient', ''),
                avatar=item.get('avatar'),
                no_password=item.get('no_password', False),
                permanent=item.get('permanent', True),
                output=output
            )
            return result

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [executor.submit(process_item, i, item) for i, item in enumerate(items)]
            for future in futures:
                try:
                    results.append(future.result())
                except Exception as e:
                    results.append({"error": str(e)})

        # 生成报告
        report_path = os.path.join(output_dir, 'report.json')
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump({
                'total': len(items),
                'success': sum(1 for r in results if 'error' not in r),
                'failed': sum(1 for r in results if 'error' in r),
                'results': results
            }, f, ensure_ascii=False, indent=2)

        return results

    def generate_from_csv(self, csv_path, output_dir='./batch_output'):
        """从CSV文件批量生成"""
        import csv
        items = []
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                items.append({
                    'amount': float(row.get('amount', 0)) if row.get('amount') else None,
                    'note': row.get('note', ''),
                    'provider': row.get('provider', 'auto'),
                    'recipient': row.get('recipient', '')
                })
        return self.generate_batch(items, output_dir)
