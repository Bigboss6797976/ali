# -*- coding: utf-8 -*-
"""易支付 - 第三方聚合支付API"""

import urllib.parse
from core.crypto import CryptoUtil

class EasyPayAPI:
    """易支付API"""

    def __init__(self, pid, key, api_url='https://pay.easypay.com'):
        self.pid = pid
        self.key = key
        self.api_url = api_url.rstrip('/')

    def create_order(self, order_no, amount, subject, body='', channel='alipay'):
        """创建支付订单"""
        params = {
            "pid": self.pid,
            "type": channel,
            "out_trade_no": order_no,
            "notify_url": "https://your-domain.com/notify",
            "return_url": "https://your-domain.com/return",
            "name": subject,
            "money": str(amount),
            "clientip": "127.0.0.1",
            "device": "pc",
            "param": body,
        }

        # MD5签名
        params["sign"] = CryptoUtil.md5_sign(params, self.key)
        params["sign_type"] = "MD5"

        return f"{self.api_url}/submit.php?{urllib.parse.urlencode(params)}"

    def verify_notify(self, params):
        """验证异步通知"""
        sign = params.pop('sign', '')
        sign_type = params.pop('sign_type', '')
        computed = CryptoUtil.md5_sign(params, self.key)
        return sign.upper() == computed
