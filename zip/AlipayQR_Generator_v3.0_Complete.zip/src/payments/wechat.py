# -*- coding: utf-8 -*-
"""微信支付 - Native扫码支付"""

import xml.etree.ElementTree as ET
from core.crypto import CryptoUtil

class WechatAPI:
    """微信支付API"""

    GATEWAY = "https://api.mch.weixin.qq.com/pay/unifiedorder"

    def __init__(self, mch_id, api_key, app_id=None):
        self.mch_id = mch_id
        self.api_key = api_key
        self.app_id = app_id

    def create_order(self, order_no, amount, subject, body='', trade_type='NATIVE'):
        """创建Native支付订单"""
        params = {
            "appid": self.app_id or '',
            "mch_id": self.mch_id,
            "nonce_str": CryptoUtil.generate_nonce_str(),
            "body": subject,
            "out_trade_no": order_no,
            "total_fee": int(float(amount) * 100),  # 分
            "spbill_create_ip": "127.0.0.1",
            "notify_url": "https://your-domain.com/wxnotify",
            "trade_type": trade_type,
        }

        params["sign"] = CryptoUtil.md5_sign(params, self.api_key)

        # 构建XML
        xml = "<xml>"
        for k, v in params.items():
            xml += f"<{k}><![CDATA[{v}]]></{k}>"
        xml += "</xml>"

        return xml

    def parse_response(self, xml_data):
        """解析XML响应"""
        root = ET.fromstring(xml_data)
        result = {child.tag: child.text for child in root}
        return result
