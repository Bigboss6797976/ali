# -*- coding: utf-8 -*-
"""
智能路由 - 根据金额自动选择最优通道

聚合收款码核心原理:
- 微信Native支付: 返回weixin://链接，需微信内置识别
- 支付宝当面付: 返回https://qr.alipay.com链接，可直接唤起App
- 建议采用JSAPI支付/当面付扫码支付方案

参考: https://cloud.tencent.com/developer/article/1709229
"""

class SmartRouter:
    """智能路由选择器 - 聚合支付最优通道选择"""

    # 路由策略配置 - 基于费率和到账速度
    ROUTES = {
        'small': {      # 小额 < ¥100
            'provider': 'easypay',
            'name': '易支付',
            'fee_rate': 0.01,
            'settle': 'D+0',
            'reason': '小额快速到账，D+0结算，适合个人收款',
            'min_amount': 0.01,
            'max_amount': 99.99
        },
        'medium': {     # 中额 ¥100 - ¥5000
            'provider': 'alipay',
            'name': '支付宝官方',
            'fee_rate': 0.006,
            'settle': 'D+1',
            'reason': '标准费率0.6%，稳定可靠，适合商家收款',
            'min_amount': 100,
            'max_amount': 5000
        },
        'large': {      # 大额 > ¥5000
            'provider': 'stripe',
            'name': 'Stripe',
            'fee_rate': 0.029,
            'settle': 'T+7',
            'reason': '支持国际支付，大额风控更优，适合跨境交易',
            'min_amount': 5000.01,
            'max_amount': float('inf')
        }
    }

    def __init__(self, custom_rules=None):
        self.rules = custom_rules or self.ROUTES

    def select(self, amount):
        """
        根据金额选择最优通道

        策略:
        - < ¥100: 易支付 (D+0快速到账)
        - ¥100-¥5000: 支付宝官方 (费率最低)
        - > ¥5000: Stripe (国际支持+风控)
        """
        amount = float(amount)

        if amount < 100:
            return self.rules['small']['provider']
        elif amount <= 5000:
            return self.rules['medium']['provider']
        else:
            return self.rules['large']['provider']

    def get_route_info(self, amount):
        """获取路由详细信息"""
        amount = float(amount)

        if amount < 100:
            route = self.rules['small']
        elif amount <= 5000:
            route = self.rules['medium']
        else:
            route = self.rules['large']

        fee = amount * route['fee_rate']

        return {
            **route,
            'amount': amount,
            'estimated_fee': round(fee, 2),
            'actual_amount': round(amount - fee, 2),
            'recommended': True
        }

    def compare(self, amount):
        """
        对比所有通道

        返回按费率排序的通道列表，帮助用户选择
        """
        amount = float(amount)
        results = []

        for key, route in self.rules.items():
            fee = amount * route['fee_rate']
            results.append({
                'tier': key,
                **route,
                'estimated_fee': round(fee, 2),
                'actual_amount': round(amount - fee, 2),
                'is_recommended': self.select(amount) == route['provider']
            })

        # 按费率排序
        return sorted(results, key=lambda x: x['fee_rate'])

    def get_all_providers(self):
        """获取所有支持的支付通道"""
        return {
            'alipay': {
                'name': '支付宝官方',
                'fee_rate': 0.006,
                'settle': 'D+1',
                'api': 'alipay.trade.precreate',
                'qr_type': 'dynamic',  # 动态二维码
                'app_support': True,     # 支持App内唤起
            },
            'wechat': {
                'name': '微信官方',
                'fee_rate': 0.006,
                'settle': 'D+1',
                'api': 'unifiedorder',
                'qr_type': 'native',
                'app_support': True,
            },
            'easypay': {
                'name': '易支付',
                'fee_rate': 0.01,
                'settle': 'D+0',
                'api': 'submit',
                'qr_type': 'dynamic',
                'app_support': True,
            },
            'stripe': {
                'name': 'Stripe',
                'fee_rate': 0.029,
                'settle': 'T+7',
                'api': 'payment_intents',
                'qr_type': 'dynamic',
                'app_support': True,
                'multi_currency': True,
            }
        }
