# -*- coding: utf-8 -*-
"""Stripe - 国际支付API"""

import urllib.request
import urllib.parse
import json
import base64

class StripeAPI:
    """Stripe支付API"""

    BASE_URL = "https://api.stripe.com/v1"

    def __init__(self, secret_key, currency='cny'):
        self.secret_key = secret_key
        self.currency = currency.lower()

    def _request(self, endpoint, data=None, method='GET'):
        """发送API请求"""
        url = f"{self.BASE_URL}{endpoint}"
        headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/x-www-form-urlencoded"
        }

        if data and method == 'POST':
            data = urllib.parse.urlencode(data).encode()

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            return {"error": str(e)}

    def create_order(self, order_no, amount, subject, body=''):
        """创建PaymentIntent"""
        # 实际应调用Stripe API，此处返回模拟URL
        return f"https://stripe.com/pay/{order_no}"

    def create_payment_intent(self, amount, currency=None, metadata=None):
        """创建PaymentIntent"""
        data = {
            "amount": int(float(amount) * 100),
            "currency": currency or self.currency,
            "automatic_payment_methods[enabled]": "true",
        }
        if metadata:
            for k, v in metadata.items():
                data[f"metadata[{k}]"] = v
        return self._request('/payment_intents', data, 'POST')

    def retrieve_payment_intent(self, payment_intent_id):
        """查询PaymentIntent"""
        return self._request(f'/payment_intents/{payment_intent_id}')
