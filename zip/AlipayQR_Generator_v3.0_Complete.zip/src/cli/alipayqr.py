#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlipayQR v3.0 - 多通道聚合收款码生成器 CLI
支持: 支付宝/微信/Stripe/易支付
作者: AlipayQR Team
"""

import argparse
import sys
import os
import json
import base64
import hashlib
import time
import urllib.parse
from pathlib import Path

from core.config import ConfigManager
from core.qr_engine import QREngine
from core.crypto import CryptoUtil
from payments.alipay import AlipayAPI
from payments.easypay import EasyPayAPI
from payments.wechat import WechatAPI
from payments.stripe_pay import StripeAPI
from payments.router import SmartRouter

__version__ = "3.0.0"

def create_parser():
    parser = argparse.ArgumentParser(
        prog='alipayqr',
        description='AlipayQR v3.0 - 多通道聚合收款码生成器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 生成支付宝收款码
  alipayqr --provider alipay --amount 100 --note "测试订单"

  # 智能路由自动选择
  alipayqr --provider auto --amount 5000 --recipient "商家"

  # 解析现有二维码
  alipayqr --parse existing_qr.png

  # 自定义账号+头像
  alipayqr --provider alipay --amount 88.88 \
    --account "your@email.com" --avatar head.jpg

  # 易支付通道
  alipayqr --provider easypay --amount 50 --config easypay.json

  # 微信Native支付
  alipayqr --provider wechat --amount 200 \
    --mch_id 123456 --api_key xxx

  # Stripe国际支付
  alipayqr --provider stripe --amount 99.99 \
    --currency usd --stripe_key sk_live_xxx

  # 免密支付+永久有效
  alipayqr --provider alipay --amount 10 \
    --no-password --permanent
        """
    )

    # 基本参数
    parser.add_argument('--version', action='version', version=f'AlipayQR v{__version__}')
    parser.add_argument('-v', '--verbose', action='store_true', help='详细输出')

    # 功能模式
    parser.add_argument('--parse', metavar='FILE', help='解析现有二维码图片')
    parser.add_argument('--generate', action='store_true', help='生成收款码（默认）')

    # 支付通道
    parser.add_argument('-p', '--provider', 
                       choices=['auto', 'alipay', 'easypay', 'wechat', 'stripe'],
                       default='auto', help='支付通道 (默认: auto)')

    # 收款信息
    parser.add_argument('-a', '--amount', type=float, help='收款金额')
    parser.add_argument('-n', '--note', help='订单备注')
    parser.add_argument('-r', '--recipient', help='收款方名称')
    parser.add_argument('--account', help='自定义收款账号')

    # 样式
    parser.add_argument('--avatar', metavar='FILE', help='自定义头像图片')
    parser.add_argument('--color', default='#000000', help='二维码颜色')
    parser.add_argument('--bg-color', default='#FFFFFF', help='二维码背景色')

    # 高级选项
    parser.add_argument('--no-password', action='store_true', help='启用免密支付')
    parser.add_argument('--permanent', action='store_true', help='二维码永久有效')
    parser.add_argument('--fixed', action='store_true', help='固定金额模式')

    # 支付宝API
    parser.add_argument('--app-id', help='支付宝APPID')
    parser.add_argument('--private-key', help='应用私钥文件路径')
    parser.add_argument('--alipay-public-key', help='支付宝公钥文件路径')
    parser.add_argument('--sandbox', action='store_true', help='沙箱环境')

    # 易支付
    parser.add_argument('--pid', help='易支付商户ID')
    parser.add_argument('--key', help='易支付通信密钥')
    parser.add_argument('--api-url', default='https://pay.easypay.com', help='易支付API地址')

    # 微信
    parser.add_argument('--mch-id', help='微信商户号')
    parser.add_argument('--api-key', help='微信API密钥')
    parser.add_argument('--wx-app-id', help='微信AppID')

    # Stripe
    parser.add_argument('--stripe-key', help='Stripe Secret Key')
    parser.add_argument('--currency', default='cny', help='货币代码 (默认: cny)')

    # 输出
    parser.add_argument('-o', '--output', default='qr_output.png', help='输出文件名')
    parser.add_argument('--format', choices=['png', 'svg', 'pdf'], default='png', help='输出格式')
    parser.add_argument('--size', type=int, default=512, help='二维码尺寸')

    # 配置
    parser.add_argument('-c', '--config', metavar='FILE', help='配置文件路径')
    parser.add_argument('--save-config', action='store_true', help='保存当前配置')

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()

    if args.verbose:
        print(f"[+] AlipayQR v{__version__} 启动")

    # 解析模式
    if args.parse:
        from utils.qr_parser import QRParser
        result = QRParser.parse(args.parse)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    # 加载配置
    config = ConfigManager()
    if args.config:
        config.load_from_file(args.config)

    # 智能路由
    provider = args.provider
    if provider == 'auto' and args.amount:
        router = SmartRouter()
        provider = router.select(args.amount)
        if args.verbose:
            print(f"[*] 智能路由选择: {provider}")

    # 初始化支付API
    api = None
    if provider == 'alipay':
        api = AlipayAPI(
            app_id=args.app_id or config.get('alipay.app_id'),
            private_key=args.private_key or config.get('alipay.private_key'),
            alipay_public_key=args.alipay_public_key or config.get('alipay.alipay_public_key'),
            sandbox=args.sandbox or config.get('alipay.sandbox', False)
        )
    elif provider == 'easypay':
        api = EasyPayAPI(
            pid=args.pid or config.get('easypay.pid'),
            key=args.key or config.get('easypay.key'),
            api_url=args.api_url or config.get('easypay.api_url', 'https://pay.easypay.com')
        )
    elif provider == 'wechat':
        api = WechatAPI(
            mch_id=args.mch_id or config.get('wechat.mch_id'),
            api_key=args.api_key or config.get('wechat.api_key'),
            app_id=args.wx_app_id or config.get('wechat.app_id')
        )
    elif provider == 'stripe':
        api = StripeAPI(
            secret_key=args.stripe_key or config.get('stripe.secret_key'),
            currency=args.currency
        )

    # 生成收款码
    qr_engine = QREngine()
    result = qr_engine.generate(
        provider=provider,
        amount=args.amount,
        note=args.note,
        recipient=args.recipient,
        account=args.account,
        avatar=args.avatar,
        no_password=args.no_password,
        permanent=args.permanent,
        api=api,
        size=args.size,
        output=args.output
    )

    if args.verbose:
        print(f"[+] 收款码已生成: {args.output}")
        print(f"[*] 支付通道: {result.get('provider_name')}")
        print(f"[*] 订单号: {result.get('order_no')}")
        print(f"[*] URL: {result.get('qr_url')}")
    else:
        print(f"✓ 收款码已保存: {os.path.abspath(args.output)}")

    # 保存配置
    if args.save_config:
        config.save()
        print("✓ 配置已保存")

if __name__ == '__main__':
    main()
