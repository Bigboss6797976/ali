"""
AlipayQR v3.0 - 多通道聚合收款码生成器

支持: 支付宝 / 微信 / Stripe / 易支付
平台: Web / iOS / Android / 桌面端 / CLI
"""

__version__ = "3.0.0"
__author__ = "AlipayQR Team"

from .core.qr_engine import QREngine
from .core.config import ConfigManager
from .core.crypto import CryptoUtil
from .payments.router import SmartRouter
from .payments.alipay import AlipayAPI
from .payments.easypay import EasyPayAPI
from .payments.wechat import WechatAPI
from .payments.stripe_pay import StripeAPI

__all__ = [
    'QREngine',
    'ConfigManager', 
    'CryptoUtil',
    'SmartRouter',
    'AlipayAPI',
    'EasyPayAPI',
    'WechatAPI',
    'StripeAPI',
]
