# AlipayQR v3.0 - Windows 一键安装脚本
# 以管理员身份运行: powershell -ExecutionPolicy Bypass -File install.ps1

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   AlipayQR v3.0 - 一键安装" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查Python
Write-Host "[*] 检查 Python..." -ForegroundColor Yellow
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command python3 -ErrorAction SilentlyContinue
}
if (-not $python) {
    Write-Host "[!] 未找到 Python，请先安装 Python 3.8+" -ForegroundColor Red
    Write-Host "    下载地址: https://www.python.org/downloads/"
    exit 1
}
Write-Host "[+] Python 已找到: $($python.Source)" -ForegroundColor Green

# 检查Node.js
Write-Host "[*] 检查 Node.js..." -ForegroundColor Yellow
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Write-Host "[!] 未找到 Node.js，正在下载安装..." -ForegroundColor Yellow
    $nodeUrl = "https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi"
    $nodeInstaller = "$env:TEMP\nodejs_installer.msi"
    Invoke-WebRequest -Uri $nodeUrl -OutFile $nodeInstaller
    Start-Process msiexec.exe -ArgumentList "/i", $nodeInstaller, "/quiet", "/norestart" -Wait
    Remove-Item $nodeInstaller
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    Write-Host "[+] Node.js 安装完成" -ForegroundColor Green
} else {
    Write-Host "[+] Node.js 已找到: $($node.Source)" -ForegroundColor Green
}

# 安装Python依赖
Write-Host "[*] 安装 Python 依赖..." -ForegroundColor Yellow
& python -m pip install --upgrade pip
& python -m pip install -r requirements.txt
Write-Host "[+] Python 依赖安装完成" -ForegroundColor Green

# 安装Node依赖
Write-Host "[*] 安装 Node 依赖..." -ForegroundColor Yellow
& npm install
Write-Host "[+] Node 依赖安装完成" -ForegroundColor Green

# 创建桌面快捷方式
Write-Host "[*] 创建桌面快捷方式..." -ForegroundColor Yellow
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\AlipayQR.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$PWD\start.ps1`""
$Shortcut.WorkingDirectory = "$PWD"
$Shortcut.IconLocation = "$PWD\icon-512.png"
$Shortcut.Description = "AlipayQR 收款码生成器"
$Shortcut.Save()
Write-Host "[+] 桌面快捷方式已创建" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "   安装完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "使用方式:" -ForegroundColor Cyan
Write-Host "  1. Web版本: 双击 start.bat" -ForegroundColor White
Write-Host "  2. CLI版本: python src\cli\alipayqr.py --help" -ForegroundColor White
Write-Host "  3. 桌面版本: npm run build:win" -ForegroundColor White
Write-Host ""
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
