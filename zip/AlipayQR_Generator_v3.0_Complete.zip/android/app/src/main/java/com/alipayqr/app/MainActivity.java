package com.alipayqr.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(com.getcapacitor.community.camera.CameraPlugin.class);
        registerPlugin(com.getcapacitor.community.share.SharePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
