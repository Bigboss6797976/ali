#!/bin/bash
echo "========================================"
echo "   AlipayQR v3.0 - 收款码生成器"
echo "========================================"
echo ""
echo "正在启动 Web 服务器..."
echo "请在浏览器中访问: http://localhost:8080"
echo ""
python3 -m http.server 8080