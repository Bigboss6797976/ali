# 部署指南

## Web部署

### 静态托管
```bash
# 复制到任意Web服务器
scp -r src/ui/web/* user@server:/var/www/html/

# 或使用Nginx
server {
    listen 80;
    server_name qr.yourdomain.com;
    root /var/www/alipayqr;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # 启用Gzip
    gzip on;
    gzip_types text/css application/javascript image/svg+xml;
}
```

### Docker部署
```bash
# 构建镜像
docker-compose up -d --build

# 访问 http://localhost:8080
```

### Vercel/Netlify
```bash
# 直接拖拽 src/ui/web 文件夹到Vercel/Netlify
# 或使用CLI
vercel --prod
netlify deploy --prod --dir=src/ui/web
```

## 桌面端打包

### Windows
```bash
npm install
npm run build:win
# 输出: dist-electron/AlipayQR Setup 3.0.0.exe
```

### macOS
```bash
npm install
npm run build:mac
# 输出: dist-electron/AlipayQR-3.0.0.dmg
```

### Linux
```bash
npm install
npm run build:linux
# 输出: dist-electron/AlipayQR-3.0.0.AppImage
```

## 移动端打包

### Android APK
```bash
# 前提: 安装Android Studio和SDK
npm install
npx cap sync android
cd android
./gradlew assembleRelease
# 输出: android/app/build/outputs/apk/release/app-release.apk
```

### iOS IPA
```bash
# 前提: macOS + Xcode
npm install
npx cap sync ios
cd ios/App
xcodebuild -workspace App.xcworkspace -scheme App -configuration Release
# 使用Xcode Archive导出IPA
```

## 发布到应用商店

### Google Play
1. 生成签名密钥
2. 构建AAB文件: `./gradlew bundleRelease`
3. 上传到Google Play Console

### App Store
1. 注册Apple Developer账号 ($99/年)
2. 创建App ID和Provisioning Profile
3. 使用Xcode Archive并上传

### 国内应用市场
- 华为应用市场
- 小米应用商店
- OPPO/vivo应用商店
- 应用宝
