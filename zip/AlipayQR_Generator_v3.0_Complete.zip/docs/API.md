# AlipayQR API 文档

## 支付通道API

### 支付宝 (AlipayAPI)

```python
from payments.alipay import AlipayAPI

api = AlipayAPI(
    app_id="2024XXXXXXXXXXXX",
    private_key="-----BEGIN RSA PRIVATE KEY-----\n...",
    alipay_public_key="-----BEGIN PUBLIC KEY-----\n...",
    sandbox=False
)

# 创建预创建订单
url = api.create_order(
    order_no="ORDER202405211200001",
    amount=100.00,
    subject="商品购买",
    body="测试商品",
    timeout="30m"
)

# 查询订单
result = api.query_order("ORDER202405211200001")

# 退款
result = api.refund(
    order_no="ORDER202405211200001",
    refund_amount=50.00,
    reason="用户申请退款"
)
```

### 易支付 (EasyPayAPI)

```python
from payments.easypay import EasyPayAPI

api = EasyPayAPI(
    pid="1000",
    key="your_communication_key",
    api_url="https://pay.easypay.com"
)

url = api.create_order(
    order_no="ORDER001",
    amount=50.00,
    subject="充值",
    channel="alipay"
)

# 验证异步通知
is_valid = api.verify_notify(notify_params)
```

### 微信支付 (WechatAPI)

```python
from payments.wechat import WechatAPI

api = WechatAPI(
    mch_id="1234567890",
    api_key="your_api_key",
    app_id="wx..."
)

xml = api.create_order(
    order_no="ORDER001",
    amount=200.00,
    subject="微信支付测试",
    trade_type="NATIVE"
)

result = api.parse_response(xml_response)
```

### Stripe (StripeAPI)

```python
from payments.stripe_pay import StripeAPI

api = StripeAPI(
    secret_key="sk_live_...",
    currency="cny"
)

# 创建PaymentIntent
intent = api.create_payment_intent(
    amount=99.99,
    currency="usd",
    metadata={"order_id": "ORDER001"}
)

# 查询
result = api.retrieve_payment_intent("pi_...")
```

## 智能路由

```python
from payments.router import SmartRouter

router = SmartRouter()

# 自动选择通道
provider = router.select(5000)  # 返回 'stripe'

# 获取路由详情
info = router.get_route_info(1000)
# {
#   'provider': 'alipay',
#   'name': '支付宝官方',
#   'fee_rate': 0.006,
#   'estimated_fee': 6.0,
#   'actual_amount': 994.0
# }

# 对比所有通道
comparison = router.compare(1000)
```

## 二维码引擎

```python
from core.qr_engine import QREngine

engine = QREngine()

# 生成二维码
result = engine.generate(
    provider="alipay",
    amount=88.88,
    note="测试订单",
    recipient="商家名称",
    avatar="head.jpg",
    no_password=True,
    permanent=True,
    size=512,
    output="qr.png"
)

# 生成SVG
engine.generate_svg("https://example.com", "qr.svg")
```

## 加密工具

```python
from core.crypto import CryptoUtil

# MD5签名
sign = CryptoUtil.md5_sign(
    {"pid": "1000", "money": "100"},
    key="secret_key"
)

# RSA2签名
sign = CryptoUtil.rsa2_sign(
    {"app_id": "2024...", "method": "alipay.trade.precreate"},
    private_key="-----BEGIN RSA PRIVATE KEY-----\n..."
)

# 验证签名
is_valid = CryptoUtil.verify_rsa2(
    params, signature, public_key
)
```

## 盲签工具

```python
from utils.blind_sign import BlindSigner

signer = BlindSigner()

# 盲化消息
blinded = signer.blind_message("message", public_key)

# 签名
blind_sig = signer.sign_blinded(blinded['blinded_message'], private_key)

# 去盲化
signature = signer.unblind_signature(blind_sig, blinded['blind_factor'], public_key)

# 验证
is_valid = signer.verify("message", signature, public_key)
```
