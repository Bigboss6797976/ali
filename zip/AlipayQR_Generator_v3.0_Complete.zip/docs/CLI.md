# CLI命令行工具文档

## 安装

```bash
pip install alipayqr
# 或
pip install -e .
```

## 基本用法

### 生成收款码
```bash
# 支付宝
alipayqr --provider alipay --amount 100 --note "商品购买"

# 微信
alipayqr --provider wechat --amount 200 --recipient "商家"

# Stripe
alipayqr --provider stripe --amount 99.99 --currency usd
```

### 智能路由
```bash
# 自动选择最优通道
alipayqr --provider auto --amount 5000
# 输出: 选择 Stripe (大额)
```

### 解析二维码
```bash
alipayqr --parse qr_code.png
# 输出JSON格式的解析结果
```

### 自定义样式
```bash
alipayqr --provider alipay --amount 88.88 \
  --avatar head.jpg \
  --color "#FF6B6B" \
  --bg-color "#FFF5F5"
```

## 完整参数列表

| 参数 | 简写 | 说明 | 示例 |
|------|------|------|------|
| `--provider` | `-p` | 支付通道 | `alipay`, `wechat`, `stripe`, `easypay`, `auto` |
| `--amount` | `-a` | 金额 | `100.00` |
| `--note` | `-n` | 备注 | `"测试订单"` |
| `--recipient` | `-r` | 收款方 | `"商家名称"` |
| `--account` | | 自定义账号 | `"your@email.com"` |
| `--avatar` | | 头像图片 | `head.jpg` |
| `--color` | | 二维码颜色 | `#000000` |
| `--bg-color` | | 背景色 | `#FFFFFF` |
| `--no-password` | | 免密支付 | 开关 |
| `--permanent` | | 永久有效 | 开关 |
| `--fixed` | | 固定金额 | 开关 |
| `--output` | `-o` | 输出文件 | `qr.png` |
| `--format` | | 输出格式 | `png`, `svg`, `pdf` |
| `--size` | | 尺寸 | `512` |
| `--config` | `-c` | 配置文件 | `config.json` |
| `--parse` | | 解析图片 | `qr.png` |
| `--verbose` | `-v` | 详细输出 | 开关 |
| `--save-config` | | 保存配置 | 开关 |

## 配置文件示例

```json
{
  "alipay": {
    "app_id": "2024XXXXXXXXXXXX",
    "private_key": "app_private_key.pem",
    "alipay_public_key": "alipay_public_key.pem",
    "sandbox": false
  },
  "easypay": {
    "pid": "1000",
    "key": "your_key",
    "api_url": "https://pay.easypay.com"
  },
  "wechat": {
    "mch_id": "1234567890",
    "api_key": "your_api_key",
    "app_id": "wx..."
  },
  "stripe": {
    "secret_key": "sk_live_...",
    "currency": "cny"
  }
}
```

## 批量生成

```bash
# 使用shell循环
for amount in 10 50 100 200 500; do
  alipayqr --provider alipay --amount $amount --output "qr_$amount.png"
done
```
