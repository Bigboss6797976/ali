# 移动端安装指南

## iOS (iPhone/iPad)
1. 用 Safari 打开 index.html
2. 点击底部 "分享" 按钮
3. 选择 "添加到主屏幕"
4. 完成！像原生App一样使用

## Android
1. 用 Chrome 打开 index.html
2. 点击菜单 → "添加到主屏幕"
3. 或点击地址栏弹出的 "安装应用"
4. 完成！支持离线使用

## 平板 (iPad/Android Tablet)
- 自动适配横竖屏
- 支持分屏使用
- 响应式布局优化

## 桌面端
- Windows: 双击 start.bat
- Mac/Linux: 运行 ./start.sh
- 或直接双击 index.html 用浏览器打开
