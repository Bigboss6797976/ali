#!/bin/bash
# AlipayQR v3.0 - macOS/Linux 一键安装脚本

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}   AlipayQR v3.0 - 一键安装${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# 检查Python
echo -e "${YELLOW}[*] 检查 Python...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo -e "${RED}[!] 未找到 Python，请先安装 Python 3.8+${NC}"
    echo "    macOS: brew install python3"
    echo "    Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "    CentOS: sudo yum install python3 python3-pip"
    exit 1
fi
echo -e "${GREEN}[+] Python 已找到: $($PYTHON --version)${NC}"

# 检查Node.js
echo -e "${YELLOW}[*] 检查 Node.js...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}[!] 未找到 Node.js，正在安装...${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        if command -v brew &> /dev/null; then
            brew install node
        else
            echo -e "${RED}[!] 请先安装 Homebrew: https://brew.sh${NC}"
            exit 1
        fi
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if command -v apt &> /dev/null; then
            curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
            sudo apt-get install -y nodejs
        elif command -v yum &> /dev/null; then
            curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
            sudo yum install -y nodejs
        fi
    fi
    echo -e "${GREEN}[+] Node.js 安装完成${NC}"
else
    echo -e "${GREEN}[+] Node.js 已找到: $(node --version)${NC}"
fi

# 安装Python依赖
echo -e "${YELLOW}[*] 安装 Python 依赖...${NC}"
$PYTHON -m pip install --upgrade pip
$PYTHON -m pip install -r requirements.txt
echo -e "${GREEN}[+] Python 依赖安装完成${NC}"

# 安装Node依赖
echo -e "${YELLOW}[*] 安装 Node 依赖...${NC}"
npm install
echo -e "${GREEN}[+] Node 依赖安装完成${NC}"

# 创建启动脚本
echo -e "${YELLOW}[*] 创建启动脚本...${NC}"
cat > alipayqr.desktop << EOF
[Desktop Entry]
Name=AlipayQR
Comment=收款码生成器
Exec=$(pwd)/start.sh
Icon=$(pwd)/icon.svg
Terminal=false
Type=Application
Categories=Office;Finance;
EOF
chmod +x alipayqr.desktop

# 尝试添加到应用菜单
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    mkdir -p ~/.local/share/applications/
    cp alipayqr.desktop ~/.local/share/applications/ 2>/dev/null || true
    update-desktop-database ~/.local/share/applications/ 2>/dev/null || true
fi

echo -e "${GREEN}[+] 启动脚本已创建${NC}"

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   安装完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${CYAN}使用方式:${NC}"
echo -e "  ${WHITE}1. Web版本: ./start.sh${NC}"
echo -e "  ${WHITE}2. CLI版本: $PYTHON src/cli/alipayqr.py --help${NC}"
echo -e "  ${WHITE}3. 桌面版本: npm run build${NC}"
echo ""
