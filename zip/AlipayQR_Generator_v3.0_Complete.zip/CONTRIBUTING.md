# 贡献指南

## 开发环境搭建

```bash
git clone https://github.com/yourname/alipayqr.git
cd alipayqr
pip install -r requirements.txt
pip install -e .
npm install
```

## 代码规范

- Python: 遵循 PEP 8
- JavaScript: 使用 ESLint 标准配置
- 提交前运行测试: `pytest tests/`

## 提交PR流程

1. Fork 仓库
2. 创建特性分支: `git checkout -b feature/xxx`
3. 提交更改: `git commit -am 'Add xxx'`
4. 推送分支: `git push origin feature/xxx`
5. 创建 Pull Request

## 测试要求

- 新增功能必须包含测试用例
- 所有测试必须通过
- 覆盖率不低于 80%
