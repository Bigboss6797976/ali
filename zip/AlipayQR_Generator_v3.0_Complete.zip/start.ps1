# AlipayQR v3.0 - 启动脚本
$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   AlipayQR v3.0 - 收款码生成器" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查是否有Electron桌面版
if (Test-Path "dist-electron\win-unpacked\AlipayQR.exe") {
    Write-Host "[*] 启动桌面版..." -ForegroundColor Green
    & "dist-electron\win-unpacked\AlipayQR.exe"
    exit
}

# 启动Web服务器
Write-Host "[*] 启动 Web 服务器..." -ForegroundColor Yellow
Write-Host "    访问地址: http://localhost:8080" -ForegroundColor Cyan
Write-Host "    按 Ctrl+C 停止" -ForegroundColor Gray
Write-Host ""

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command python3 }

& $python.Source -m http.server 8080
