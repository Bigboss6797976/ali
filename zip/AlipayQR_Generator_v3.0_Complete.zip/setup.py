from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="alipayqr",
    version="3.0.0",
    author="AlipayQR Team",
    description="多通道聚合收款码生成器 - 支持支付宝/微信/Stripe/易支付",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/alipayqr",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business :: Financial",
    ],
    python_requires=">=3.8",
    install_requires=[
        "qrcode[pil]>=7.0",
        "Pillow>=9.0",
        "pycryptodome>=3.15",
        "cryptography>=3.4",
        "requests>=2.28",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
        "camera": [
            "opencv-python>=4.5",
            "pyzbar>=0.1.9",
        ],
        "all": [
            "opencv-python>=4.5",
            "pyzbar>=0.1.9",
            "zxing>=0.14",
        ]
    },
    entry_points={
        "console_scripts": [
            "alipayqr=cli.alipayqr:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)