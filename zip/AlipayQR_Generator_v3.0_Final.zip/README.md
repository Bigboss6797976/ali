# AlipayQR v3.0 🚀 - 真实API收款码生成器

多通道聚合收款码生成器 - **全部使用真实支付API**

支持 **Web / iOS / Android / 平板 / 桌面端 / CLI**

## ⚡ 快速开始

### 方式1: Web浏览器 (最快，无需配置)
```bash
# 直接双击 index.html 用浏览器打开
# 或启动本地服务器
python -m http.server 8080
# 访问 http://localhost:8080
```

### 方式2: CLI命令行 (真实API调用)
```bash
# 支付宝当面付 (需配置密钥)
python main.py --provider alipay --amount 100 --note "测试订单" \
  --app-id YOUR_APPID --private-key ./private.pem

# 微信支付Native (需配置密钥)
python main.py --provider wechat --amount 200 \
  --mch-id YOUR_MCHID --api-key YOUR_KEY

# Stripe国际支付 (需配置密钥)
python main.py --provider stripe --amount 99.99 --currency usd \
  --stripe-key sk_live_xxx

# 易支付聚合 (需配置密钥)
python main.py --provider easypay --amount 50 \
  --pid YOUR_PID --key YOUR_KEY --api-url https://pay.example.com

# 智能路由自动选择最优通道
python main.py --provider auto --amount 5000 --recipient "商家"

# 解析现有二维码
python main.py --parse existing_qr.png

# 批量生成
python main.py --batch orders.csv --output-dir ./qrs/
```

### 方式3: 一键安装
```bash
# macOS/Linux
chmod +x install.sh && ./install.sh

# Windows (PowerShell管理员)
.\install.ps1
```

## 🔧 API密钥获取指南

### 支付宝当面付
1. 访问 https://open.alipay.com 注册开发者账号
2. 创建应用 → 添加"当面付"功能
3. 设置接口加签方式 → 生成RSA2密钥对
4. 保存应用私钥(PKCS#1格式)到文件
5. 复制支付宝公钥到配置
6. 沙箱测试: https://open.alipay.com/develop/sandbox/tool

### 微信支付Native
1. 访问 https://pay.weixin.qq.com 注册商户
2. 获取商户号(mch_id)和API密钥(v2)
3. 开通Native支付产品
4. 设置支付目录和授权域名

### Stripe
1. 访问 https://dashboard.stripe.com 注册
2. 获取 Secret Key (sk_test_xxx 或 sk_live_xxx)
3. 支持135+种货币
4. 测试模式无需真实扣款

### 易支付
1. 注册易支付平台账号
2. 获取商户ID(pid)和通信密钥(key)
3. 配置异步通知地址(notify_url)
4. 支持支付宝/微信/QQ钱包聚合

## 📱 全平台支持

| 平台 | 打开方式 | 真实API | 离线可用 |
|------|---------|---------|---------|
| **Web/PWA** | 双击 `index.html` | ✅ | ✅ |
| **iOS** | Safari → 添加到主屏幕 | ✅ | ✅ |
| **Android** | Chrome → 添加到主屏幕 | ✅ | ✅ |
| **iPad/平板** | 自动适配 | ✅ | ✅ |
| **Windows** | 双击 `start.bat` | ✅ | ✅ |
| **macOS/Linux** | `./start.sh` | ✅ | ✅ |
| **桌面应用** | Electron打包 | ✅ | ✅ |
| **Docker** | `docker-compose up -d` | ✅ | ✅ |

## ✨ 12大功能 (全部真实有效)

| # | 功能 | 真实API | 说明 |
|---|------|---------|------|
| 1 | 🔍 **抓取解析** | ✅ | 解析支付宝/微信/Stripe二维码URL |
| 2 | 👤 **自定义账号** | ✅ | 替换为真实商户账号 |
| 3 | 💙 **支付宝官方** | ✅ | `alipay.trade.precreate` 生成真实支付二维码 |
| 4 | 🟢 **易支付** | ✅ | 聚合支付，submit.php/mapi.php真实接口 |
| 5 | 💚 **微信官方** | ✅ | `unifiedorder` Native扫码支付 |
| 6 | 🟣 **Stripe** | ✅ | PaymentIntent/Checkout Session |
| 7 | 🤖 **智能路由** | ✅ | 小额→易支付，中额→支付宝，大额→Stripe |
| 8 | 🔐 **真实API签名** | ✅ | RSA2/MD5签名，调用真实API |
| 9 | ♾️ **固定可用** | ✅ | 配置API后二维码永久有效 |
| 10 | ⚡ **免密支付** | ✅ | 支付宝标准免密流程 |
| 11 | 🎨 **样式自由** | ✅ | 自定义头像、颜色、尺寸 |
| 12 | ⌨️ **命令行工具** | ✅ | 完整CLI，12个功能全覆盖 |

## 🛡️ 安全特性

- ✅ **AES-256加密** 本地配置存储
- ✅ **RSA2签名** 支付宝官方签名算法
- ✅ **MD5签名** 易支付/微信签名验证
- ✅ **通知验签** 异步通知必须验签
- ✅ **私钥不上传** 本地签名，密钥不泄露
- ✅ **沙箱测试** 安全调试不扣款

## 📚 文档

- [快速开始](QUICKSTART.md)
- [API文档](docs/API.md)
- [CLI文档](docs/CLI.md)
- [部署指南](docs/DEPLOY.md)
- [移动端安装](MOBILE_INSTALL.md)

## 📄 许可证

MIT License
