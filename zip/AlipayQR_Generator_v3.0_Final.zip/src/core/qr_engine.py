# -*- coding: utf-8 -*-
"""
二维码生成引擎 - 生成真实可支付的二维码

支持:
- 支付宝: 调用alipay.trade.precreate获取真实qr_code
- 微信: 调用unifiedorder获取真实code_url
- Stripe: 生成Checkout Session URL
- 易支付: 生成聚合支付跳转URL
"""

import qrcode
import qrcode.image.svg
from PIL import Image, ImageDraw, ImageFont
import os
import base64
import uuid
from datetime import datetime
import urllib.parse

class QREngine:
    """
    二维码生成引擎

    生成真实可支付的二维码图片
    """

    def __init__(self):
        self.version = 5
        self.error_correction = qrcode.constants.ERROR_CORRECT_H
        self.box_size = 10
        self.border = 2

    def generate(self, provider, amount=None, note=None, recipient=None,
                 account=None, avatar=None, no_password=False,
                 permanent=False, api=None, size=512, output='qr_output.png',
                 notify_url=None, return_url=None):
        """
        生成收款码 - 调用真实API

        Args:
            provider: 支付通道 (alipay/wechat/stripe/easypay)
            amount: 金额 (元)
            note: 订单备注
            recipient: 收款方名称
            account: 自定义账号
            avatar: 头像图片路径
            no_password: 是否免密支付
            permanent: 是否永久有效
            api: API实例 (AlipayAPI/WechatAPI/StripeAPI/EasyPayAPI)
            size: 二维码尺寸
            output: 输出文件路径
            notify_url: 异步通知地址
            return_url: 同步跳转地址

        Returns:
            dict: {success, qr_url, provider_name, order_no, output, ...}
        """

        # 生成唯一订单号
        order_no = f"ORDER{datetime.now().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6].upper()}"

        qr_url = None
        provider_name = self._get_provider_name(provider)

        # 调用真实API生成支付URL
        if api:
            if provider == 'alipay' and hasattr(api, 'create_order'):
                result = api.create_order(
                    order_no=order_no,
                    amount=amount or 0.01,
                    subject=note or '收款',
                    body=recipient or '二维码收款',
                    notify_url=notify_url,
                    return_url=return_url
                )
                if result.get('success'):
                    qr_url = result.get('qr_code')
                else:
                    return {
                        'success': False,
                        'error': result.get('error', '支付宝API调用失败'),
                        'provider': provider,
                        'order_no': order_no
                    }

            elif provider == 'wechat' and hasattr(api, 'unifiedorder'):
                result = api.unifiedorder(
                    order_no=order_no,
                    amount=amount or 0.01,
                    body=note or '收款',
                    notify_url=notify_url
                )
                if result.get('success'):
                    qr_url = result.get('code_url')
                else:
                    return {
                        'success': False,
                        'error': result.get('error', '微信支付API调用失败'),
                        'provider': provider,
                        'order_no': order_no
                    }

            elif provider == 'stripe' and hasattr(api, 'create_checkout_session'):
                result = api.create_checkout_session(
                    amount=amount or 0.01,
                    metadata={'order_no': order_no, 'note': note or ''},
                    success_url=return_url or 'https://example.com/success',
                    cancel_url='https://example.com/cancel'
                )
                if 'error' not in result:
                    qr_url = result.get('url')
                else:
                    return {
                        'success': False,
                        'error': result.get('message', 'Stripe API调用失败'),
                        'provider': provider,
                        'order_no': order_no
                    }

            elif provider == 'easypay' and hasattr(api, 'submit'):
                result = api.submit(
                    order_no=order_no,
                    amount=amount or 0.01,
                    name=note or '收款',
                    notify_url=notify_url or 'https://example.com/notify',
                    return_url=return_url or 'https://example.com/return'
                )
                if result.get('success'):
                    qr_url = result.get('pay_url')
                else:
                    return {
                        'success': False,
                        'error': result.get('error', '易支付API调用失败'),
                        'provider': provider,
                        'order_no': order_no
                    }

        # 如果没有API实例或API调用失败，生成静态URL (仅用于展示)
        if not qr_url:
            qr_url = self._generate_fallback_url(provider, order_no, amount, note, recipient, account)

        # 生成二维码图片
        try:
            img = self._generate_qr_image(qr_url, size, avatar)
            img.save(output)

            return {
                'success': True,
                'provider': provider,
                'provider_name': provider_name,
                'order_no': order_no,
                'qr_url': qr_url,
                'output': os.path.abspath(output),
                'size': size,
                'amount': amount,
                'note': note,
                'is_real_payment': api is not None
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'二维码生成失败: {str(e)}',
                'provider': provider,
                'order_no': order_no
            }

    def _generate_qr_image(self, qr_url, size=512, avatar=None):
        """生成二维码图片"""
        qr = qrcode.QRCode(
            version=None,
            error_correction=self.error_correction,
            box_size=10,
            border=2,
        )
        qr.add_data(qr_url)
        qr.make(fit=True)

        # 生成图像
        img = qr.make_image(fill_color="black", back_color="white").convert('RGBA')
        img = img.resize((size, size), Image.LANCZOS)

        # 添加头像
        if avatar and os.path.exists(avatar):
            img = self._add_avatar(img, avatar)

        # 添加装饰边框
        img = self._add_decoration(img)

        return img

    def _add_avatar(self, img, avatar_path):
        """在二维码中心添加头像"""
        try:
            avatar = Image.open(avatar_path).convert('RGBA')
            avatar_size = int(img.width * 0.22)
            avatar = avatar.resize((avatar_size, avatar_size), Image.LANCZOS)

            # 创建圆形遮罩
            mask = Image.new('L', (avatar_size, avatar_size), 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, avatar_size, avatar_size), fill=255)

            # 白色背景+头像
            bg = Image.new('RGBA', (avatar_size + 8, avatar_size + 8), (255, 255, 255, 255))
            bg.paste(avatar, (4, 4), mask)

            pos = ((img.width - bg.width) // 2, (img.height - bg.height) // 2)
            img.paste(bg, pos)
        except Exception as e:
            print(f"[!] 头像添加失败: {e}")
        return img

    def _add_decoration(self, img):
        """添加装饰元素"""
        draw = ImageDraw.Draw(img)
        border_width = 4
        draw.rectangle(
            [border_width//2, border_width//2, 
             img.width-border_width//2, img.height-border_width//2],
            outline='#1677FF', width=border_width
        )
        return img

    def _generate_fallback_url(self, provider, order_no, amount, note, recipient, account):
        """
        生成备用URL (当没有API密钥时使用)

        这些URL仅用于展示，无法真正完成支付
        配置真实API后可生成可支付的二维码
        """
        base_urls = {
            'alipay': f'https://qr.alipay.com/fkx{base64.b64encode(order_no.encode()).decode().replace("=","")[:16]}',
            'wechat': f'weixin://wxpay/bizpayurl?pr={order_no[:16]}',
            'stripe': f'https://pay.stripe.com/{order_no}',
            'easypay': f'https://pay.easypay.com/{order_no}'
        }

        url = base_urls.get(provider, base_urls['alipay'])

        params = []
        if amount:
            params.append(f'a={amount}')
        if note:
            params.append(f'n={urllib.parse.quote(note)}')
        if recipient:
            params.append(f'r={urllib.parse.quote(recipient)}')
        if account:
            params.append(f'acc={base64.b64encode(account.encode()).decode()}')

        if params:
            url += '?' + '&'.join(params)

        return url

    def _get_provider_name(self, provider):
        """获取通道名称"""
        names = {
            'alipay': '支付宝官方',
            'wechat': '微信官方',
            'stripe': 'Stripe',
            'easypay': '易支付'
        }
        return names.get(provider, provider)

    def generate_svg(self, qr_url, output='qr_output.svg'):
        """生成SVG格式二维码"""
        factory = qrcode.image.svg.SvgImage
        qr = qrcode.QRCode(image_factory=factory)
        qr.add_data(qr_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(output)
        return output

    def generate_with_logo(self, qr_url, logo_path, output='qr_with_logo.png', size=512):
        """生成带Logo的二维码"""
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=2,
        )
        qr.add_data(qr_url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white").convert('RGBA')
        img = img.resize((size, size), Image.LANCZOS)

        if os.path.exists(logo_path):
            logo = Image.open(logo_path).convert('RGBA')
            logo_size = int(size * 0.25)
            logo = logo.resize((logo_size, logo_size), Image.LANCZOS)

            # 居中放置
            pos = ((size - logo_size) // 2, (size - logo_size) // 2)
            img.paste(logo, pos, logo)

        img.save(output)
        return output
