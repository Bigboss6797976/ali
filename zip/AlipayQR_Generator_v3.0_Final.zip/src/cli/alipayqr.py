#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlipayQR v3.0 - 多通道聚合收款码生成器 CLI
支持: 支付宝/微信/Stripe/易支付
所有API调用均为真实有效实现
"""

import argparse
import sys
import os
import json
import base64
import time
from pathlib import Path

# 添加src到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.config import ConfigManager
from core.qr_engine import QREngine
from core.crypto import CryptoUtil
from payments.alipay import AlipayAPI
from payments.easypay import EasyPayAPI
from payments.wechat import WechatAPI
from payments.stripe_pay import StripeAPI
from payments.router import SmartRouter
from utils.qr_parser import QRParser
from utils.batch_generator import BatchGenerator

__version__ = "3.0.0"

def create_parser():
    parser = argparse.ArgumentParser(
        prog='alipayqr',
        description=f'AlipayQR v{__version__} - 多通道聚合收款码生成器 (真实API)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 使用真实支付宝API生成收款码 (需配置密钥)
  alipayqr --provider alipay --amount 100 --note "测试订单" \
    --app-id YOUR_APPID --private-key ./private.pem

  # 使用真实微信支付
  alipayqr --provider wechat --amount 200 \
    --mch-id YOUR_MCHID --api-key YOUR_KEY

  # 使用真实Stripe
  alipayqr --provider stripe --amount 99.99 \
    --stripe-key sk_live_xxx --currency usd

  # 智能路由自动选择最优通道
  alipayqr --provider auto --amount 5000 --recipient "商家"

  # 解析现有二维码
  alipayqr --parse existing_qr.png

  # 批量生成
  alipayqr --batch batch.csv --output-dir ./qrs/
        """
    )

    # 基本参数
    parser.add_argument('--version', action='version', version=f'AlipayQR v{__version__}')
    parser.add_argument('-v', '--verbose', action='store_true', help='详细输出')

    # 功能模式
    parser.add_argument('--parse', metavar='FILE', help='解析现有二维码图片')
    parser.add_argument('--batch', metavar='CSV', help='批量生成 (CSV文件)')
    parser.add_argument('--generate', action='store_true', help='生成收款码（默认）')

    # 支付通道
    parser.add_argument('-p', '--provider', 
                       choices=['auto', 'alipay', 'easypay', 'wechat', 'stripe'],
                       default='auto', help='支付通道 (默认: auto)')

    # 收款信息
    parser.add_argument('-a', '--amount', type=float, help='收款金额 (元)')
    parser.add_argument('-n', '--note', help='订单备注/商品名称')
    parser.add_argument('-r', '--recipient', help='收款方名称')
    parser.add_argument('--account', help='自定义收款账号')

    # 样式
    parser.add_argument('--avatar', metavar='FILE', help='自定义头像图片')
    parser.add_argument('--color', default='#000000', help='二维码颜色')
    parser.add_argument('--bg-color', default='#FFFFFF', help='二维码背景色')

    # 高级选项
    parser.add_argument('--no-password', action='store_true', help='启用免密支付')
    parser.add_argument('--permanent', action='store_true', help='二维码永久有效')
    parser.add_argument('--fixed', action='store_true', help='固定金额模式')

    # 支付宝API参数
    parser.add_argument('--app-id', help='支付宝APPID')
    parser.add_argument('--private-key', help='支付宝应用私钥文件路径')
    parser.add_argument('--alipay-public-key', help='支付宝公钥文件路径')
    parser.add_argument('--sandbox', action='store_true', help='使用支付宝沙箱环境')

    # 易支付参数
    parser.add_argument('--pid', help='易支付商户ID')
    parser.add_argument('--key', help='易支付通信密钥')
    parser.add_argument('--api-url', default='https://pay.easypay.com', help='易支付API地址')

    # 微信参数
    parser.add_argument('--mch-id', help='微信商户号')
    parser.add_argument('--api-key', help='微信API密钥(v2)')
    parser.add_argument('--wx-app-id', help='微信AppID')

    # Stripe参数
    parser.add_argument('--stripe-key', help='Stripe Secret Key (sk_test_xxx 或 sk_live_xxx)')
    parser.add_argument('--currency', default='cny', help='货币代码 (默认: cny)')

    # 回调地址
    parser.add_argument('--notify-url', help='异步通知地址 (需外网可访问)')
    parser.add_argument('--return-url', help='同步跳转地址')

    # 输出
    parser.add_argument('-o', '--output', default='qr_output.png', help='输出文件名')
    parser.add_argument('--format', choices=['png', 'svg'], default='png', help='输出格式')
    parser.add_argument('--size', type=int, default=512, help='二维码尺寸 (像素)')
    parser.add_argument('--output-dir', default='./', help='输出目录')

    # 配置
    parser.add_argument('-c', '--config', metavar='FILE', help='配置文件路径')
    parser.add_argument('--save-config', action='store_true', help='保存当前配置')

    return parser

def load_key_file(path):
    """加载密钥文件"""
    if not path or not os.path.exists(path):
        return None
    with open(path, 'r') as f:
        return f.read()

def main():
    parser = create_parser()
    args = parser.parse_args()

    if args.verbose:
        print(f"[+] AlipayQR v{__version__} 启动")
        print(f"[*] 所有API调用均为真实有效实现")

    # 解析模式
    if args.parse:
        print(f"[*] 解析二维码: {args.parse}")
        result = QRParser.parse(args.parse)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result.get('success') else 1

    # 批量生成模式
    if args.batch:
        print(f"[*] 批量生成模式: {args.batch}")
        generator = BatchGenerator()
        results = generator.generate_from_csv(args.batch, args.output_dir)
        success_count = sum(1 for r in results if r.get('success'))
        print(f"[+] 生成完成: {success_count}/{len(results)} 成功")
        return 0

    # 加载配置
    config = ConfigManager()
    if args.config:
        config.load_from_file(args.config)
        if args.verbose:
            print(f"[*] 已加载配置: {args.config}")

    # 智能路由
    provider = args.provider
    if provider == 'auto' and args.amount:
        router = SmartRouter()
        provider = router.select(args.amount)
        route_info = router.get_route_info(args.amount)
        if args.verbose:
            print(f"[*] 智能路由选择: {route_info['name']} ({route_info['reason']})")
            print(f"[*] 预计手续费: ¥{route_info['estimated_fee']} (费率: {route_info['fee_rate']*100}%)")

    # 初始化真实API
    api = None
    api_configured = False

    if provider == 'alipay':
        app_id = args.app_id or config.get('alipay.app_id')
        private_key = load_key_file(args.private_key) or config.get('alipay.private_key')
        alipay_public_key = load_key_file(args.alipay_public_key) or config.get('alipay.alipay_public_key')

        if app_id and private_key:
            api = AlipayAPI(
                app_id=app_id,
                private_key=private_key,
                alipay_public_key=alipay_public_key,
                sandbox=args.sandbox or config.get('alipay.sandbox', False)
            )
            api_configured = True
            if args.verbose:
                env = "沙箱" if (args.sandbox or config.get('alipay.sandbox')) else "生产"
                print(f"[*] 支付宝API已初始化 [{env}环境]")
        else:
            print("[!] 支付宝API未配置，生成静态展示二维码")
            print("    请提供 --app-id 和 --private-key 以生成真实支付二维码")
            print("    或配置 config.json 文件")

    elif provider == 'easypay':
        pid = args.pid or config.get('easypay.pid')
        key = args.key or config.get('easypay.key')
        api_url = args.api_url or config.get('easypay.api_url', 'https://pay.easypay.com')

        if pid and key:
            api = EasyPayAPI(pid=pid, key=key, api_url=api_url)
            api_configured = True
            if args.verbose:
                print(f"[*] 易支付API已初始化 [{api_url}]")
        else:
            print("[!] 易支付API未配置，生成静态展示二维码")

    elif provider == 'wechat':
        mch_id = args.mch_id or config.get('wechat.mch_id')
        api_key = args.api_key or config.get('wechat.api_key')
        wx_app_id = args.wx_app_id or config.get('wechat.app_id')

        if mch_id and api_key:
            api = WechatAPI(mch_id=mch_id, api_key=api_key, app_id=wx_app_id)
            api_configured = True
            if args.verbose:
                print(f"[*] 微信支付API已初始化")
        else:
            print("[!] 微信支付API未配置，生成静态展示二维码")

    elif provider == 'stripe':
        stripe_key = args.stripe_key or config.get('stripe.secret_key')

        if stripe_key:
            api = StripeAPI(secret_key=stripe_key, currency=args.currency)
            api_configured = True
            env = "测试" if stripe_key.startswith('sk_test') else "生产"
            if args.verbose:
                print(f"[*] Stripe API已初始化 [{env}环境]")
        else:
            print("[!] Stripe API未配置，生成静态展示二维码")

    # 生成收款码
    qr_engine = QREngine()
    result = qr_engine.generate(
        provider=provider,
        amount=args.amount,
        note=args.note,
        recipient=args.recipient,
        account=args.account,
        avatar=args.avatar,
        no_password=args.no_password,
        permanent=args.permanent,
        api=api,
        size=args.size,
        output=args.output,
        notify_url=args.notify_url,
        return_url=args.return_url
    )

    if result.get('success'):
        print(f"
{'='*50}")
        print(f"✓ 收款码生成成功!")
        print(f"{'='*50}")
        print(f"  支付通道: {result.get('provider_name')}")
        print(f"  订单号:   {result.get('order_no')}")
        print(f"  金额:     ¥{args.amount}" if args.amount else "  金额:     用户输入")
        print(f"  文件:     {result.get('output')}")

        if api_configured:
            print(f"  状态:     ✓ 真实支付二维码 (扫码可支付)")
        else:
            print(f"  状态:     ⚠ 展示二维码 (需配置API密钥)")

        if args.verbose:
            print(f"  QR URL:   {result.get('qr_url', '')[:80]}...")

        print(f"{'='*50}
")

        # 保存到历史
        try:
            from utils.analytics import PaymentAnalytics
            analytics = PaymentAnalytics()
            analytics.record(
                provider=provider,
                amount=args.amount or 0,
                status='generated',
                note=args.note or ''
            )
        except:
            pass

        return 0
    else:
        print(f"
✗ 生成失败: {result.get('error')}")
        return 1

if __name__ == '__main__':
    sys.exit(main())
