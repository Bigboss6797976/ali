# -*- coding: utf-8 -*-
"""
Stripe - 国际支付API真实实现
文档: https://stripe.com/docs/api/payment_intents
"""

import json
import urllib.request
import urllib.parse
import base64

class StripeAPI:
    """
    Stripe支付API - 支持多币种国际支付

    使用流程:
    1. 调用 create_payment_intent() 创建PaymentIntent
    2. 获取 client_secret 用于前端确认支付
    3. 或生成Stripe Checkout URL用于扫码支付

    支持的货币: cny, usd, eur, gbp, jpy, hkd, sgd 等135+

    测试密钥: sk_test_...
    生产密钥: sk_live_...
    """

    BASE_URL = "https://api.stripe.com/v1"

    def __init__(self, secret_key, currency='cny'):
        """
        初始化Stripe API

        Args:
            secret_key: Stripe Secret Key (sk_test_xxx 或 sk_live_xxx)
            currency: 默认货币代码 (ISO 4217)
        """
        self.secret_key = secret_key
        self.currency = currency.lower()
        self._auth_header = f"Bearer {secret_key}"

    def _request(self, endpoint, data=None, method='GET'):
        """
        发送API请求

        Stripe API使用Basic Auth，密钥作为用户名
        """
        url = f"{self.BASE_URL}{endpoint}"

        headers = {
            "Authorization": self._auth_header,
            "Content-Type": "application/x-www-form-urlencoded"
        }

        encoded_data = None
        if data and method == 'POST':
            encoded_data = urllib.parse.urlencode(data).encode('utf-8')

        req = urllib.request.Request(
            url,
            data=encoded_data,
            headers=headers,
            method=method
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                return json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8')
            try:
                error_json = json.loads(error_body)
                return {
                    'error': True,
                    'type': error_json.get('error', {}).get('type'),
                    'message': error_json.get('error', {}).get('message'),
                    'code': error_json.get('error', {}).get('code'),
                    'decline_code': error_json.get('error', {}).get('decline_code'),
                    'status_code': e.code,
                    'raw': error_json
                }
            except:
                return {'error': True, 'message': error_body, 'status_code': e.code}
        except Exception as e:
            return {'error': True, 'message': str(e)}

    def create_payment_intent(self, amount, currency=None, metadata=None, 
                            description=None, receipt_email=None,
                            automatic_payment_methods=True,
                            payment_method_types=None):
        """
        创建PaymentIntent - 生成支付会话

        Args:
            amount: 金额 (元，会自动转为分/最小单位)
            currency: 货币代码 (默认构造函数中的currency)
            metadata: 元数据字典 (如订单号等)
            description: 订单描述
            receipt_email: 收据邮箱
            automatic_payment_methods: 自动支付方式
            payment_method_types: 指定支付方式 ['card', 'alipay', 'wechat_pay']

        Returns:
            dict: PaymentIntent对象
                - id: pi_xxx
                - client_secret: 前端确认支付用
                - status: requires_payment_method / requires_confirmation / succeeded
        """
        # Stripe金额需要转为最小单位
        currency = (currency or self.currency).lower()

        # 零小数货币 (如JPY) 不需要乘100
        zero_decimal_currencies = ['jpy', 'krw', 'vnd', 'clp', 'pyg', 'xaf', 'xof', 'xpf', 'bif', 'djf', 'gnf', 'kmf', 'mga', 'rwf']

        if currency in zero_decimal_currencies:
            amount_cents = int(float(amount))
        else:
            amount_cents = int(float(amount) * 100)

        data = {
            "amount": str(amount_cents),
            "currency": currency,
        }

        if automatic_payment_methods:
            data["automatic_payment_methods[enabled]"] = "true"

        if payment_method_types:
            for i, pmt in enumerate(payment_method_types):
                data[f"payment_method_types[{i}]"] = pmt

        if description:
            data["description"] = description

        if receipt_email:
            data["receipt_email"] = receipt_email

        if metadata:
            for k, v in metadata.items():
                data[f"metadata[{k}]"] = str(v)

        return self._request('/payment_intents', data, 'POST')

    def retrieve_payment_intent(self, payment_intent_id):
        """
        查询PaymentIntent状态

        状态: requires_payment_method / requires_confirmation / 
              requires_action / processing / requires_capture / 
              canceled / succeeded
        """
        return self._request(f'/payment_intents/{payment_intent_id}')

    def confirm_payment_intent(self, payment_intent_id, payment_method=None):
        """
        确认PaymentIntent

        通常在服务端完成，或前端使用Stripe.js
        """
        data = {}
        if payment_method:
            data["payment_method"] = payment_method
        return self._request(f'/payment_intents/{payment_intent_id}/confirm', data, 'POST')

    def cancel_payment_intent(self, payment_intent_id, cancellation_reason=None):
        """
        取消PaymentIntent

        cancellation_reason: duplicate / fraudulent / requested_by_customer / abandoned
        """
        data = {}
        if cancellation_reason:
            data["cancellation_reason"] = cancellation_reason
        return self._request(f'/payment_intents/{payment_intent_id}/cancel', data, 'POST')

    def create_checkout_session(self, amount, currency=None, success_url=None, 
                               cancel_url=None, line_items=None, mode='payment',
                               metadata=None, customer_email=None):
        """
        创建Checkout Session - 生成支付链接

        返回URL可直接在浏览器打开完成支付
        适合生成二维码让用户扫码支付
        """
        currency = (currency or self.currency).lower()

        if currency in ['jpy', 'krw', 'vnd']:
            amount_cents = int(float(amount))
        else:
            amount_cents = int(float(amount) * 100)

        data = {
            "mode": mode,
            "success_url": success_url or 'https://example.com/success',
            "cancel_url": cancel_url or 'https://example.com/cancel',
        }

        if line_items:
            for i, item in enumerate(line_items):
                data[f"line_items[{i}][price_data][currency]"] = currency
                data[f"line_items[{i}][price_data][unit_amount]"] = str(amount_cents)
                data[f"line_items[{i}][price_data][product_data][name]"] = item.get('name', 'Payment')
                data[f"line_items[{i}][quantity]"] = str(item.get('quantity', 1))
        else:
            # 默认单个商品
            data["line_items[0][price_data][currency]"] = currency
            data["line_items[0][price_data][unit_amount]"] = str(amount_cents)
            data["line_items[0][price_data][product_data][name]"] = "Payment"
            data["line_items[0][quantity]"] = "1"

        if customer_email:
            data["customer_email"] = customer_email

        if metadata:
            for k, v in metadata.items():
                data[f"metadata[{k}]"] = str(v)

        return self._request('/checkout/sessions', data, 'POST')

    def retrieve_checkout_session(self, session_id):
        """查询Checkout Session状态"""
        return self._request(f'/checkout/sessions/{session_id}')

    def create_refund(self, payment_intent_id, amount=None, reason=None):
        """
        创建退款

        reason: duplicate / fraudulent / requested_by_customer
        """
        data = {"payment_intent": payment_intent_id}

        if amount:
            currency = self.currency
            if currency in ['jpy', 'krw', 'vnd']:
                data["amount"] = int(float(amount))
            else:
                data["amount"] = int(float(amount) * 100)

        if reason:
            data["reason"] = reason

        return self._request('/refunds', data, 'POST')

    def list_payment_methods(self, customer_id=None, type='card'):
        """列出支付方式"""
        endpoint = f'/payment_methods?type={type}'
        if customer_id:
            endpoint += f'&customer={customer_id}'
        return self._request(endpoint)

    def get_balance(self):
        """查询账户余额"""
        return self._request('/balance')

    def list_events(self, limit=10, type=None):
        """
        查询Webhook事件

        type: payment_intent.created / payment_intent.succeeded / 
              checkout.session.completed 等
        """
        endpoint = f'/events?limit={limit}'
        if type:
            endpoint += f'&type={type}'
        return self._request(endpoint)
