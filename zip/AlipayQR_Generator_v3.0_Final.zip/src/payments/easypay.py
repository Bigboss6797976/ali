# -*- coding: utf-8 -*-
"""
易支付 - 第三方聚合支付API真实实现

参考接口规范:
- 页面跳转: /submit.php (GET/POST)
- API接口: /mapi.php (POST返回JSON)
- 订单查询: /api.php?act=order
- 商户查询: /api.php?act=query
- 结算记录: /api.php?act=settle

签名算法: MD5(参数按key排序拼接 + KEY)
文档参考: https://ezfp.cn/doc.html
"""

import urllib.request
import urllib.parse
import urllib.error
import json
import hashlib
from core.crypto import CryptoUtil

class EasyPayAPI:
    """
    易支付API - 第三方聚合支付

    支持接口:
    - submit.php: 页面跳转支付 (form或URL跳转)
    - mapi.php: API接口支付 (返回JSON)
    - api.php?act=order: 订单查询
    - api.php?act=query: 商户信息查询
    - api.php?act=settle: 结算记录查询
    - api.php?act=refund: 订单退款

    设备类型: pc/mobile/qq/wechat/alipay
    """

    def __init__(self, pid, key, api_url='https://pay.easypay.com'):
        """
        初始化易支付API

        Args:
            pid: 商户ID (易支付平台分配)
            key: 通信密钥/商户密钥 (商户后台获取)
            api_url: API地址 (各平台不同，如 https://ezfp.cn)
        """
        self.pid = str(pid)
        self.key = str(key)
        self.api_url = api_url.rstrip('/')

    def _sign(self, params):
        """
        MD5签名算法

        1. 参数按key的ASCII码从小到大排序(a-z)
        2. sign、sign_type、空值不参与签名
        3. 拼接成URL键值对格式: a=b&c=d&e=f
        4. 拼接密钥KEY: a=b&c=d&e=f + KEY
        5. MD5加密，结果小写
        """
        # 过滤不参与签名的参数
        filtered = {k: v for k, v in params.items() 
                   if k not in ('sign', 'sign_type') and v is not None and v != ''}

        # 按key排序
        sorted_items = sorted(filtered.items(), key=lambda x: x[0])

        # 拼接字符串
        sign_str = '&'.join([f"{k}={v}" for k, v in sorted_items])

        # 拼接密钥
        sign_str += self.key

        # MD5加密
        return hashlib.md5(sign_str.encode('utf-8')).hexdigest().lower()

    def submit(self, order_no, amount, name, notify_url, return_url,
              channel='alipay', param='', clientip='127.0.0.1', device='pc'):
        """
        页面跳转支付 - 获取支付跳转URL

        URL: {api_url}/submit.php

        Args:
            order_no: 商户订单号 (唯一)
            amount: 金额 (元，最多2位小数)
            name: 商品名称
            notify_url: 异步通知地址 (必须外网可访问)
            return_url: 同步跳转地址
            channel: 支付方式 (alipay/wechat/qq)
            param: 自定义参数 (原样返回)
            clientip: 用户IP
            device: 设备类型 (pc/mobile/qq/wechat/alipay)

        Returns:
            dict: {success, pay_url, order_no, params}
        """
        params = {
            "pid": self.pid,
            "type": channel,
            "out_trade_no": str(order_no),
            "notify_url": notify_url,
            "return_url": return_url,
            "name": str(name),
            "money": str(amount),
            "clientip": clientip,
            "device": device,
            "param": str(param) if param else '',
        }

        # 生成签名
        params["sign"] = self._sign(params)
        params["sign_type"] = "MD5"

        # 构建支付URL
        pay_url = f"{self.api_url}/submit.php?{urllib.parse.urlencode(params)}"

        return {
            'success': True,
            'pay_url': pay_url,
            'order_no': order_no,
            'amount': amount,
            'channel': channel,
            'params': params,
            'api_url': self.api_url,
            'method': 'GET/POST',
            'note': '用户访问此URL完成支付，支付结果异步通知到notify_url'
        }

    def mapi(self, order_no, amount, name, notify_url, return_url,
             channel='alipay', clientip='127.0.0.1', device='pc', param=''):
        """
        API接口支付 - 返回JSON格式支付信息

        URL: {api_url}/mapi.php (POST)

        返回结果包含:
        - code: 状态码 (1成功)
        - msg: 返回信息
        - payurl: 支付跳转地址
        - qrcode: 二维码直链 (部分通道)
        - trade_no: 系统订单号

        Returns:
            dict: API返回的JSON数据
        """
        params = {
            "pid": self.pid,
            "type": channel,
            "out_trade_no": str(order_no),
            "notify_url": notify_url,
            "return_url": return_url,
            "name": str(name),
            "money": str(amount),
            "clientip": clientip,
            "device": device,
            "param": str(param) if param else '',
        }

        params["sign"] = self._sign(params)
        params["sign_type"] = "MD5"

        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                f"{self.api_url}/mapi.php",
                data=data,
                method='POST',
                headers={
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'EasyPayAPI/3.0'
                }
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {
                    'success': result.get('code') == 1,
                    'data': result,
                    'pay_url': result.get('payurl'),
                    'qr_code': result.get('qrcode'),
                    'trade_no': result.get('trade_no')
                }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'fallback_url': f"{self.api_url}/submit.php?{urllib.parse.urlencode(params)}"
            }

    def query_order(self, order_no):
        """
        查询单个订单状态

        URL: {api_url}/api.php?act=order

        Args:
            order_no: 商户订单号 或 系统订单号(trade_no)

        Returns:
            dict: {success, status, data}
            status: 1=支付成功, 0=未支付, 2=订单不存在
        """
        params = {
            "act": "order",
            "pid": self.pid,
            "key": self.key,
            "out_trade_no": str(order_no),
        }

        query_url = f"{self.api_url}/api.php?{urllib.parse.urlencode(params)}"

        try:
            req = urllib.request.Request(
                query_url,
                method='GET',
                headers={'User-Agent': 'EasyPayAPI/3.0'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {
                    'success': result.get('code') == 1,
                    'status': result.get('status'),  # 1=成功, 0=未支付
                    'data': result,
                    'order_no': order_no
                }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'order_no': order_no
            }

    def query_merchant(self):
        """
        查询商户信息

        URL: {api_url}/api.php?act=query

        Returns:
            dict: 商户信息 (余额、订单统计等)
        """
        params = {
            "act": "query",
            "pid": self.pid,
            "key": self.key,
        }

        query_url = f"{self.api_url}/api.php?{urllib.parse.urlencode(params)}"

        try:
            req = urllib.request.Request(
                query_url,
                method='GET',
                headers={'User-Agent': 'EasyPayAPI/3.0'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {
                    'success': result.get('code') == 1,
                    'data': result,
                    'merchant_id': result.get('pid'),
                    'balance': result.get('money'),
                    'status': result.get('active'),  # 1=正常, 0=封禁
                    'total_orders': result.get('orders'),
                    'today_orders': result.get('order_today'),
                    'yesterday_orders': result.get('order_lastday')
                }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def query_settlements(self):
        """
        查询结算记录

        URL: {api_url}/api.php?act=settle

        Returns:
            dict: 结算记录列表
        """
        params = {
            "act": "settle",
            "pid": self.pid,
            "key": self.key,
        }

        query_url = f"{self.api_url}/api.php?{urllib.parse.urlencode(params)}"

        try:
            req = urllib.request.Request(
                query_url,
                method='GET',
                headers={'User-Agent': 'EasyPayAPI/3.0'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {
                    'success': result.get('code') == 1,
                    'data': result.get('data', []),
                    'raw': result
                }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def refund(self, order_no, amount=None, trade_no=None):
        """
        订单退款

        URL: {api_url}/api.php?act=refund (POST)

        需先在商户后台开启退款API开关

        Args:
            order_no: 商户订单号
            amount: 退款金额 (部分通道需与原订单金额一致)
            trade_no: 系统订单号 (优先使用)

        Returns:
            dict: {success, msg}
        """
        params = {
            "pid": self.pid,
            "key": self.key,
            "out_trade_no": str(order_no),
        }

        if trade_no:
            params["trade_no"] = str(trade_no)
        if amount:
            params["money"] = str(amount)

        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                f"{self.api_url}/api.php?act=refund",
                data=data,
                method='POST',
                headers={
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'EasyPayAPI/3.0'
                }
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                return {
                    'success': result.get('code') == 1,
                    'msg': result.get('msg', ''),
                    'data': result
                }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def verify_notify(self, notify_params):
        """
        验证异步通知签名 - 防止伪造通知

        易支付异步通知会POST到notify_url，收到后必须验签

        通知参数示例:
        {
            'pid': '1001',
            'trade_no': '202405211200001',
            'out_trade_no': 'ORDER001',
            'type': 'alipay',
            'name': '商品',
            'money': '10.00',
            'trade_status': 'TRADE_SUCCESS',
            'sign': 'xxx',
            'sign_type': 'MD5'
        }

        Args:
            notify_params: 通知参数字典 (包含sign字段)

        Returns:
            bool: 签名是否有效
        """
        if 'sign' not in notify_params:
            return False

        params = dict(notify_params)
        received_sign = params.pop('sign', '').lower()
        params.pop('sign_type', None)  # 不参与签名

        computed_sign = self._sign(params)

        return received_sign == computed_sign

    def get_success_response(self):
        """
        返回给易支付平台的成功响应

        收到异步通知并验签通过后，必须返回纯文本 "success"
        如通知失败，平台会重复通知最多5次
        """
        return "success"

    def get_payment_channels(self):
        """
        获取支持的支付方式列表

        常见通道:
        - alipay: 支付宝
        - wxpay: 微信支付
        - qq: QQ钱包
        """
        return {
            'alipay': {'name': '支付宝', 'fee_rate': 0.01},
            'wxpay': {'name': '微信支付', 'fee_rate': 0.01},
            'qq': {'name': 'QQ钱包', 'fee_rate': 0.01},
        }
