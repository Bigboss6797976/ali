# -*- coding: utf-8 -*-
"""
微信支付 - Native扫码支付真实实现
接口: unifiedorder (统一下单)
文档: https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_1
"""

import xml.etree.ElementTree as ET
import urllib.request
import urllib.parse
import hashlib
import time
import uuid
from core.crypto import CryptoUtil

class WechatAPI:
    """
    微信支付API - Native扫码支付

    使用流程:
    1. 调用 unifiedorder() 获取 code_url
    2. 将 code_url 生成二维码图片
    3. 用户微信扫码支付
    4. 微信异步通知支付结果

    注意: 需要配置支付目录和授权域名
    """

    UNIFIEDORDER_URL = "https://api.mch.weixin.qq.com/pay/unifiedorder"
    ORDERQUERY_URL = "https://api.mch.weixin.qq.com/pay/orderquery"
    CLOSEORDER_URL = "https://api.mch.weixin.qq.com/pay/closeorder"
    REFUND_URL = "https://api.mch.weixin.qq.com/secapi/pay/refund"

    def __init__(self, mch_id, api_key, app_id=None):
        """
        初始化微信支付API

        Args:
            mch_id: 微信支付商户号
            api_key: API密钥 (v2) - 32位，在商户平台设置
            app_id: 微信公众号/小程序AppID (Native支付可不填)
        """
        self.mch_id = mch_id
        self.api_key = api_key
        self.app_id = app_id

    def _dict_to_xml(self, data):
        """将字典转为XML"""
        xml = ['<xml>']
        for k, v in sorted(data.items()):
            if v is not None and v != '':
                xml.append(f'<{k}><![CDATA[{v}]]></{k}>')
        xml.append('</xml>')
        return ''.join(xml)

    def _xml_to_dict(self, xml_str):
        """将XML转为字典"""
        root = ET.fromstring(xml_str)
        result = {}
        for child in root:
            result[child.tag] = child.text
        return result

    def _sign(self, params):
        """生成MD5签名"""
        return CryptoUtil.md5_sign(params, self.api_key)

    def unifiedorder(self, order_no, amount, body, detail='', 
                     notify_url=None, product_id='QR001', 
                     trade_type='NATIVE', time_expire=None):
        """
        统一下单 - 生成Native支付二维码

        Args:
            order_no: 商户订单号 (32字符内)
            amount: 金额 (元，会自动转为分)
            body: 商品描述
            detail: 商品详情
            notify_url: 异步通知地址
            product_id: 商品ID
            trade_type: NATIVE (扫码支付)
            time_expire: 订单失效时间

        Returns:
            dict: {success, code_url, prepay_id, ...}
            code_url 用于生成二维码图片
        """
        params = {
            "appid": self.app_id or '',
            "mch_id": self.mch_id,
            "nonce_str": CryptoUtil.generate_nonce_str(),
            "body": body,
            "detail": detail,
            "out_trade_no": str(order_no),
            "total_fee": int(float(amount) * 100),  # 转为分
            "spbill_create_ip": "127.0.0.1",  # 调用IP
            "notify_url": notify_url or '',
            "trade_type": trade_type,
            "product_id": product_id,
        }

        if time_expire:
            params["time_expire"] = time_expire

        # 生成签名
        params["sign"] = self._sign(params)

        # 发送请求
        xml_data = self._dict_to_xml(params)

        try:
            req = urllib.request.Request(
                self.UNIFIEDORDER_URL,
                data=xml_data.encode('utf-8'),
                headers={'Content-Type': 'text/xml; charset=utf-8'},
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result_xml = response.read().decode('utf-8')
                result = self._xml_to_dict(result_xml)

                # 验证返回签名
                return_sign = result.pop('sign', '')
                calc_sign = self._sign(result)

                if return_sign and return_sign != calc_sign:
                    return {
                        'success': False,
                        'error': '返回签名验证失败',
                        'raw_response': result
                    }

                if result.get('return_code') == 'SUCCESS':
                    if result.get('result_code') == 'SUCCESS':
                        return {
                            'success': True,
                            'code_url': result.get('code_url'),  # 二维码URL
                            'prepay_id': result.get('prepay_id'),
                            'trade_type': result.get('trade_type'),
                            'out_trade_no': order_no,
                            'raw_response': result
                        }
                    else:
                        return {
                            'success': False,
                            'error': result.get('err_code_des', result.get('err_code')),
                            'raw_response': result
                        }
                else:
                    return {
                        'success': False,
                        'error': result.get('return_msg', '请求失败'),
                        'raw_response': result
                    }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def orderquery(self, order_no, transaction_id=None):
        """
        查询订单状态

        状态: SUCCESS/REFUND/NOTPAY/CLOSED/REVOKED/USERPAYING/PAYERROR
        """
        params = {
            "appid": self.app_id or '',
            "mch_id": self.mch_id,
            "nonce_str": CryptoUtil.generate_nonce_str(),
            "out_trade_no": str(order_no),
        }
        if transaction_id:
            params["transaction_id"] = transaction_id

        params["sign"] = self._sign(params)
        xml_data = self._dict_to_xml(params)

        try:
            req = urllib.request.Request(
                self.ORDERQUERY_URL,
                data=xml_data.encode('utf-8'),
                headers={'Content-Type': 'text/xml; charset=utf-8'},
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = self._xml_to_dict(response.read().decode('utf-8'))

                if result.get('return_code') == 'SUCCESS':
                    if result.get('result_code') == 'SUCCESS':
                        return {
                            'success': True,
                            'trade_state': result.get('trade_state'),
                            'trade_state_desc': result.get('trade_state_desc'),
                            'total_fee': result.get('total_fee'),
                            'cash_fee': result.get('cash_fee'),
                            'transaction_id': result.get('transaction_id'),
                            'time_end': result.get('time_end'),
                            'raw_response': result
                        }
                return {
                    'success': False,
                    'error': result.get('err_code_des', '查询失败'),
                    'raw_response': result
                }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def closeorder(self, order_no):
        """关闭订单"""
        params = {
            "appid": self.app_id or '',
            "mch_id": self.mch_id,
            "nonce_str": CryptoUtil.generate_nonce_str(),
            "out_trade_no": str(order_no),
        }
        params["sign"] = self._sign(params)
        xml_data = self._dict_to_xml(params)

        try:
            req = urllib.request.Request(
                self.CLOSEORDER_URL,
                data=xml_data.encode('utf-8'),
                headers={'Content-Type': 'text/xml; charset=utf-8'},
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = self._xml_to_dict(response.read().decode('utf-8'))
                return {
                    'success': result.get('return_code') == 'SUCCESS',
                    'raw_response': result
                }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def verify_notify(self, notify_data):
        """
        验证异步通知签名

        微信异步通知会POST到notify_url
        """
        sign = notify_data.pop('sign', '')
        calc_sign = self._sign(notify_data)
        return sign == calc_sign
