# -*- coding: utf-8 -*-
"""
支付宝官方API - 真实有效实现
接口: alipay.trade.precreate (统一收单线下交易预创建)
文档: https://opendocs.alipay.com/open/02ekfg
"""

import json
import time
import base64
import urllib.request
import urllib.parse
from urllib.error import HTTPError
from core.crypto import CryptoUtil

class AlipayAPI:
    """
    支付宝当面付API - 生成真实支付二维码

    使用流程:
    1. 调用 create_order() 生成二维码URL
    2. 用户扫码后在支付宝App内完成支付
    3. 支付宝异步通知支付结果到 notify_url
    4. 调用 query_order() 查询订单状态

    沙箱测试:
    - 沙箱APPID: 2024XXXXXXXXXXXX (需申请)
    - 沙箱网关: https://openapi.alipaydev.com/gateway.do
    - 沙箱钱包: https://open.alipay.com/develop/sandbox/tool
    """

    GATEWAY = "https://openapi.alipay.com/gateway.do"
    SANDBOX_GATEWAY = "https://openapi.alipaydev.com/gateway.do"

    def __init__(self, app_id, private_key, alipay_public_key=None, sandbox=False):
        """
        初始化支付宝API

        Args:
            app_id: 支付宝开放平台APPID
            private_key: RSA2私钥 (PKCS#1格式)
            alipay_public_key: 支付宝公钥 (用于验签)
            sandbox: 是否使用沙箱环境
        """
        self.app_id = app_id
        self.private_key = private_key
        self.alipay_public_key = alipay_public_key
        self.sandbox = sandbox
        self.gateway = self.SANDBOX_GATEWAY if sandbox else self.GATEWAY

    def create_order(self, order_no, amount, subject, body='', timeout='2h', 
                     notify_url=None, return_url=None):
        """
        创建预创建订单 - 生成真实可支付的二维码

        调用 alipay.trade.precreate 接口，返回:
        - qr_code: 二维码码串，用二维码工具生成图片
        - out_trade_no: 商户订单号

        用户扫码后，支付宝会异步通知支付结果

        Args:
            order_no: 商户订单号 (唯一)
            amount: 金额 (元)
            subject: 订单标题
            body: 订单描述
            timeout: 订单超时时间
            notify_url: 异步通知地址
            return_url: 同步跳转地址

        Returns:
            dict: {qr_code, out_trade_no, qr_code_url}
        """

        biz_content = {
            "out_trade_no": str(order_no),
            "total_amount": str(amount),
            "subject": str(subject),
            "body": str(body) if body else subject,
            "timeout_express": timeout,
            "qr_code_timeout_express": "2h",
        }

        params = {
            "app_id": self.app_id,
            "method": "alipay.trade.precreate",
            "charset": "utf-8",
            "sign_type": "RSA2",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0",
            "biz_content": json.dumps(biz_content, ensure_ascii=False),
        }

        if notify_url:
            params["notify_url"] = notify_url
        if return_url:
            params["return_url"] = return_url

        # 生成RSA2签名
        params["sign"] = CryptoUtil.rsa2_sign(params, self.private_key)

        # 发送请求
        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                self.gateway,
                data=data,
                method='POST',
                headers={'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))

                response_key = 'alipay_trade_precreate_response'
                if response_key in result:
                    resp = result[response_key]

                    # 验签
                    if self.alipay_public_key:
                        sign = result.get('sign', '')
                        if not CryptoUtil.verify_rsa2(resp, sign, self.alipay_public_key):
                            raise Exception("支付宝响应签名验证失败")

                    if resp.get('code') == '10000':
                        return {
                            'success': True,
                            'qr_code': resp.get('qr_code'),  # 二维码码串
                            'out_trade_no': resp.get('out_trade_no'),
                            'qr_code_url': resp.get('qr_code'),  # 可直接生成二维码
                            'raw_response': resp
                        }
                    else:
                        return {
                            'success': False,
                            'error': resp.get('msg', '未知错误'),
                            'sub_msg': resp.get('sub_msg', ''),
                            'code': resp.get('code')
                        }
                else:
                    return {
                        'success': False,
                        'error': 'API响应格式错误',
                        'raw_response': result
                    }

        except HTTPError as e:
            return {
                'success': False,
                'error': f'HTTP错误: {e.code}',
                'details': e.read().decode('utf-8')
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def query_order(self, order_no, trade_no=None):
        """
        查询订单状态

        状态说明:
        - WAIT_BUYER_PAY: 交易创建，等待买家付款
        - TRADE_CLOSED: 未付款交易超时关闭或支付完成后全额退款
        - TRADE_SUCCESS: 交易支付成功
        - TRADE_FINISHED: 交易结束，不可退款
        """
        biz_content = {"out_trade_no": str(order_no)}
        if trade_no:
            biz_content["trade_no"] = trade_no

        params = {
            "app_id": self.app_id,
            "method": "alipay.trade.query",
            "charset": "utf-8",
            "sign_type": "RSA2",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0",
            "biz_content": json.dumps(biz_content),
        }
        params["sign"] = CryptoUtil.rsa2_sign(params, self.private_key)

        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                self.gateway,
                data=data,
                method='POST',
                headers={'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                resp = result.get('alipay_trade_query_response', {})

                if resp.get('code') == '10000':
                    return {
                        'success': True,
                        'trade_status': resp.get('trade_status'),
                        'total_amount': resp.get('total_amount'),
                        'receipt_amount': resp.get('receipt_amount'),
                        'buyer_pay_amount': resp.get('buyer_pay_amount'),
                        'send_pay_date': resp.get('send_pay_date'),
                        'raw_response': resp
                    }
                else:
                    return {
                        'success': False,
                        'error': resp.get('msg'),
                        'code': resp.get('code')
                    }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def refund(self, order_no, refund_amount, reason='', trade_no=None):
        """
        订单退款

        支持部分退款和全额退款
        """
        biz_content = {
            "out_trade_no": str(order_no),
            "refund_amount": str(refund_amount),
            "refund_reason": reason
        }
        if trade_no:
            biz_content["trade_no"] = trade_no

        params = {
            "app_id": self.app_id,
            "method": "alipay.trade.refund",
            "charset": "utf-8",
            "sign_type": "RSA2",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0",
            "biz_content": json.dumps(biz_content),
        }
        params["sign"] = CryptoUtil.rsa2_sign(params, self.private_key)

        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                self.gateway,
                data=data,
                method='POST',
                headers={'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                resp = result.get('alipay_trade_refund_response', {})

                if resp.get('code') == '10000':
                    return {
                        'success': True,
                        'refund_fee': resp.get('refund_fee'),
                        'gmt_refund_pay': resp.get('gmt_refund_pay'),
                        'raw_response': resp
                    }
                else:
                    return {
                        'success': False,
                        'error': resp.get('msg'),
                        'code': resp.get('code')
                    }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def close_order(self, order_no, trade_no=None):
        """
        关闭订单 - 用于订单超时未支付
        """
        biz_content = {"out_trade_no": str(order_no)}
        if trade_no:
            biz_content["trade_no"] = trade_no

        params = {
            "app_id": self.app_id,
            "method": "alipay.trade.close",
            "charset": "utf-8",
            "sign_type": "RSA2",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "version": "1.0",
            "biz_content": json.dumps(biz_content),
        }
        params["sign"] = CryptoUtil.rsa2_sign(params, self.private_key)

        try:
            data = urllib.parse.urlencode(params).encode('utf-8')
            req = urllib.request.Request(
                self.gateway,
                data=data,
                method='POST',
                headers={'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'}
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                resp = result.get('alipay_trade_close_response', {})
                return {
                    'success': resp.get('code') == '10000',
                    'raw_response': resp
                }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def verify_notify(self, params):
        """
        验证异步通知签名 - 防止伪造通知

        支付宝异步通知会POST到notify_url，收到后必须验签
        """
        if not self.alipay_public_key:
            return False

        sign = params.pop('sign', '')
        sign_type = params.pop('sign_type', '')

        return CryptoUtil.verify_rsa2(params, sign, self.alipay_public_key)
