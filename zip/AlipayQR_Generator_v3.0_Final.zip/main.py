#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlipayQR v3.0 - 多通道聚合收款码生成器

支持: 支付宝 / 微信 / Stripe / 易支付 (全部真实API)
平台: Web / iOS / Android / 桌面端 / CLI

使用方法:
    python main.py --help
    python main.py --provider alipay --amount 100 --app-id YOUR_APPID --private-key ./key.pem
"""

import sys
import os

# 添加src到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from cli.alipayqr import main

if __name__ == '__main__':
    sys.exit(main())
