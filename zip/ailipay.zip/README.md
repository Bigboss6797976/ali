# Payment Code Beautifier v2.0

聚合收款码美化生成工具 - 纯前端实现

## 在线演示

GitHub Pages: https://bigboss6797976.github.io/ailipay/

## 功能

- 单码美化 - 上传图片 + 输入链接生成海报
- 聚合能量码 - 支付宝/微信/USDT/ETH 多平台聚合
- 批量生成 - 一次上传多张图片批量处理
- 拖拽上传 + 点击上传
- 图片预览 + 清除
- 扫码测试跳转
- 主题颜色自定义

## 本地使用

```bash
# 方式1: 直接打开浏览器
open index.html

# 方式2: 本地服务器
python3 -m http.server 8080
```

## 技术栈

HTML5 + CSS3 + JavaScript + QRCode.js + html2canvas

## License

MIT
