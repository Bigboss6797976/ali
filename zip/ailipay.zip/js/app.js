// ===== Payment Code Beautifier - Main App =====

// State management
const state = {
    single: { image: null, link: '', logo: null },
    multi: {
        alipay: { image: null, link: '' },
        wechat: { image: null, link: '' },
        usdt: { image: null, link: '' },
        eth: { image: null, link: '' }
    },
    batch: { images: [], link: '' }
};

// ===== Utility Functions =====
function $(selector) { return document.querySelector(selector); }
function $$(selector) { return document.querySelectorAll(selector); }

function fileToBase64(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(file);
    });
}

function createQRCode(text, container, width = 200, height = 200) {
    container.innerHTML = '';
    const qr = new QRCode(container, {
        text: text,
        width: width,
        height: height,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
    });
    return qr;
}

function downloadImage(dataUrl, filename) {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// ===== Tab Navigation =====
function initTabs() {
    const tabBtns = $$('.tab-btn');
    const tabContents = $$('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;

            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            $(`#${tabId}`).classList.add('active');
        });
    });
}

// ===== Upload Handler =====
function initUpload(config) {
    const { areaId, inputId, previewId, imgId, clearId, stateKey, stateSubKey, onChange } = config;

    const area = $(`#${areaId}`);
    const input = $(`#${inputId}`);
    const previewContainer = $(`#${previewId}`);
    const img = $(`#${imgId}`);
    const clearBtn = $(`#${clearId}`);
    const placeholder = $(`#${areaId.replace('upload-area', 'placeholder')}`);

    // Click upload
    area.addEventListener('click', (e) => {
        if (e.target.closest('.clear-btn')) return;
        input.click();
    });

    // File select
    input.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const base64 = await fileToBase64(file);
        img.src = base64;
        previewContainer.style.display = 'block';
        placeholder.style.display = 'none';

        if (stateSubKey) {
            state[stateKey][stateSubKey].image = base64;
        } else {
            state[stateKey].image = base64;
        }

        if (onChange) onChange(base64);
    });

    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
        });
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.add('dragover'));
    });

    ['dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.remove('dragover'));
    });

    area.addEventListener('drop', async (e) => {
        const file = e.dataTransfer.files[0];
        if (!file || !file.type.startsWith('image/')) return;

        const base64 = await fileToBase64(file);
        img.src = base64;
        previewContainer.style.display = 'block';
        placeholder.style.display = 'none';

        if (stateSubKey) {
            state[stateKey][stateSubKey].image = base64;
        } else {
            state[stateKey].image = base64;
        }

        if (onChange) onChange(base64);
    });

    // Clear
    clearBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        img.src = '';
        previewContainer.style.display = 'none';
        placeholder.style.display = 'block';
        input.value = '';

        if (stateSubKey) {
            state[stateKey][stateSubKey].image = null;
        } else {
            state[stateKey].image = null;
        }
    });
}

// ===== Single Code Module =====
function initSingle() {
    initUpload({
        areaId: 'single-upload-area',
        inputId: 'single-file-input',
        previewId: 'single-preview-container',
        imgId: 'single-preview-img',
        clearId: 'single-clear-btn',
        stateKey: 'single'
    });

    // Color picker
    const colorPicker = $('#single-color');
    const colorValue = $('.color-value');
    colorPicker.addEventListener('input', (e) => {
        colorValue.textContent = e.target.value;
    });

    // Logo upload
    const logoInput = $('#single-logo-input');
    logoInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            state.single.logo = await fileToBase64(file);
        }
    });

    // Link input
    $('#single-link').addEventListener('input', (e) => {
        state.single.link = e.target.value;
    });

    // Generate
    $('#single-generate').addEventListener('click', generateSinglePoster);

    // Download
    $('#single-download').addEventListener('click', () => {
        const poster = $('#single-poster').querySelector('img');
        if (poster) downloadImage(poster.src, 'payment-code-poster.png');
    });

    // Scan test
    $('#single-scan-test').addEventListener('click', () => {
        openScanModal(state.single.link || 'https://example.com');
    });
}

async function generateSinglePoster() {
    const { image, link, logo } = state.single;
    const color = $('#single-color').value;
    const qrStyle = $('#single-qr-style').value;

    if (!image) {
        alert('请先上传收款码图片！');
        return;
    }

    const posterContainer = $('#single-poster');
    posterContainer.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 生成中...</div>';
    $('#single-result').style.display = 'block';

    // Create poster DOM
    const poster = document.createElement('div');
    poster.className = 'poster-single';
    poster.style.background = `linear-gradient(135deg, ${color}, ${adjustColor(color, -30)})`;

    let qrHtml = '';
    if (link) {
        qrHtml = `<div id="temp-qr-single"></div>`;
    } else {
        qrHtml = `<img src="${image}" style="width:200px;height:200px;object-fit:contain;border-radius:8px;background:#fff;padding:10px;">`;
    }

    let logoHtml = '';
    if (logo) {
        logoHtml = `<img src="${logo}" class="poster-logo" alt="logo">`;
    }

    poster.innerHTML = `
        <div class="poster-content">
            ${logoHtml}
            <div class="poster-title">扫一扫 向我付款</div>
            <div class="poster-qr">${qrHtml}</div>
            <div class="poster-hint">长按识别二维码</div>
        </div>
    `;

    posterContainer.innerHTML = '';
    posterContainer.appendChild(poster);

    // Generate QR if link exists
    if (link) {
        const qrContainer = poster.querySelector('#temp-qr-single');
        qrContainer.style.cssText = 'width:200px;height:200px;background:#fff;padding:10px;border-radius:12px;margin:0 auto;';
        createQRCode(link, qrContainer, 180, 180);
    }

    // Wait for QR to render
    await new Promise(r => setTimeout(r, 500));

    // Capture with html2canvas
    try {
        const canvas = await html2canvas(poster, {
            backgroundColor: null,
            scale: 2,
            useCORS: true,
            allowTaint: true
        });

        const dataUrl = canvas.toDataURL('image/png');
        posterContainer.innerHTML = `<img src="${dataUrl}" alt="海报" style="max-width:100%;">`;
    } catch (err) {
        console.error('生成失败:', err);
        posterContainer.innerHTML = '<p style="color:#e74c3c;">生成失败，请重试</p>';
    }
}

// ===== Multi Code Module =====
function initMulti() {
    const platforms = ['alipay', 'wechat', 'usdt', 'eth'];

    platforms.forEach(platform => {
        initUpload({
            areaId: `${platform}-upload-area`,
            inputId: `${platform}-file-input`,
            previewId: `${platform}-preview-container`,
            imgId: `${platform}-preview-img`,
            clearId: `${platform}-clear-btn`,
            stateKey: 'multi',
            stateSubKey: platform
        });

        $(`#${platform}-link`).addEventListener('input', (e) => {
            state.multi[platform].link = e.target.value;
        });
    });

    $('#multi-generate').addEventListener('click', generateMultiPoster);

    $('#multi-download').addEventListener('click', () => {
        const poster = $('#multi-poster').querySelector('img');
        if (poster) downloadImage(poster.src, 'multi-payment-poster.png');
    });

    $('#multi-scan-test').addEventListener('click', () => {
        // Use first available link
        const platforms = ['alipay', 'wechat', 'usdt', 'eth'];
        let testLink = 'https://example.com';
        for (const p of platforms) {
            if (state.multi[p].link) {
                testLink = state.multi[p].link;
                break;
            }
        }
        openScanModal(testLink);
    });
}

async function generateMultiPoster() {
    const platforms = ['alipay', 'usdt', 'wechat', 'eth'];
    const platformNames = { alipay: '支付宝', wechat: '微信支付', usdt: 'USDT', eth: 'ETH' };
    const platformColors = { alipay: '#1677ff', wechat: '#07c160', usdt: '#f0b90b', eth: '#627eea' };
    const platformIcons = { 
        alipay: 'fab fa-alipay', 
        wechat: 'fab fa-weixin', 
        usdt: 'fas fa-coins', 
        eth: 'fas fa-wallet' 
    };

    const layout = $('#multi-layout').value;
    const theme = $('#multi-theme').value;

    const posterContainer = $('#multi-poster');
    posterContainer.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 生成中...</div>';
    $('#multi-result').style.display = 'block';

    // Create poster DOM
    const poster = document.createElement('div');
    poster.className = 'poster-multi';

    // Theme background
    let bgStyle = '';
    if (theme === 'dark') {
        bgStyle = 'background: linear-gradient(135deg, #1a1a2e, #16213e);';
    } else if (theme === 'light') {
        bgStyle = 'background: linear-gradient(135deg, #f5f5f5, #e0e0e0);';
    } else {
        bgStyle = 'background: linear-gradient(135deg, #667eea, #764ba2);';
    }
    poster.style.cssText = bgStyle + ' width:500px;';

    // Build items
    let itemsHtml = '';
    const activePlatforms = platforms.filter(p => state.multi[p].image);

    if (activePlatforms.length === 0) {
        alert('请至少上传一个平台的收款码！');
        posterContainer.innerHTML = '';
        $('#multi-result').style.display = 'none';
        return;
    }

    const gridClass = layout === 'grid3' ? 'multi-grid-3' : (layout === 'vertical' ? 'multi-vertical' : 'multi-grid');

    activePlatforms.forEach((platform, idx) => {
        const { image, link } = state.multi[platform];
        const qrId = `multi-qr-${platform}-${idx}`;

        let qrHtml = '';
        if (link) {
            qrHtml = `<div id="${qrId}" style="width:120px;height:120px;background:#fff;padding:6px;border-radius:8px;margin:0 auto;"></div>`;
        } else {
            qrHtml = `<img src="${image}" style="width:120px;height:120px;object-fit:contain;background:#fff;padding:6px;border-radius:8px;">`;
        }

        const textColor = theme === 'light' ? '#333' : '#fff';

        itemsHtml += `
            <div class="multi-item" style="border:2px solid ${platformColors[platform]}33;">
                <div class="item-icon" style="color:${platformColors[platform]};">
                    <i class="${platformIcons[platform]}"></i>
                </div>
                <div class="item-name" style="color:${textColor};">${platformNames[platform]}</div>
                <div class="item-qr">${qrHtml}</div>
            </div>
        `;
    });

    const titleColor = theme === 'light' ? '#333' : '#fff';
    const hintColor = theme === 'light' ? '#666' : 'rgba(255,255,255,0.7)';

    poster.innerHTML = `
        <div class="poster-content">
            <div class="poster-title" style="color:${titleColor};">聚合收款码</div>
            <div class="${gridClass}" style="display:grid;grid-template-columns:repeat(${layout === 'grid3' ? 3 : 2}, 1fr);gap:20px;">
                ${itemsHtml}
            </div>
            <div class="multi-hint" style="color:${hintColor};">选择任意方式扫码支付</div>
        </div>
    `;

    posterContainer.innerHTML = '';
    posterContainer.appendChild(poster);

    // Generate QRs
    activePlatforms.forEach((platform, idx) => {
        const { link } = state.multi[platform];
        if (link) {
            const qrContainer = poster.querySelector(`#multi-qr-${platform}-${idx}`);
            createQRCode(link, qrContainer, 108, 108);
        }
    });

    await new Promise(r => setTimeout(r, 500));

    try {
        const canvas = await html2canvas(poster, {
            backgroundColor: null,
            scale: 2,
            useCORS: true,
            allowTaint: true
        });

        const dataUrl = canvas.toDataURL('image/png');
        posterContainer.innerHTML = `<img src="${dataUrl}" alt="聚合海报" style="max-width:100%;">`;
    } catch (err) {
        console.error('生成失败:', err);
        posterContainer.innerHTML = '<p style="color:#e74c3c;">生成失败，请重试</p>';
    }
}

// ===== Batch Module =====
function initBatch() {
    const area = $('#batch-upload-area');
    const input = $('#batch-file-input');
    const grid = $('#batch-preview-grid');
    const placeholder = $('#batch-placeholder');

    // Click upload
    area.addEventListener('click', () => input.click());

    // File select
    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        await addBatchImages(files);
    });

    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
        });
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.add('dragover'));
    });

    ['dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.remove('dragover'));
    });

    area.addEventListener('drop', async (e) => {
        const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
        await addBatchImages(files);
    });

    // Link input
    $('#batch-link').addEventListener('input', (e) => {
        state.batch.link = e.target.value;
    });

    // Generate
    $('#batch-generate').addEventListener('click', generateBatchPosters);

    // Download all
    $('#batch-download-all').addEventListener('click', downloadAllBatch);
}

async function addBatchImages(files) {
    const grid = $('#batch-preview-grid');

    for (const file of files) {
        if (state.batch.images.length >= 50) {
            alert('最多支持50张图片');
            break;
        }

        const base64 = await fileToBase64(file);
        const id = Date.now() + Math.random();
        state.batch.images.push({ id, base64, name: file.name });

        const item = document.createElement('div');
        item.className = 'batch-item';
        item.dataset.id = id;
        item.innerHTML = `
            <img src="${base64}" alt="${file.name}">
            <button class="batch-remove" onclick="removeBatchImage(${id})"><i class="fas fa-times"></i></button>
            <div class="batch-name">${file.name}</div>
        `;
        grid.appendChild(item);
    }

    if (state.batch.images.length > 0) {
        $('#batch-placeholder').style.display = 'none';
    }
}

function removeBatchImage(id) {
    state.batch.images = state.batch.images.filter(img => img.id !== id);
    const item = $(`.batch-item[data-id="${id}"]`);
    if (item) item.remove();

    if (state.batch.images.length === 0) {
        $('#batch-placeholder').style.display = 'block';
    }
}

async function generateBatchPosters() {
    const images = state.batch.images;
    const link = state.batch.link;
    const color = $('#batch-color').value;
    const format = $('#batch-format').value;

    if (images.length === 0) {
        alert('请先上传图片！');
        return;
    }

    const progressBar = $('#batch-progress-fill');
    const progressText = $('#batch-progress-text');
    const progressContainer = $('#batch-progress');
    const resultsGrid = $('#batch-results-grid');
    const resultSection = $('#batch-result');

    progressContainer.style.display = 'block';
    resultSection.style.display = 'none';
    resultsGrid.innerHTML = '';

    const results = [];

    for (let i = 0; i < images.length; i++) {
        const { base64, name } = images[i];

        // Update progress
        const percent = ((i + 1) / images.length) * 100;
        progressBar.style.width = percent + '%';
        progressText.textContent = `${i + 1} / ${images.length}`;

        // Generate poster
        const poster = document.createElement('div');
        poster.className = 'poster-single';
        poster.style.cssText = `background: linear-gradient(135deg, ${color}, ${adjustColor(color, -30)}); width:400px; padding:30px;`;

        let qrHtml = '';
        if (link) {
            qrHtml = `<div id="batch-qr-${i}" style="width:200px;height:200px;background:#fff;padding:10px;border-radius:12px;margin:0 auto;"></div>`;
        } else {
            qrHtml = `<img src="${base64}" style="width:200px;height:200px;object-fit:contain;border-radius:8px;background:#fff;padding:10px;">`;
        }

        poster.innerHTML = `
            <div class="poster-content">
                <div class="poster-title">扫一扫 向我付款</div>
                <div class="poster-qr">${qrHtml}</div>
                <div class="poster-hint">长按识别二维码</div>
            </div>
        `;

        // Hidden container for rendering
        const hiddenContainer = document.createElement('div');
        hiddenContainer.style.cssText = 'position:fixed;left:-9999px;top:0;';
        hiddenContainer.appendChild(poster);
        document.body.appendChild(hiddenContainer);

        if (link) {
            const qrContainer = poster.querySelector(`#batch-qr-${i}`);
            createQRCode(link, qrContainer, 180, 180);
        }

        await new Promise(r => setTimeout(r, 300));

        try {
            const canvas = await html2canvas(poster, {
                backgroundColor: null,
                scale: 2,
                useCORS: true,
                allowTaint: true
            });

            const mimeType = format === 'jpg' ? 'image/jpeg' : (format === 'webp' ? 'image/webp' : 'image/png');
            const dataUrl = canvas.toDataURL(mimeType, 0.95);
            results.push({ name, dataUrl });

            // Add to results grid
            const resultItem = document.createElement('div');
            resultItem.className = 'batch-result-item';
            resultItem.innerHTML = `
                <img src="${dataUrl}" alt="${name}">
                <div class="result-info">
                    <span>${name}</span>
                    <button onclick="downloadImage('${dataUrl}', 'poster-${i+1}.${format}')">下载</button>
                </div>
            `;
            resultsGrid.appendChild(resultItem);

        } catch (err) {
            console.error(`生成失败 ${name}:`, err);
        }

        document.body.removeChild(hiddenContainer);

        // Small delay between generations
        await new Promise(r => setTimeout(r, 100));
    }

    progressContainer.style.display = 'none';
    resultSection.style.display = 'block';

    // Store results for download all
    state.batchResults = results;
}

function downloadAllBatch() {
    if (!state.batchResults || state.batchResults.length === 0) return;

    // Download one by one with delay
    state.batchResults.forEach((result, i) => {
        setTimeout(() => {
            downloadImage(result.dataUrl, `poster-${i+1}.png`);
        }, i * 500);
    });
}

// ===== Scan Test Modal =====
function initModal() {
    $('#modal-close').addEventListener('click', closeScanModal);
    $('#scan-modal').addEventListener('click', (e) => {
        if (e.target === $('#scan-modal')) closeScanModal();
    });
}

function openScanModal(link) {
    const modal = $('#scan-modal');
    const container = $('#scan-qr-container');
    const display = $('#scan-link-display');

    container.innerHTML = '';
    createQRCode(link, container, 200, 200);
    display.textContent = link;

    modal.style.display = 'flex';
}

function closeScanModal() {
    $('#scan-modal').style.display = 'none';
}

// ===== Utility: Color Adjustment =====
function adjustColor(hex, amount) {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.min(255, Math.max(0, (num >> 16) + amount));
    const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amount));
    const b = Math.min(255, Math.max(0, (num & 0x00FF) + amount));
    return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
}

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initSingle();
    initMulti();
    initBatch();
    initModal();

    console.log('Payment Code Beautifier v2.0 loaded');
});
