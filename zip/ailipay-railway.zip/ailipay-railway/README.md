# 支付宝能量码生成器 (Railway版)

基于 Pillow + Flask 的支付宝风格收款码海报生成服务。

## 功能
- 生成支付宝风格收款码海报（700x1000）
- 支持头像嵌入二维码中央
- 完整复刻模板样式（蓝色背景、白色广告牌、能量球）
- 扫码直接跳转支付链接

## 部署到 Railway

1. 把代码 push 到 GitHub 仓库
2. 登录 [railway.app](https://railway.app)
3. New Project → Deploy from GitHub repo
4. 选择此仓库，自动部署
5. 生成域名后即可访问

## API

### POST /generate
生成海报，支持 form-data 上传。

| 字段 | 类型 | 说明 |
|------|------|------|
| pay_url | string | 支付跳转链接 |
| avatar | file | 头像图片（可选） |

返回：`{success, image_url, preview, message}`

### POST /api/generate
纯 JSON API，头像用 base64 传入。

## 本地运行

```bash
pip install -r requirements.txt
python app.py
```

访问 http://localhost:5000
