import os
import io
import base64
import uuid
from datetime import datetime

from flask import Flask, render_template, request, jsonify, send_file
from PIL import Image, ImageDraw, ImageFont
import qrcode

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ==================== 配置项 ====================
# 字体路径兼容 Windows / Linux / macOS
FONT_PATHS = [
    "C:/Windows/Fonts/simhei.ttf",
    "C:/Windows/Fonts/msyh.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/usr/share/fonts/truetype/droid/DroidSansFallback.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/System/Library/Fonts/PingFang.ttc",
]

def get_font_path():
    for path in FONT_PATHS:
        if os.path.exists(path):
            return path
    return None

FONT_PATH = get_font_path()

# 颜色常量 (RGB)
BG_BLUE = (26, 133, 255)
WHITE = (255, 255, 255)
TEXT_DARK = (51, 51, 51)
TEXT_BLUE = (26, 133, 255)
GREEN_BALL_TOP = (164, 237, 27)
GREEN_BALL_BOTTOM = (102, 212, 0)
GREEN_TEXT = (25, 102, 0)

# ==================== 字体加载 ====================
def load_font(size):
    if FONT_PATH and os.path.exists(FONT_PATH):
        try:
            return ImageFont.truetype(FONT_PATH, size)
        except:
            pass
    return ImageFont.load_default()

# ==================== 绘制能量球 ====================
def draw_energy_ball(canvas, x, y, radius, font_ball):
    ball = Image.new("RGBA", (radius * 2, radius * 2), (0, 0, 0, 0))
    b_draw = ImageDraw.Draw(ball)

    for r in range(radius, 0, -1):
        factor = r / radius
        r_col = int(GREEN_BALL_BOTTOM[0] + (GREEN_BALL_TOP[0] - GREEN_BALL_BOTTOM[0]) * (1 - factor))
        g_col = int(GREEN_BALL_BOTTOM[1] + (GREEN_BALL_TOP[1] - GREEN_BALL_BOTTOM[1]) * (1 - factor))
        b_col = int(GREEN_BALL_BOTTOM[2] + (GREEN_BALL_TOP[2] - GREEN_BALL_BOTTOM[2]) * (1 - factor))
        offset = int((radius - r) * 0.15)
        b_draw.ellipse([offset, offset, offset + r * 2, offset + r * 2], 
                       fill=(r_col, g_col, b_col, 255))

    b_draw.text((radius - 18, radius - 22), "绿色", fill=GREEN_TEXT, font=font_ball)
    b_draw.text((radius - 18, radius + 2), "能量", fill=GREEN_TEXT, font=font_ball)

    canvas.paste(ball, (x - radius, y - radius), ball)

# ==================== 核心：生成海报 ====================
def generate_poster(pay_url, avatar_path=None):
    """
    基于用户原始模板代码，完整保留样式逻辑
    pay_url: 扫码跳转的支付链接
    avatar_path: 用户头像路径（可选，嵌入二维码中间）
    """
    # 加载字体
    font_logo = load_font(48)
    font_main_title = load_font(56)
    font_sub_title = load_font(32)
    font_bottom = load_font(42)
    font_ball = load_font(18)
    font_zhi = load_font(50)

    # ==================== 1. 初始化大画布 ====================
    poster_w, poster_h = 700, 1000
    canvas = Image.new("RGB", (poster_w, poster_h), WHITE)
    draw = ImageDraw.Draw(canvas)

    # 绘制下半部分的蓝色背景大矩形
    draw.rectangle([0, 160, poster_w, poster_h], fill=BG_BLUE)

    # ==================== 2. 绘制顶部 支付宝 Logo 区 ====================
    # 绘制蓝底白字的"支"字小方块
    draw.rounded_rectangle([200, 40, 280, 120], radius=15, fill=BG_BLUE)
    draw.text((215, 45), "支", fill=WHITE, font=font_zhi)
    # 绘制旁边的"支付宝"三个字
    draw.text((300, 50), "支付宝", fill=TEXT_DARK, font=font_logo)

    # ==================== 3. 绘制中部白色大广告牌 ====================
    board_w, board_h = 448, 520
    board_x = (poster_w - board_w) // 2
    board_y = 380
    draw.rounded_rectangle([board_x, board_y, board_x + board_w, board_y + board_h], 
                           radius=10, fill=WHITE)

    # ==================== 4. 生成带核心小图的二维码 ====================
    # 生成主体二维码
    qr = qrcode.QRCode(
        version=5,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=0
    )
    qr.add_data(pay_url)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    qr_img = qr_img.resize((320, 320), Image.Resampling.LANCZOS)

    # ==================== 5. 嵌入头像到二维码中央 ====================
    qr_w, qr_h = qr_img.size
    logo_w, logo_h = 55, 55  # 中央区域大小
    logo_x = (qr_w - logo_w) // 2
    logo_y = (qr_h - logo_h) // 2

    if avatar_path and os.path.exists(avatar_path):
        try:
            # 加载用户头像
            avatar = Image.open(avatar_path).convert("RGB")
            avatar = avatar.resize((logo_w, logo_h), Image.Resampling.LANCZOS)

            # 给头像加一圈白边
            logo_border = Image.new("RGB", (logo_w + 6, logo_h + 6), WHITE)
            logo_border.paste(avatar, (3, 3))
            qr_img.paste(logo_border, (logo_x - 3, logo_y - 3))
        except Exception as e:
            print(f"头像处理失败: {e}")
            # 失败时用默认 Logo
            center_logo = Image.new("RGB", (50, 50), (100, 180, 240))
            logo_draw = ImageDraw.Draw(center_logo)
            logo_draw.rectangle([0, 0, 50, 25], fill=(200, 230, 255))
            logo_draw.text((5, 30), "SHOP", fill=WHITE, font=load_font(10))
            center_logo = center_logo.resize((logo_w, logo_h), Image.Resampling.LANCZOS)
            logo_border = Image.new("RGB", (logo_w + 6, logo_h + 6), WHITE)
            logo_border.paste(center_logo, (3, 3))
            qr_img.paste(logo_border, (logo_x - 3, logo_y - 3))
    else:
        # 默认商户 Logo
        center_logo = Image.new("RGB", (50, 50), (100, 180, 240))
        logo_draw = ImageDraw.Draw(center_logo)
        logo_draw.rectangle([0, 0, 50, 25], fill=(200, 230, 255))
        logo_draw.text((5, 30), "SHOP", fill=WHITE, font=load_font(10))
        center_logo = center_logo.resize((logo_w, logo_h), Image.Resampling.LANCZOS)
        logo_border = Image.new("RGB", (logo_w + 6, logo_h + 6), WHITE)
        logo_border.paste(center_logo, (3, 3))
        qr_img.paste(logo_border, (logo_x - 3, logo_y - 3))

    # 将二维码贴上白色广告牌
    canvas.paste(qr_img, (board_x + (board_w - 320) // 2, board_y + 40))

    # ==================== 6. 绘制所有文本信息 ====================
    # 1. 蓝色背景上的大标题："推荐使用支付宝"
    title_text = "推荐使用支付宝"
    t_w = draw.textlength(title_text, font=font_main_title)
    draw.text(((poster_w - t_w) // 2, 230), title_text, fill=WHITE, font=font_main_title)

    # 2. 白色大牌子底部的提示语："打开支付宝[扫一扫]"
    sub_text = "打开支付宝[扫一扫]"
    s_w = draw.textlength(sub_text, font=font_sub_title)
    draw.text(((poster_w - s_w) // 2, board_y + 440), sub_text, fill=TEXT_BLUE, font=font_sub_title)

    # 3. 海报最底部的文案："支付得蚂蚁森林能量"
    bottom_text = "支付得蚂蚁森林能量"
    b_w = draw.textlength(bottom_text, font=font_bottom)
    draw.text(((poster_w - b_w) // 2, 920), bottom_text, fill=WHITE, font=font_bottom)

    # ==================== 7. 绘制绿色的"蚂蚁森林能量球" ====================
    draw_energy_ball(canvas, 620, 420, 48, font_ball)  # 右上大球
    draw_energy_ball(canvas, 70,  570, 38, font_ball)  # 左中中球
    draw_energy_ball(canvas, 620, 790, 32, font_ball)  # 右下小球

    return canvas

# ==================== Flask 路由 ====================
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    """生成海报 API - 支持 form-data 上传头像"""
    try:
        pay_url = request.form.get("pay_url", "https://www.alipay.com")
        avatar = request.files.get("avatar")

        avatar_path = None
        if avatar and avatar.filename:
            ext = os.path.splitext(avatar.filename)[1].lower()
            if ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']:
                avatar_path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4().hex}{ext}")
                avatar.save(avatar_path)

        # 生成海报
        poster = generate_poster(pay_url, avatar_path)

        # 保存到文件
        output_name = f"poster_{uuid.uuid4().hex[:8]}.png"
        output_path = os.path.join(UPLOAD_FOLDER, output_name)
        poster.save(output_path, "PNG")

        # 返回 base64 预览
        buffer = io.BytesIO()
        poster.save(buffer, format="PNG")
        img_base64 = base64.b64encode(buffer.getvalue()).decode()

        return jsonify({
            "success": True,
            "image_url": f"/download/{output_name}",
            "preview": f"data:image/png;base64,{img_base64}",
            "message": "海报生成成功！"
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/download/<filename>")
def download(filename):
    """下载生成的海报"""
    path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(path):
        return send_file(path, mimetype="image/png", as_attachment=True, 
                        download_name="alipay_poster.png")
    return "文件不存在", 404

@app.route("/api/generate", methods=["POST"])
def api_generate():
    """纯 JSON API - 头像用 base64 传入"""
    try:
        data = request.get_json() or {}
        pay_url = data.get("pay_url", "https://www.alipay.com")
        avatar_b64 = data.get("avatar_base64")

        avatar_path = None
        if avatar_b64:
            avatar_data = base64.b64decode(avatar_b64.split(",")[-1])
            avatar_path = os.path.join(UPLOAD_FOLDER, f"api_{uuid.uuid4().hex}.png")
            with open(avatar_path, "wb") as f:
                f.write(avatar_data)

        poster = generate_poster(pay_url, avatar_path)

        buffer = io.BytesIO()
        poster.save(buffer, format="PNG")
        img_base64 = base64.b64encode(buffer.getvalue()).decode()

        return jsonify({
            "success": True,
            "image_base64": img_base64,
            "message": "生成成功"
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
